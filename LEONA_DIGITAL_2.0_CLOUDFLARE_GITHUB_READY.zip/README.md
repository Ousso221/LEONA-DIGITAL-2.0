# LÉONA DIGITAL 2.0 — socle reconstruit

Plateforme municipale multi-communes : registre fiscal, recensement, recettes, contrôle,
cartographie et services citoyens. Cette livraison est un **socle technique V1**, pas une
certification de conformité ni une mise en production.

## Architecture

- `public/` : interface web statique publiée sur Cloudflare Pages.
- `functions/` : opérations serveur via Cloudflare Pages Functions ; secrets uniquement dans les variables chiffrées Cloudflare.
- `netlify/functions/` : anciennes fonctions conservées comme référence de migration, non utilisées par le déploiement Cloudflare.
- `supabase/migrations/` : schéma PostgreSQL versionné et politiques RLS.
- `docs/` : procédures, décisions et plan de tests.

## Prérequis

- Projet Supabase PostgreSQL + Auth.
- Projet Cloudflare Pages relié au dépôt GitHub (voir `README_CLOUDFLARE.md`).
- Node.js 20+ pour les fonctions Netlify et les contrôles locaux.
- Un environnement de test séparé de toute donnée réelle.

## Installation initiale

1. Créer un projet Supabase de test.
2. Dans SQL Editor, exécuter `supabase/migrations/0001_initial.sql` en entier.
3. Renseigner les secrets Supabase dans Cloudflare Pages selon `README_CLOUDFLARE.md`.
4. Dans `public/assets/js/config.js`, ne conserver que `SUPABASE_URL` et la clé publique/anon.
5. Déployer via GitHub et Cloudflare Pages ; le répertoire publié est `public/` et les fonctions sont dans `functions/`.
6. Créer les comptes avec Supabase Auth (pas d'inscription publique), puis affecter les profils/rôles depuis un processus administrateur contrôlé.
7. Exécuter les tests de `docs/PLAN_TESTS.md` avant toute donnée réelle.

## Sécurité importante

- La clé `service_role` ne doit jamais être mise dans `public/`, dans Git, dans un fichier `.env` versionné ou dans le navigateur.
- Les tarifs doivent être saisis uniquement après validation des textes légaux applicables.
- Ne pas activer le paiement Wave/Orange Money avant obtention des contrats marchands et intégration des API/webhooks officiels.
- Ne pas considérer une redirection navigateur comme preuve de paiement : seul un webhook authentifié du prestataire peut confirmer.
- Les données de contribuables et les cartes fiscales ne doivent jamais être publiques.
- Le compte Supabase propriétaire du projet doit être protégé par MFA et accès restreint.

## Limites de cette V1

Les fondations de données, les rôles, RLS, le registre, les affectations, les imports en attente,
l'encaissement physique transactionnel, l'audit et une interface de connexion/tableau de bord
sont préparés. Les modules avancés (workflow complet d'import Excel, cartographie SIG,
rapports PDF, clôture/rapprochement, dépenses/comptabilité, Wave, Orange Money et services
administratifs) restent à construire et à tester en lots séparés. Aucun tarif légal ni liste
des 59 villages n'est inventé.

## Déploiement

Voir `README_CLOUDFLARE.md`, `docs/INSTALLATION.md` et `docs/PLAN_TESTS.md`.


## Livraisons récentes
- Phase 4 : `docs/LIVRAISON_4_GESTION_AGENTS.md`
- Procédure autonome pour catégories et tarifs (exemples fictifs uniquement) : `docs/PROCEDURE_FUTURE_CATEGORIES_TARIFS_EXEMPLE_FICTIF.md`
- Migration additive phase 4 : `supabase/migrations/0002_phase4_agent_management.sql`
