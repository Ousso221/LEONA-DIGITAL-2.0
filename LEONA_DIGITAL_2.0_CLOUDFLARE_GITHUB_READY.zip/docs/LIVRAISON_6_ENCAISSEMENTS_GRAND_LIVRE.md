# LÉONA DIGITAL 2.0 — Phase 6 : encaissements, reçus et grand livre

## Contenu de cette livraison

- Formulaire d'encaissement physique dans l'espace Finances, visible uniquement avec `payments.collect`.
- Sélection des évaluations ayant un solde positif à partir de `v_assessment_balances`.
- Enregistrement par RPC `record_physical_payment` : la base vérifie la permission, la commune, l'affectation du collecteur, le mode de paiement et le solde restant, puis crée l'écriture et le numéro de reçu dans une même transaction.
- Grand livre chronologique à partir de `v_financial_ledger`.
- Impression d'un reçu consultable depuis une session authentifiée. Le reçu porte un numéro séquentiel, le contribuable, le montant, le mode et la période. Le document rappelle les limites légales de sa valeur.
- Contrepassation par RPC `reverse_payment`, avec motif obligatoire d'au moins 10 caractères. L'écriture initiale est conservée ; la contrepassation crée une nouvelle écriture liée.
- Permission dédiée `payments.reverse` attribuée au receveur municipal uniquement. Le maire et le contrôleur disposent de droits de consultation, pas d'annulation.

## Installation

1. Conserver une copie de sauvegarde du projet et de la base.
2. Déployer l'archive complète sur Netlify Drop.
3. Dans Supabase > SQL Editor, ouvrir un nouvel onglet et exécuter une seule fois `supabase/migrations/0004_phase6_encaissements_grand_livre.sql`.
4. Ne pas réexécuter `0001_initial.sql`, `0002_phase4_agent_management.sql` ou `0003_phase5_fiscalite.sql`.
5. Vérifier ensuite les rôles et effectuer les tests de recette ci-dessous.

La migration est additive : elle ajoute des permissions, des index, deux vues et remplace la fonction de contrepassation. Elle ne supprime aucune table, colonne, donnée, politique ou écriture.

## Permissions attendues

| Rôle | Consulter le grand livre | Encaisser | Contrepasser |
|---|---:|---:|---:|
| Maire | Oui | Non | Non |
| Secrétaire général | Selon permissions existantes, sans encaissement par défaut | Non | Non |
| Receveur municipal | Oui | Oui | Oui |
| Contrôleur | Oui | Non | Non |
| Agent de recensement | Non | Non | Non |
| Agent de collecte | Oui, dans le périmètre RLS et affectations | Oui, selon affectation | Non |
| Administrateur technique | Non par défaut | Non | Non |

## Tests obligatoires avant usage réel

1. Connexion comme agent de collecte affecté à un village : vérifier que les évaluations hors affectation ne peuvent pas être encaissées.
2. Tenter un montant supérieur au solde : la base doit refuser avec `amount_exceeds_balance`.
3. Encaisser une somme partielle en espèces : un paiement et un reçu doivent apparaître.
4. Vérifier que le solde diminue du montant encaissé.
5. Se connecter comme secrétaire général et contrôleur : aucun bouton d'encaissement ni de contrepassation ne doit être disponible.
6. Se connecter comme receveur municipal : vérifier l'encaissement et la contrepassation avec un motif de 10 caractères minimum.
7. Vérifier qu'une contrepassation ne supprime pas le reçu ni l'écriture initiale ; le reçu initial doit apparaître comme ANNULÉE.
8. Vérifier que le maire peut consulter sans encaisser ni contrepasser.
9. Vérifier qu'un compte d'une autre commune ou anonyme ne peut pas lire ces vues.

## Limites connues

- Cette version enregistre les encaissements physiques : espèces, chèque et virement bancaire. Les modes Wave et Orange Money existent dans l'enum historique, mais aucun rapprochement API ou webhook de paiement mobile n'est implémenté. Ne pas sélectionner ni déclarer ces paiements comme confirmés via cette interface.
- La génération est imprimable depuis le navigateur ; la conformité du reçu (mentions réglementaires, signatures, cachet, numérotation officielle et modèle approuvé) doit être validée par la commune avant usage administratif réel.
- Les tests statiques de code ne remplacent pas les tests intégrés avec les vrais comptes et données de Léona.
- Les états de recettes avancés par village, période et catégorie feront l'objet de l'étape 6.2 après validation des encaissements et du grand livre.
