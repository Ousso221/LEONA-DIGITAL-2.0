# LÉONA DIGITAL 2.0 — Phase 9.6
## Approbation des catégories fiscales par le maire

### Objectif
Séparer la préparation des catégories fiscales de leur activation. Le secrétaire général prépare les catégories ; le maire les approuve et les active.

### Changements
- Ajout de la permission `categories.approve` au rôle `maire`.
- Ajout du déclencheur `categories_activation_guard` : une insertion active ou un changement du statut `active` exige la permission d'approbation.
- Ajout de la fonction sécurisée `activate_tax_category_by_mayor(uuid)`, qui contrôle la permission, la commune, le statut et la référence juridique avant activation.
- Le déclencheur `audit_tax_categories` existant conserve la trace de la modification dans `audit_logs`.
- Le formulaire du secrétaire général enregistre toujours les nouvelles catégories avec `active = false`.
- L'espace fiscal affiche au maire un bouton « Approuver et activer » pour chaque catégorie inactive.

### Fichiers modifiés
- `public/espace.html`
- `public/assets/js/fiscalite.js`
- `supabase/migrations/0005_phase9_6_approbation_categories.sql`

### Préservation
Aucune catégorie, aucun tarif, contribuable, paiement, reçu, compte ou autre table n'a été supprimé. Les 47 catégories existantes restent inactives jusqu'à une décision explicite du maire.

### Vérifications effectuées
- Syntaxe JavaScript vérifiée avec `node --check`.
- Les contrôles SQL de la migration ont confirmé la présence de la permission, du déclencheur et de la fonction.
- Un test réel de connexion et d'activation avec les comptes maire et secrétaire général reste à effectuer dans l'environnement déployé.

### Déploiement
Le fichier SQL de migration est conservé dans le dépôt pour traçabilité. La migration a déjà été exécutée manuellement dans Supabase ; ne pas la relancer sans raison. Déployer les fichiers frontend de cette archive sur Netlify, puis tester avec les deux comptes.
