# Installation Supabase — LÉONA DIGITAL 2.0

## Prérequis
Ce paquet cible un projet Supabase neuf dont le schéma `public` ne contient pas encore les tables métier. Le résultat « No rows returned » est cohérent avec ce prérequis.

## 1. Installer le schéma
1. Ouvrir Supabase > SQL Editor > New query.
2. Ouvrir `supabase/migrations/0001_initial.sql`.
3. Copier tout le contenu dans SQL Editor.
4. Cliquer sur Run une seule fois.
5. Si une erreur apparaît, arrêter et transmettre le message complet. Ne pas relancer en boucle.

## 2. Créer le compte administrateur Auth
1. Ouvrir Supabase > Authentication > Users.
2. Cliquer sur Add user / Create new user.
3. Saisir une adresse e-mail contrôlée par l'administrateur et définir un mot de passe fort.
4. Valider/confirmer l'adresse si l'option est proposée.
5. Copier l'UUID de l'utilisateur.

Ne jamais envoyer le mot de passe dans le chat. Ne jamais placer une clé service_role dans le navigateur.

## 3. Attribuer le rôle administrateur
1. Ouvrir `supabase/ADMIN_BOOTSTRAP.sql`.
2. Remplacer `REMPLACER-PAR-UUID-AUTH` par l'UUID exact.
3. Modifier le nom si nécessaire.
4. Exécuter le script dans SQL Editor.
5. Le résultat final doit afficher une ligne avec `administrateur_technique` et `active = true`.

## 4. Vérifier les tables et le profil
```sql
select table_name from information_schema.tables
where table_schema='public' and table_type='BASE TABLE'
order by table_name;
```
```sql
select p.id, u.email, p.full_name, p.role, p.active
from public.profiles p join auth.users u on u.id=p.id;
```

## 5. Étapes suivantes
- Brancher et tester le formulaire de connexion de l'application.
- Relier l'espace agents aux permissions et aux vraies données.
- Construire les écrans de gestion des agents, villages et contribuables.
- Ajouter les imports avec validation/approbation.
- Configurer fiscalité, créances, encaissements et reçus.
- Ajouter les rapports, exports et cartographie.
- Intégrer Wave/Orange Money uniquement après obtention des accès marchands et validation de leurs API.

Les 59 villages, leurs codes et les tarifs officiels ne sont pas préremplis : ils doivent être vérifiés avant import. Le script crée les primitives de base mais ne constitue pas une certification de sécurité ni une preuve de fonctionnement en production. Des tests RLS avec plusieurs comptes sont obligatoires avant toute donnée réelle.
