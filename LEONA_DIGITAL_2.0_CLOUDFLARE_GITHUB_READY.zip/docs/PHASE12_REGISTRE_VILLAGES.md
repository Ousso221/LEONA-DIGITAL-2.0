# Phase 12 — Registre des contribuables organisé par village

## Modifications de l'interface
- Le registre exige désormais la sélection d'un village avant toute consultation.
- La recherche s'effectue à l'intérieur du village sélectionné.
- Le tri est disponible par nom croissant/décroissant, code et date de recensement.
- Le titre du registre rappelle le village sélectionné et le nombre de fiches affichées.
- Les colonnes utilisent des couleurs pastel distinctes pour faciliter la lecture, y compris sur mobile avec défilement horizontal du tableau.
- Le filtre du registre est indépendant du village facultatif proposé dans le formulaire de recensement.

## Données et sécurité
- Aucun changement de schéma SQL n'est nécessaire pour cette partie.
- La lecture continue d'utiliser la session Supabase et les politiques RLS existantes.
- Le filtre village est appliqué côté requête avec `village_id` ; il ne remplace jamais les contrôles RLS.
- La requête affiche jusqu'à 1 000 lignes par village ; une recherche permet de réduire la liste.

## À poursuivre dans la phase 12
Le workflow d'importation CSV/Excel, prévisualisation, détection des doublons, validation et intégration contrôlée reste à réaliser et à tester séparément.
