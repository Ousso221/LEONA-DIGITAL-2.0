# LÉONA DIGITAL 2.0 — Livraison 2 : registre territorial

## Objectif

Cette livraison transforme la rubrique « Villages » en premier module de gestion réellement connecté à Supabase pour la Commune de Léona.

## Fonctionnalités

- Lecture des villages rattachés à l'identifiant communal de Léona.
- Compteur des villages visibles.
- Recherche locale par nom ou code officiel.
- Création d'un village avec nom obligatoire et code officiel facultatif.
- Modification du nom et du code officiel.
- Marquage « vérifié / à vérifier ».
- Actualisation du registre.
- Formulaire de gestion affiché uniquement si le rôle possède `settings.manage`.
- Toutes les écritures restent soumises aux politiques RLS existantes de Supabase.

## Tables et règles utilisées

- Table : `public.villages`.
- Identifiant de la commune de Léona : `4ff58202-4615-4d1f-8412-d06fdc0967ad`.
- Colonnes utilisées : `id`, `commune_id`, `official_code`, `name`, `verified`, `created_at`.
- Lecture : politique `villages_read`.
- Création, modification et vérification : politique `villages_admin`, qui exige `settings.manage` et le rattachement à la commune courante.

Aucune politique RLS n'est modifiée par cette livraison. Aucun village fictif n'est inséré.

## Installation

1. Conserver une copie de sauvegarde du projet actuellement déployé.
2. Extraire cette archive dans un nouveau dossier de test.
3. Déployer le contenu du dossier `public` avec la configuration Netlify existante, en conservant les variables d'environnement déjà configurées.
4. Se connecter avec le compte administrateur technique.
5. Ouvrir « Villages » et créer uniquement des villages dont le nom/code a été confirmé par la commune.
6. Vérifier qu'un village créé apparaît dans le registre et que le compteur augmente.
7. Tester la modification et le changement du statut de vérification.

## Limites connues

- Cette livraison ne crée pas encore de données de villages.
- Elle ne gère pas encore les géométries GeoJSON ni les coordonnées cartographiques.
- Elle ne supprime pas les villages : la suppression est volontairement absente afin de préserver l'intégrité des contribuables et des affectations d'agents.
- Le module contribuables reste en lecture seule dans cette livraison.

## Contrôles techniques effectués

- Vérification syntaxique JavaScript avec `node --check`.
- Vérification de l'intégrité de l'archive ZIP.
- Pas de test d'écriture sur le projet Supabase réel : celui-ci doit être réalisé depuis le navigateur avec le compte connecté.
