# Livraison 4 — Gestion des agents et affectations

## Contenu livré
- Création d’un compte par invitation e-mail via une fonction Netlify côté serveur.
- Vérification du JWT Supabase, du profil actif, du rattachement à la Commune de Léona et des permissions `users.manage` + `agents.manage`.
- Rôles attribuables depuis l’écran : maire, secrétaire général, receveur municipal, contrôleur, agent de recensement, agent de collecte. Le rôle `administrateur_technique` est volontairement exclu de la création ordinaire et protégé contre la modification depuis cette interface.
- Modification du nom, du rôle et de l’état actif/inactif par le serveur. Le compte de l’administrateur connecté ne peut pas être modifié depuis cet écran.
- Affectation des agents de terrain aux villages, mission recensement/collecte/les deux, dates, historique et clôture.
- Contrôle SQL avant chaque insertion/modification d’affectation : agent actif, rôle de terrain, village et agent rattachés à la même commune.
- Journalisation des invitations et modifications de profils dans `audit_logs`. Les affectations sont déjà couvertes par le déclencheur d’audit du schéma initial.

## Installation
1. Faire une sauvegarde Supabase.
2. Dans Supabase SQL Editor, exécuter une seule fois `supabase/migrations/0002_phase4_agent_management.sql`. Ce script est additif et ne recrée pas les tables existantes.
3. Dans Netlify > Site configuration > Environment variables, définir :
   - `SUPABASE_URL` : URL du projet Supabase.
   - `SUPABASE_ANON_KEY` : clé publique/anon du projet (variable serveur utilisée pour valider le JWT).
   - `SUPABASE_SERVICE_ROLE_KEY` : clé secrète service_role, serveur uniquement. Ne jamais la mettre dans `public/`, dans Git public ou dans `config.js`.
   - `URL` : URL HTTPS du site Netlify de production, par exemple `https://votre-site.netlify.app`.
4. Déployer l’ensemble du dossier du projet sur Netlify.
5. Vérifier que l’envoi d’e-mails Supabase est configuré (SMTP du projet ou fournisseur e-mail). Sans service e-mail opérationnel, les invitations ne seront pas délivrées.
6. Dans Supabase Authentication > URL Configuration, ajouter l’URL de redirection exacte du site (et la route `/connexion`) aux Redirect URLs autorisées.
7. Se connecter avec l’administrateur technique existant, ouvrir Administration, puis créer un compte de test avec une adresse e-mail que vous contrôlez.
8. Vérifier la réception du message d’invitation, définir le mot de passe, se connecter avec le nouvel utilisateur, puis vérifier que ses modules correspondent à son rôle.
9. Créer un village de test réel ou utiliser un village déjà enregistré, puis affecter l’agent. Ne pas inventer un village officiel pour les données de production.

## Sécurité et limites
- Le navigateur ne reçoit jamais la clé `service_role`.
- Le mot de passe n’est ni demandé, ni généré, ni stocké par l’interface municipale. Supabase envoie une invitation.
- Seul un profil actif ayant simultanément `users.manage` et `agents.manage` peut utiliser la fonction serveur. Dans la configuration connue, cela correspond à l’administrateur technique.
- L’interface ne permet pas de créer un autre administrateur technique ni de modifier le compte technique connecté.
- Une affectation « recensement et collecte » est une information d’organisation. Elle ne modifie pas les permissions du rôle : un agent de recensement ne reçoit pas les droits d’encaissement parce qu’il est affecté à une mission mixte.
- Les comptes désactivés ne peuvent pas être affectés. Une désactivation du profil bloque l’accès applicatif lors du contrôle de profil. Pour une révocation complète et immédiate des sessions déjà ouvertes, désactiver aussi l’utilisateur dans Supabase Auth depuis une procédure administrateur sécurisée (étape à automatiser dans une future version).
- Prévoir une protection anti-abus/rate limiting de la fonction Netlify avant exposition publique à grande échelle.

## Dépannage
- `service_unavailable` : vérifier les variables Netlify, redéployer après toute modification et consulter les logs de fonction.
- `forbidden` : vérifier que le compte est actif, rattaché à la commune de Léona et possède les deux permissions requises.
- invitation non reçue : vérifier l’adresse, les réglages SMTP de Supabase et les courriers indésirables.
- affectation refusée : vérifier que le profil est actif et a le rôle `agent_recensement` ou `agent_collecte`, et que le village est dans la commune de Léona.

## Tests de recette à effectuer
- Un compte administrateur technique peut inviter un agent.
- Un agent invité peut définir son mot de passe et se connecter.
- Un agent de recensement voit les modules permis par son rôle, mais pas les encaissements.
- Un agent de collecte voit les modules permis par son rôle, mais n’obtient pas les droits de gestion des utilisateurs.
- Un compte sans `users.manage` et `agents.manage` reçoit un refus serveur même s’il tente d’appeler directement la fonction.
- Un profil désactivé ne peut plus ouvrir l’espace municipal après une nouvelle authentification.
- Une affectation vers un village d’une autre commune, un profil inactif ou un responsable non-agent est rejetée par le déclencheur SQL.
- La création/modification de compte apparaît dans `audit_logs`.
