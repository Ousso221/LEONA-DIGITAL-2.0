# Plan de tests minimum avant production

## Base de données
1. Appliquer la migration sur un projet Supabase vierge.
2. Vérifier que chaque table sensible a RLS activée.
3. Tester chaque rôle avec un compte distinct.
4. Vérifier qu'un agent ne lit pas les données d'une autre commune ni les affectations d'un autre agent.
5. Vérifier qu'un utilisateur sans permission ne peut pas appeler `record_physical_payment`.
6. Vérifier qu'un paiement supérieur au solde est refusé.
7. Lancer deux paiements simultanés sur la même créance : le total ne doit jamais dépasser le dû.
8. Vérifier qu'un paiement ou une quittance ne peut pas être modifié/supprimé.
9. Vérifier que l'audit enregistre INSERT/UPDATE/DELETE et que les utilisateurs applicatifs ne peuvent pas l'altérer.

## Interface
1. Connexion valide/invalide.
2. Session absente redirigée vers connexion.
3. Déconnexion et invalidation de session.
4. Modules affichés selon les permissions effectives.
5. Mobile, clavier, lecteur d'écran et erreurs réseau.

## Imports (à développer)
- CSV/XLSX valide, colonnes manquantes, types invalides, doublons, fichier volumineux.
- Lot soumis non intégré au registre avant validation.
- Rejet avec motif obligatoire.
- Validation atomique et traçable.

## Paiements en ligne (à développer)
- Paiement accepté, refusé, annulé, expiré.
- Webhook signé invalide, répétition de webhook, montant/devise/référence incorrects.
- Aucun paiement enregistré avant confirmation serveur vérifiée.

## Critère de sortie
Aucune donnée réelle, aucun paiement réel et aucun déploiement public tant que les tests ne sont pas passés et que les règles/tarifs locaux n'ont pas été validés par les autorités compétentes.
