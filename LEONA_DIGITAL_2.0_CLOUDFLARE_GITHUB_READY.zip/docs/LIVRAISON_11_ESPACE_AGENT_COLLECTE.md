# LÉONA DIGITAL 2.0 — Phase 11 : espace Agent de collecte

## Contenu livré

- Tableau de bord dédié au rôle `agent_collecte`, avec raccourcis vers le registre des contribuables, les encaissements et les opérations.
- Libellés de navigation adaptés : « Mes encaissements » et « Mes encaissements et reçus ».
- Formulaire d'encaissement physique existant réutilisé : sélection d'une évaluation avec solde, montant et mode de paiement autorisé, puis appel de `record_physical_payment`.
- Consultation et impression des reçus disponibles dans le grand livre.
- Les droits d'encaissement restent déterminés par `payments.collect` et validés côté Supabase. L'interface ne donne aucun droit d'annulation, d'approbation de tarif, de gestion des catégories ou des utilisateurs.
- La politique RLS `taxpayers_read` est resserrée pour que l'agent de collecte ne consulte que les contribuables rattachés aux villages où il possède une affectation active de type `collecte` ou `both`.
- Les autres rôles conservent la règle de lecture existante : commune courante et permission `taxpayers.read`.

## Déploiement

1. Faire une sauvegarde Supabase avant toute migration.
2. Dans Supabase SQL Editor, exécuter une seule fois le script complet : `supabase/migrations/0007_phase11_espace_agent_collecte.sql`.
3. Déployer le contenu complet du dossier `leona4` sur Netlify, en conservant les variables d'environnement existantes.
4. Ne pas réexécuter les migrations `0001` à `0006`.
5. Ne jamais exposer `SUPABASE_SERVICE_ROLE_KEY` dans le navigateur.

## Tests de recette

1. Se connecter avec un compte `agent_collecte` actif et affecté à un village en mission `collecte` ou `both`.
2. Vérifier que le tableau de bord dédié apparaît et que « Mes encaissements » ouvre le module financier.
3. Vérifier que le registre ne retourne que les contribuables des villages affectés activement.
4. Vérifier qu'une évaluation non soldée d'un village affecté apparaît dans le formulaire d'encaissement.
5. Vérifier qu'une évaluation d'un village non affecté ne peut pas être consultée/encaissée par cet agent.
6. Faire les essais d'encaissement uniquement en environnement de test ou avec une opération réelle autorisée ; ne pas créer de faux paiements en production.
7. Vérifier qu'un reçu confirmé peut être consulté et imprimé.
8. Vérifier qu'aucune action de contrepassation, de modification tarifaire ou d'administration n'est disponible.
9. Tester avec un autre rôle que `agent_collecte` que les règles de lecture antérieures restent inchangées.

## Limites

- Les opérations visibles restent limitées aux données permises par les politiques RLS et aux 200 écritures les plus récentes chargées dans le grand livre.
- Le module utilise les modes physiques déjà prévus par la base : espèces, chèque et virement bancaire. Wave et Orange Money ne sont pas activés par cette livraison.
- Cette livraison ne crée aucun compte agent et n'affecte aucun village automatiquement. Les comptes et affectations sont gérés depuis Administration par un profil habilité.
