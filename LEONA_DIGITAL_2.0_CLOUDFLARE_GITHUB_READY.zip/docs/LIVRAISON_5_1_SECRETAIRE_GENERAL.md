# LÉONA DIGITAL 2.0 — Livraison 5.1 : espace du Secrétaire général

## Objectif
Cette livraison améliore l'interface métier du Secrétaire général à partir du module Fiscalité Phase 5 déjà installé. Elle ne modifie pas le schéma PostgreSQL et ne crée aucune donnée fiscale.

## Nouveautés
1. Synthèse personnelle affichant le nombre de catégories actives, de fiches contribuables en attente, de tarifs en attente d'approbation et d'évaluations enregistrées. Les nombres sont lus dans Supabase ; ils ne sont pas simulés.
2. Recherche instantanée dans les fiches de contribuables à classifier, par code, nom ou activité.
3. Filtre des contribuables par statut : tous, en attente, validés ou inactifs.
4. Lorsqu'un tarif approuvé est choisi pour une évaluation, la liste des contribuables est limitée aux contribuables validés qui appartiennent à la catégorie de ce tarif. Le contrôle serveur `create_assessment` reste l'autorité finale.
5. Les permissions existantes restent appliquées. Le Secrétaire général prépare les catégories et tarifs, valide et classe les contribuables, et crée les évaluations. Il ne peut pas approuver un tarif.

## Installation
Cette archive contient le projet complet construit à partir de la livraison Phase 4, avec les fichiers Phase 5 et 5.1 intégrés.

1. Conserver une copie de la version actuelle du site.
2. Déployer le contenu de cette archive complète sur Netlify Drop.
3. Ne pas modifier les variables d'environnement Netlify déjà corrigées.
4. **Ne pas réexécuter `0001_initial.sql`, `0002_phase4_agent_management.sql` ni `0003_phase5_fiscalite.sql`** : la base existante a déjà reçu ces migrations et les corrections de permissions déjà validées.
5. Se connecter avec un véritable compte `secretaire_general` activé.

## Tests métier à effectuer avec le Secrétaire général
- Le menu Fiscalité et les quatre indicateurs de synthèse s'affichent.
- La recherche et le filtre de statut réduisent la liste des contribuables.
- Une fiche en attente peut être validée après vérification réelle.
- Un contribuable peut être classé dans une catégorie active appropriée.
- Un tarif peut être créé comme brouillon avec sa référence juridique et sa période.
- Le Secrétaire général ne voit aucun bouton d'approbation et ne peut pas appeler la fonction d'approbation avec ses droits.
- Dans la création d'évaluation, sélectionner un tarif approuvé filtre les contribuables à la catégorie correspondante.
- Le montant définitif est calculé par Supabase, pas par le navigateur.

## Précautions
- Ne pas saisir de catégorie, montant, tarif ou référence juridique fictifs dans la base réelle.
- Les indicateurs affichent `—` lorsqu'une lecture est refusée ; vérifier alors les journaux et permissions plutôt que de supposer une valeur nulle.
- Aucun encaissement ni reçu n'est ajouté : ces fonctions relèvent de la Phase 6.
- Aucun droit fiscal n'est accordé à l'administrateur technique.
