# Livraison 1 — Socle de l'espace professionnel

Cette livraison conserve les fichiers et la structure du projet d'origine.
Seuls les fichiers suivants ont été remplacés :
- `public/espace.html`
- `public/assets/css/app.css`
- `public/assets/js/space.js`

Fonctions présentes :
- vérification de la session Supabase ;
- lecture du profil actif ;
- lecture des permissions du rôle ;
- navigation selon les permissions ;
- tableau de bord avec compteurs Supabase soumis aux RLS ;
- consultation en lecture seule des villages ;
- consultation en lecture seule du registre des contribuables ;
- consultation en lecture seule des paiements ;
- consultation en lecture seule du journal d'audit.

Limites :
- aucun formulaire de création/modification n'est activé ;
- aucune opération financière n'est créée depuis l'interface ;
- les modules non développés ne sont pas simulés ;
- la sécurité dépend toujours des politiques RLS et des autorisations PostgreSQL ;
- les tests doivent être réalisés dans Supabase avec plusieurs comptes avant toute utilisation réelle.

Installation :
1. Sauvegarder le dossier local actuel.
2. Extraire cette archive dans un nouveau dossier de test.
3. Comparer les trois fichiers listés ci-dessus.
4. Remplacer ces trois fichiers dans une copie de travail du projet, pas dans l'unique copie.
5. Déployer sur un site de préproduction Netlify ou lancer le serveur local configuré.
6. Tester les comptes et les rôles sans utiliser de données réelles.
