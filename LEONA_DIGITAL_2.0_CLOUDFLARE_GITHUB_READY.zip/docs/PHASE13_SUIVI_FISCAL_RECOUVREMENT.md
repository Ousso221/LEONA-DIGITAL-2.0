# LÉONA DIGITAL 2.0 — Phase 13 : suivi fiscal et recouvrement

## Fonctionnalités livrées côté interface
- Vue dédiée « Suivi fiscal » pour les profils disposant d’au moins une permission de lecture des évaluations ou finances.
- Consultation des évaluations et soldes depuis `v_assessment_balances`, vue existante de la Phase 6 en `security_invoker`.
- Filtrage par village, situation (solde restant / soldée), période et recherche contribuable.
- Tri par village/nom, solde décroissant, nom ou période récente.
- Indicateurs des montants évalués, payés nets et soldes restants sur les lignes chargées.
- Export CSV UTF-8 avec séparateur point-virgule, ouvrable dans Excel.
- Impression navigateur et enregistrement PDF.

## Sécurité et limites
- Aucune nouvelle table, fonction ou permission n’est créée. Aucune migration SQL n’est nécessaire : la vue `v_assessment_balances` existe déjà dans la migration de Phase 6.
- La vue est `security_invoker=true` : les politiques RLS des tables sous-jacentes continuent de s’appliquer.
- Les agents de collecte ne voient que les lignes autorisées par leurs affectations actives et les politiques RLS existantes. Le filtre des villages est construit à partir des villages présents dans les résultats accessibles.
- Le chargement de l’interface est limité aux 1 000 évaluations les plus récentes visibles. Les totaux affichés portent donc sur ces lignes, et non nécessairement sur l’intégralité de l’historique si celui-ci dépasse cette limite.
- Les dates filtrent les périodes fiscales ; aucune échéance de paiement légale ou pénalité n’est déduite.
- Le CSV est un format compatible Excel, pas un classeur `.xlsx` natif.

## Déploiement
1. Sauvegarder le projet et Supabase.
2. Déployer le contenu du ZIP sur Netlify en conservant les variables d’environnement.
3. Tester avec un compte de lecture (Secrétaire général / Contrôleur) puis un agent de collecte affecté à un village.
4. Vérifier que les soldes affichés correspondent aux évaluations et écritures connues.

Aucun script SQL n’est requis pour cette phase.
