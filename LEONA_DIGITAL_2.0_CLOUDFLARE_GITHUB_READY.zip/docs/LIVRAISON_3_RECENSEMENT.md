# LÉONA DIGITAL 2.0 — Livraison 3 : recensement initial

## Ajouts
- Formulaire de création de fiche contribuable pour les rôles disposant de `recensement.manage` ou `imports.review`.
- Attribution du créateur via l'identifiant de session Supabase (`created_by`).
- Rattachement facultatif à un village existant de la Commune de Léona.
- Champs téléphone, activité, catégorie fiscale descriptive, repère local et GPS.
- Validation des coordonnées et des champs obligatoires côté navigateur ; les contraintes PostgreSQL et RLS restent la protection finale.
- Statut initial `pending`, conforme à l'enum existant.
- Détection de doublon sur la contrainte unique existante (commune_id, taxpayer_code).
- Liste et recherche des contribuables conservées.

## Sécurité et limites
- Aucun changement SQL, aucune migration et aucune modification des permissions.
- L'administrateur technique actuel ne possède pas `recensement.manage` ni `imports.review` : il pourra consulter selon ses droits, mais ne pourra pas créer de contribuable. C'est intentionnel ; utiliser un compte agent_recensement actif pour saisir les fiches.
- Le code contribuable doit être attribué selon la nomenclature officiellement décidée par la Commune. Aucun code automatique arbitraire n'est généré.
- La catégorie fiscale est un libellé descriptif uniquement ; aucune évaluation ni dette n'est calculée ici.
- Les champs GeoJSON des villages ne sont pas modifiés.
- Les tests d'écriture réels doivent être effectués avec un compte autorisé dans un environnement de test avant déploiement général.

## Installation
1. Sauvegarder le dossier actuellement déployé.
2. Extraire cette archive dans un nouveau dossier.
3. Déployer le contenu du dossier `public` via Netlify, en conservant les variables et fonctions existantes.
4. Tester la connexion avec un compte `agent_recensement` autorisé.
5. Vérifier l'enregistrement d'une fiche de test autorisée, puis contrôler le résultat dans Supabase.
6. Ne pas exécuter `0001_initial.sql` sur la base déjà existante.
