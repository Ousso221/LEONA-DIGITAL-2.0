# LÉONA DIGITAL 2.0 — Phase 12 : Importation Excel / CSV

## Fonctionnement

- L'agent de recensement disposant de `imports.create` ouvre « Imports Excel / CSV ».
- Il charge un fichier `.xlsx`, `.xls` ou `.csv` (5 Mo maximum, 1 000 lignes maximum).
- Le système lit la première feuille, prévisualise les lignes et vérifie les champs requis.
- Le fichier doit contenir un code contribuable, un prénom, un nom et un village existant de la Commune de Léona.
- Les colonnes facultatives acceptées comprennent téléphone, activité, catégorie fiscale indicative, localisation, latitude et longitude.
- La soumission crée un lot `submitted` et des lignes `import_rows`; les contrôles SQL vérifient à nouveau les champs, le village et les doublons.
- Seul le Secrétaire général disposant de `imports.review` peut approuver ou rejeter un lot depuis l'espace de revue. Un rejet exige un motif d'au moins cinq caractères.
- L'approbation intègre les contribuables au statut `pending`. Elle ne valide pas la classification fiscale et ne crée aucune évaluation.

## En-têtes recommandés

`taxpayer_code`, `first_name`, `last_name`, `village`.

Alias français reconnus : `code_contribuable`, `code`, `prenom`, `prenoms`, `nom`, `nom_famille`, `village`, `nom_village`, `code_village`, `telephone`, `tel`, `activite`, `categorie_fiscale`, `localisation`, `adresse`, `quartier`, `latitude`, `longitude`.

La valeur de `village` doit correspondre exactement au nom ou au code officiel d'un village déjà enregistré. Le champ `village_id` peut contenir l'UUID du village.

## Installation Supabase

Exécuter une seule fois le script `supabase/migrations/0008_phase12_imports_csv_excel.sql` dans Supabase SQL Editor. Le script ajoute deux fonctions RPC sécurisées et ne supprime aucune table ni donnée.

La bibliothèque SheetJS est chargée depuis jsDelivr pour lire Excel et CSV dans le navigateur. Une connexion Internet est donc nécessaire au chargement de cette bibliothèque.

## Limites / tests

- Le traitement porte sur la première feuille du classeur.
- Maximum : 1 000 lignes et 5 Mo par fichier.
- Les lots comportant une anomalie ne peuvent pas être approuvés.
- Le système refait le contrôle des doublons au moment de l'approbation.
- Tester d'abord avec un petit fichier non sensible et des codes de test, puis vérifier le statut `pending` dans le registre.
- Les contrôles de syntaxe locaux ne remplacent pas un test réel dans Supabase et Netlify.
