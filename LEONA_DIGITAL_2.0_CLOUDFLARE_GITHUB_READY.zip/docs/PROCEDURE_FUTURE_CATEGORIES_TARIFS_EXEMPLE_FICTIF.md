# Procédure de référence — catégories fiscales et tarifs (exemples fictifs uniquement)

> **AVERTISSEMENT MAJEUR :** toutes les données chiffrées et tous les libellés ci-dessous sont des EXEMPLES FICTIFS de démonstration. Ils ne constituent ni un tarif officiel, ni une décision municipale, ni une base légale applicable à Léona. Ne les saisissez jamais comme tarifs réels. Les valeurs réelles devront être tirées des textes et délibérations officiellement adoptés et vérifiés.

## 1. Dossier à préparer avant toute saisie
Pour chaque catégorie, réunir :
1. le nom officiel de la catégorie ;
2. le code interne unique ;
3. la population ou l’activité concernée et les critères objectifs de classement ;
4. la référence juridique exacte (texte, numéro, date, article) ;
5. la délibération ou décision municipale, sa date, son numéro et sa preuve d’adoption/approbation si nécessaire ;
6. le tarif voté, la devise et l’unité de calcul (par an, par mois, par m², par activité, etc.) ;
7. la date de début d’application et, si prévue, la date de fin ;
8. le nom/fonction du responsable qui vérifie le dossier et celui de l’autorité qui approuve.

Ne jamais remplacer une référence juridique absente par « selon la mairie » ou par une référence inventée. Si la base légale ou la décision manque, garder le dossier en préparation et ne pas activer le tarif.

## 2. Exemple fictif de catégories
| Code fictif | Libellé fictif | Critère fictif | Référence fictive |
|---|---|---|---|
| DEMO-CAT-001 | Activité commerciale de démonstration | Exemple de commerce de proximité | **FICTIF — Délibération DEMO-001** |
| DEMO-CAT-002 | Activité artisanale de démonstration | Exemple d’atelier artisanal | **FICTIF — Délibération DEMO-002** |
| DEMO-CAT-003 | Occupation temporaire de démonstration | Exemple d’occupation temporaire | **FICTIF — Délibération DEMO-003** |

Ces libellés ne préjugent pas des catégories que la commune a légalement le droit de taxer.

## 3. Exemple fictif de tarifs
| Catégorie | Montant fictif | Unité fictive | Validité fictive | Statut
|---|---:|---|---|---|
| DEMO-CAT-001 | 5 000 FCFA | par an | 01/01/2027 au 31/12/2027 | Brouillon non approuvé |
| DEMO-CAT-002 | 3 000 FCFA | par an | 01/01/2027 au 31/12/2027 | Brouillon non approuvé |
| DEMO-CAT-003 | 500 FCFA | par jour | 01/01/2027 au 31/12/2027 | Brouillon non approuvé |

Les montants sont volontairement fictifs. Ne pas les utiliser pour appeler `approve_tariff`, créer une évaluation, réclamer un paiement ou imprimer un reçu.

## 4. Procédure de saisie réelle, le jour où les documents seront disponibles
1. Ouvrir la rubrique Fiscalité de LÉONA DIGITAL.
2. Créer une catégorie avec son code, son libellé, sa description et la référence juridique complète.
3. Joindre ou archiver la copie de la délibération/décision dans le dossier documentaire municipal, avec date et numéro.
4. Relire le libellé et vérifier que le champ `legal_reference` ne contient pas une simple mention approximative.
5. Créer le tarif lié à cette catégorie : montant exact en XOF, unité de calcul, date de début et date de fin.
6. Enregistrer le tarif en brouillon. Un brouillon ne doit pas être utilisé pour calculer une dette.
7. Faire contrôler le dossier par le service compétent : cohérence juridique, unité, montant, période et population assujettie.
8. Faire approuver le tarif par la personne disposant de l’habilitation formelle, après vérification de la décision officielle. L’approbation doit enregistrer l’identité de l’approbateur et l’horodatage.
9. Vérifier dans l’historique que le tarif est approuvé et que la période de validité est correcte.
10. Seulement après approbation, créer les évaluations des contribuables concernés. Vérifier un échantillon manuellement avant tout traitement en masse.
11. Conserver le document justificatif et l’historique d’approbation. Toute modification ultérieure doit créer une nouvelle version ou un nouveau tarif avec sa nouvelle période ; ne pas écraser silencieusement un tarif déjà appliqué.

## 5. Contrôles avant activation
- [ ] Le texte juridique est identifié précisément et vérifié.
- [ ] La délibération/décision est disponible et valide.
- [ ] Le montant est identique au montant adopté.
- [ ] L’unité de calcul est sans ambiguïté.
- [ ] Les dates d’application sont correctes.
- [ ] Les règles d’exonération et les cas particuliers sont documentés.
- [ ] Le rôle de l’approbateur est vérifié.
- [ ] Le tarif est approuvé et l’approbation est auditée.
- [ ] Aucun exemple fictif n’a été copié dans les données officielles.

## 6. Tables existantes prévues dans Supabase
- `tax_categories` : catégorie, code, libellé, référence juridique, état actif.
- `tariffs` : catégorie, montant, devise, période de validité, référence et approbation.
- `assessments` : évaluation calculée pour un contribuable et une période.

Le schéma actuel prévoit `legal_reference` obligatoire et un couple `approved_by` / `approved_at`. La future phase fiscale devra aussi contrôler les droits d’écriture, l’approbation, les périodes qui se chevauchent et l’interdiction d’évaluer sur un tarif non approuvé. Ne pas exécuter de SQL d’insertion des exemples fictifs.

## 7. Procédure de reprise autonome
Le jour où les tarifs officiels seront disponibles, ouvrir ce document et préparer les informations à partir des pièces officielles. Ne pas lancer de script SQL trouvé dans un ancien échange sans vérifier qu’il correspond à la version active de la base. Utiliser l’interface fiscale livrée dans la prochaine phase, faire approuver les tarifs, puis tester avec un seul contribuable avant un éventuel traitement global.
