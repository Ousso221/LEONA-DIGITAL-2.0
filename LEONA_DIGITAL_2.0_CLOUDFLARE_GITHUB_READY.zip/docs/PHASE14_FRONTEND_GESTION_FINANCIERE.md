# LÉONA DIGITAL 2.0 — Phase 14 : intégration frontend

## Contenu
- Ajout d’un espace **Budget & trésorerie**, distinct du grand livre fiscal existant.
- Consultation des comptes et soldes, budgets, exécution budgétaire, dépenses, mouvements et rapprochements.
- Formulaires de création de compte et solde initial, entrée de trésorerie hors fiscalité, budget, ligne budgétaire, catégorie et dépense.
- Appels aux RPC sécurisées `ld14_submit_budget`, `ld14_approve_budget`, `ld14_submit_expense`, `ld14_validate_expense`, `ld14_pay_expense`, `ld14_record_inflow`, `ld14_reverse_movement`, `ld14_reconcile_account` et `ld14_set_opening_balance`.
- Affichage du module limité à `finance.read`; actions affichées selon les permissions de chaque rôle. Les contrôles serveur Supabase restent l’autorité finale.

## Séparation fiscale / trésorerie
Le module fiscal continue d'utiliser `payments`, `receipts` et `v_financial_ledger`. Le module de trésorerie utilise exclusivement les tables et vues `ld14_*`. Ne pas enregistrer une recette fiscale une seconde fois dans les mouvements manuels.

## Vérifications effectuées sur le paquet
- `node --check` sur `public/assets/js/space.js` : réussi.
- Contrôle des identifiants HTML référencés par le nouveau module : aucun identifiant manquant.
- Archive ZIP : intégrité vérifiée.

## Tests après déploiement
1. Se connecter avec les profils municipaux existants et vérifier que le menu **Budget & trésorerie** apparaît uniquement pour les profils ayant `finance.read`.
2. Vérifier les lectures et l'absence d'erreurs dans les comptes, budgets, dépenses et mouvements.
3. Vérifier les droits d'action : secrétaire général (préparation), maire (approbation), contrôleur (validation et rapprochement), receveur municipal (trésorerie et paiement).
4. N'effectuer des écritures de test que dans un environnement isolé. En production, utiliser uniquement des opérations et montants municipaux réels et autorisés.
5. Vérifier qu'un utilisateur ne peut pas approuver son propre budget ni valider sa propre dépense.

## Déploiement
Ce paquet contient le frontend issu de la livraison Phase 13, complété par le module Phase 14. Le SQL Phase 14 est déjà installé dans Supabase et n'a pas à être rejoué pour cette livraison frontend.
