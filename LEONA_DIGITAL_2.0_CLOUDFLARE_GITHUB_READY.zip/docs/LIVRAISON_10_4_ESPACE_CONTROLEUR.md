# LÉONA DIGITAL 2.0 — Phase 10.4 : Espace Contrôleur

## Objectif
Fournir au rôle `controleur` un point d'entrée clair vers les modules existants de consultation, sans créer de nouveaux droits ni de nouvelles tables.

## Fonctionnalités livrées
- Tableau de bord avec les compteurs déjà disponibles et autorisés par les permissions du profil.
- Indicateur du nombre d'événements du journal d'audit lorsque `audit.read` est attribué.
- Bloc « Espace de contrôle » visible uniquement pour le rôle `controleur`.
- Accès rapide au registre des contribuables, au grand livre financier et au journal d'audit.
- Les modules existants restent utilisés : aucune duplication de registre, de comptabilité ou de journal.
- Le formulaire d'encaissement reste masqué sans `payments.collect`.
- Le formulaire de création de contribuable reste masqué sans `recensement.manage` et l'insertion est protégée par la politique RLS corrigée en Phase 10.3.

## Sécurité
Cette livraison ne modifie aucune permission, table, vue, fonction SQL ou politique RLS. Elle s'appuie sur les permissions existantes du rôle `controleur` : `taxpayers.read`, `payments.read`, `finance.read`, `audit.read`, etc. Le contrôle réel des accès reste effectué par Supabase RLS et les vérifications déjà présentes dans `space.js`.

## Déploiement
Déployer le contenu du dossier `leona4` sur Netlify en remplacement des fichiers du site. Ne pas rejouer les migrations SQL `0001` à `0006` pour cette phase : aucune migration n'est requise.

## Tests après déploiement
1. Se connecter avec un profil `controleur` actif.
2. Vérifier la présence du bloc « Espace de contrôle » et des trois raccourcis.
3. Ouvrir le registre, les finances et le journal d'audit.
4. Vérifier que le formulaire de création de contribuable et le formulaire d'encaissement sont absents.
5. Vérifier qu'un agent de recensement conserve son formulaire de création.

Un compte contrôleur doit être créé par un administrateur habilité avant le test du profil contrôleur.
