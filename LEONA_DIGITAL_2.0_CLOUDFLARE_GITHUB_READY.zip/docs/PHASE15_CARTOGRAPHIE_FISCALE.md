# LÉONA DIGITAL 2.0 — Phase 15 : cartographie fiscale interactive

## Intégration
La Phase 15 ajoute le module **Carte fiscale** à l'espace municipal existant. Elle conserve les modules précédents et ne crée ni ne modifie aucune écriture financière.

## Fonctionnalités
- Carte Leaflet/OpenStreetMap avec marqueurs individuels et regroupement automatique des points rapprochés.
- Icône fondée sur l'activité économique (agriculture, commerce, artisanat, transport, pêche, élevage, restauration, services, etc.).
- Couleur fondée sur la situation : soldé, paiement partiel, impayé, non évalué, en attente, inactif ou données financières non accessibles.
- Filtres combinables : village, activité, nature fiscale, situation, dates et recherche textuelle.
- Fiche détaillée au clic : identité administrative, activité, localisation, GPS, situation, évaluations par période et montants lorsque la permission le permet.
- Indicateurs communaux filtrés, comparaison des villages, comparaison des activités entre villages, tableaux et graphiques.
- Export CSV et impression / PDF du rapport affiché.
- Les fiches sans GPS restent dans les statistiques et sont comptées séparément ; aucun point fictif n'est créé.

## Sources de données utilisées
- `public.taxpayers` : coordonnées `gps_lat` / `gps_lon`, activité, nature fiscale, statut et village.
- `public.villages` : nom et identifiant du village.
- `public.v_assessment_balances` : montant prévu, payé net et solde par évaluation.
- `public.tax_categories` : libellé de catégorie uniquement si le profil possède `categories.read`.

**Aucune dépendance au champ `geom_geojson` n'est introduite.** Aucune limite administrative de village n'est dessinée. Une couche officielle indépendante pourra être ajoutée ultérieurement si elle est fournie et validée dans QGIS.

## Sécurité et limites
- Le module ne contourne pas les politiques RLS. Les contribuables visibles et les évaluations visibles dépendent du compte connecté.
- Les montants et taux ne sont calculés que lorsque le profil possède `assessments.read`, permission requise par la vue de soldes.
- Les agents voient uniquement les enregistrements que les politiques RLS leur autorisent à consulter.
- Les données affichées et exportées restent soumises aux permissions de lecture du profil.
- Les fonds de carte, Leaflet, MarkerCluster et Chart.js sont chargés depuis des CDN ; une connexion Internet est nécessaire.
- Le fond cartographique est OpenStreetMap. Les points GPS proviennent exclusivement des fiches enregistrées.

## Vérification
Exécuter, si nécessaire, le script en lecture seule `supabase/diagnostics/PHASE15_CARTOGRAPHIE_LECTURE_SEULE.sql` dans l'éditeur SQL Supabase. Il vérifie les colonnes utiles et produit des agrégats de couverture GPS, d'activité et de recouvrement par village. Il ne modifie aucune donnée.

## Mise en service
Remplacer le contenu du site Netlify avec l'archive de livraison, puis se connecter avec un compte autorisé possédant `taxpayers.read`. Pour voir les montants, taux et détails de recouvrement, le profil doit également disposer de `assessments.read` et les politiques RLS doivent autoriser la lecture des données correspondantes.
