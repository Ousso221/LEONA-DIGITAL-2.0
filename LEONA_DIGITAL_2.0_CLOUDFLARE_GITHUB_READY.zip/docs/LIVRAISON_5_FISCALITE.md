# LÉONA DIGITAL 2.0 — Livraison Phase 5 : fiscalité

## 1. Périmètre livré

Cette phase ajoute à l'application :
- un référentiel de catégories fiscales (code, libellé, nature de recette, mode de recouvrement, description, référence juridique, état actif) ;
- la création de tarifs en brouillon (montant XOF, unité, période de validité, référence de décision) ;
- une approbation séparée des tarifs par le rôle `maire` ;
- le verrouillage des tarifs approuvés et la conservation de l'historique ;
- la classification des contribuables par catégorie officielle, sans effacer l’ancien champ texte ;
- la validation des fiches contribuables avant toute évaluation ;
- le calcul serveur d'une évaluation à partir d'un tarif approuvé et d'une quantité ;
- le rattachement facultatif d'une fiche de contribuable à une catégorie (`tax_category_id`), sans supprimer l'ancien champ texte `tax_category` ;
- les entrées du journal d'audit déjà déclenchées par les tables `tax_categories`, `tariffs`, `assessments` et `taxpayers`.

Aucun tarif, montant, catégorie officielle, exonération ou référence juridique n'est préchargé. Les données doivent provenir des textes et décisions effectivement applicables à la Commune de Léona.

## 2. Fichiers ajoutés ou modifiés

- `supabase/migrations/0003_phase5_fiscalite.sql` : migration additive et contrôles SQL.
- `public/espace.html` : navigation et interface Fiscalité ; choix d'une catégorie pendant le recensement.
- `public/assets/js/fiscalite.js` : gestion des catégories, classification des contribuables, validation, tarifs, approbations et évaluations.
- `docs/LIVRAISON_5_FISCALITE.md` : cette procédure.

Les fichiers de Phase 1 à Phase 4 sont conservés. La migration initiale `0001_initial.sql` ne doit jamais être rejouée sur la base déjà existante.

## 3. Répartition des permissions

| Rôle | Droits Phase 5 |
|---|---|
| Maire | Lire catégories et tarifs, approuver les tarifs, lire les évaluations |
| Secrétaire général | Créer les catégories, préparer les tarifs, classer et valider les fiches contribuables, créer les évaluations |
| Receveur municipal | Lire catégories, tarifs et évaluations ; l'encaissement reste Phase 6 |
| Contrôleur | Lire catégories, tarifs et évaluations ; contrôle/audit selon ses permissions existantes |
| Agent de recensement | Lire les catégories ; enregistrer les informations de terrain ; ne classe pas officiellement, ne valide pas les contribuables et ne crée pas d'évaluation |
| Agent de collecte | Lire les catégories, tarifs et évaluations nécessaires à sa mission ; l'encaissement reste Phase 6 |
| Administrateur technique | Aucun droit fiscal ajouté ; il conserve ses fonctions techniques uniquement |

Les droits sont attribués par `role_permissions`. La visibilité du bouton dans l'interface ne remplace jamais les contrôles RLS et les vérifications des fonctions PostgreSQL.

## 4. Ordre de déploiement

1. Conserver une copie de sauvegarde de la base Supabase avant toute migration.
2. Décompresser cette livraison et déployer l'ensemble du dossier du site via Netlify Drop, en remplacement de la version précédente.
3. Dans Supabase SQL Editor, ouvrir et exécuter **uniquement** `supabase/migrations/0003_phase5_fiscalite.sql`.
4. Vérifier que l'exécution se termine sans erreur.
5. Recharger le site et tester la connexion avec le compte Agent de recensement existant.
6. Vérifier que le menu Fiscalité apparaît pour l'agent et que les catégories actives peuvent être consultées/sélectionnées. Les formulaires de création de catégories/tarifs et d'évaluations ne doivent pas lui être accessibles.
7. Lorsque les invitations seront disponibles, créer les comptes Secrétaire général et Maire. Tester la préparation avec le Secrétaire général et l'approbation avec le Maire.

**Ne pas créer de faux comptes, de faux tarifs ou de fausses évaluations pour tester en production.**

## 5. Parcours métier attendu

### A. Préparer une catégorie
Le Secrétaire général saisit le code, le libellé officiel, les critères et la référence juridique exacte. Les catégories actives servent ensuite à classer les contribuables dans la rubrique Fiscalité. Chaque catégorie précise si elle relève d'un encaissement communal, d'un recouvrement par l'État, d'une quote-part ou d'une simple référence informative. Les catégories déjà présentes avant la migration reçoivent par défaut le statut « référence informative » pour empêcher qu'elles deviennent automatiquement encaissables. Seules les catégories marquées « encaissement direct par la commune » peuvent être utilisées pour une évaluation à recouvrer par la mairie. Une catégorie ne peut pas être supprimée de l'historique.

### B. Préparer un tarif
Le Secrétaire général sélectionne une catégorie active, saisit le montant unitaire en XOF, l'unité (par an, par mois, par jour, par m², etc.), les dates et la référence de la décision tarifaire. Le tarif est créé en brouillon et ne sert à aucun calcul.

### C. Approuver un tarif
Le Maire vérifie les pièces officielles, le montant, l'unité et la période, puis utilise le bouton Approuver. La base contrôle notamment la catégorie active, la référence juridique et l'absence de chevauchement avec un autre tarif déjà approuvé pour cette catégorie. Après approbation, le tarif est verrouillé : une nouvelle décision doit créer une nouvelle ligne tarifaire.

### D. Valider un contribuable
Le Secrétaire général classe la fiche dans une catégorie officielle active si elle est assujettie, puis vérifie les informations et la passe de `pending` à `active`. La base impose le statut initial `pending` pour les agents ordinaires et réserve le changement de statut au droit `taxpayers.validate`. Un agent de recensement ne peut pas modifier lui-même le statut de validation.

### E. Créer une évaluation
Le Secrétaire général sélectionne un contribuable validé, un tarif approuvé de la même catégorie fiscale, une quantité et une période comprise dans la validité du tarif. Les catégories relevant du recouvrement de l'État, d'une quote-part ou d'une simple référence ne peuvent pas générer une créance municipale dans cette fonction. Le montant est calculé côté serveur : `montant unitaire × quantité`. Le navigateur ne transmet jamais le montant dû.

## 6. Tests de contrôle à effectuer

- Agent de recensement : consultation des catégories autorisée ; création/approbation de tarif refusée ; création d'évaluation refusée.
- Administrateur technique : ne doit pas recevoir automatiquement les droits fiscaux.
- Secrétaire général : peut créer une catégorie et un tarif brouillon ; ne peut pas approuver un tarif ; peut valider une fiche et créer une évaluation seulement après approbation du tarif.
- Maire : peut approuver un brouillon ; ne peut pas modifier un tarif déjà approuvé.
- Tarif brouillon : impossible de l'utiliser dans `create_assessment`.
- Tarif approuvé : une période d'évaluation en dehors de sa validité doit être rejetée.
- Catégorie inactive : impossible de créer un nouveau tarif ou une nouvelle évaluation avec cette catégorie.
- Contribuable en attente : impossible de créer une évaluation.
- Même contribuable, même tarif et même période : le doublon doit être rejeté par la contrainte unique existante.
- Tentative de rattacher une catégorie d'une autre commune : rejetée par le trigger de contrôle de périmètre.
- Les insertions et modifications métier doivent apparaître dans `audit_logs` via les triggers existants.

## 7. Limites assumées

- Aucun moteur d'exonération, pénalité, remise, intérêt de retard ou calcul prorata n'est ajouté sans règles juridiques validées.
- Aucun calcul massif ni import fiscal en lot n'est inclus dans cette livraison.
- Aucun reçu ni encaissement n'est ajouté ici : ils relèvent de la Phase 6.
- Les fichiers justificatifs des délibérations ne sont pas encore gérés dans une bibliothèque documentaire intégrée.
- Les évaluations ne peuvent être créées que pour les contribuables au statut `active`.

## 8. Règle de sécurité

Ne jamais accorder `categories.manage`, `tariffs.manage`, `tariffs.approve` ou `assessments.create` au compte technique pour contourner la séparation des fonctions. Les comptes métier correspondants doivent être créés avec leurs vrais titulaires et leurs permissions par rôle.


## 9. Précautions juridiques à propos de la fiche documentaire fournie

La fiche transmise par le porteur du projet est une base de recherche, pas un barème officiel de la Commune de Léona. Elle ne doit pas être importée comme catalogue tarifaire automatique.

- L'article 195 du Code général des collectivités territoriales, dans sa version modifiée par la loi n° 2019-12, énumère des recettes communales : certains impôts locaux, droits de place, droits de voirie, revenus de services communaux et autres recettes. Il faut distinguer ces recettes des impôts dont le recouvrement relève de l'État.
- La DGID publie le CGI 2025 et ses taux. Sa page officielle présente notamment la CFPB à 5 % et les modalités de CEL avec des taux différenciés selon l'assiette. Les taux et assiettes de CEL reproduits dans la fiche initiale ne doivent donc pas être recopiés sans examen du CGI applicable.
- Pour les naissances, l'article 51 du Code de la famille prévoit une déclaration dans le délai d'un mois, une possibilité de déclaration tardive jusqu'à un an sous conditions, puis une autorisation judiciaire au-delà. Il ne faut pas réduire cette règle à « délai légal d'un an ».
- Les montants de vignettes d'état civil peuvent varier selon la localité. Toute valeur appliquée à Léona doit être confirmée par les textes et actes locaux pertinents.

Références de travail :
- DGID, « Lois et règlements » (CGI 2025) : https://www.dgid.sn/loi-reglement
- Code général des collectivités territoriales, article 195 : https://www.lexenegal.sn/code/code-general-collectivites-territoriales/art-195
- Code de la famille, article 51 : https://www.lexenegal.sn/code/code-de-la-famille/art-51
- Service public du Sénégal, déclaration de naissance : https://servicepublic.gouv.sn/demarche/declarer-une-naissance
- Service public du Sénégal, extrait de naissance : https://servicepublic.gouv.sn/demarche/demander-un-extrait-du-registre-des-actes-de-naissance

Ces références doivent être relues dans leur version en vigueur au moment de l'adoption du tarif.
