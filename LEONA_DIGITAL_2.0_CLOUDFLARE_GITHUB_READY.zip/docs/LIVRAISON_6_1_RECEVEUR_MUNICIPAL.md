# LÉONA DIGITAL 2.0 — Phase 6.1 : espace du receveur municipal

## Base de travail

Cette version reprend l'archive Phase 6 `LEONA_DIGITAL_2.0_PHASE6_ENCAISSEMENTS_GRAND_LIVRE.zip`. Elle conserve les modules existants : authentification, villages, contribuables, fiscalité, administration des agents, encaissements, reçus et grand livre.

## Améliorations de l'interface

1. **Synthèse financière** : encaissements bruts, contrepassations, net comptable et nombre d'opérations. Les chiffres sont explicitement limités aux 200 dernières opérations visibles.
2. **Filtres du grand livre** : recherche par code/nom/numéro de reçu, type d'opération, état du reçu, mode de paiement et période.
3. **Contrepassation** : le bouton n'est affiché que si le compte possède `payments.reverse` et que son rôle est `receveur_municipal`. La base reste l'autorité finale et contrôle elle-même la permission. Le motif demandé par l'interface doit contenir au moins 10 caractères.
4. **Vérification de reçu** : la page publique `/verification-recu?token=...` interroge uniquement la fonction RPC `verify_receipt(uuid)`. Elle ne consulte pas directement les tables et n'affiche pas l'identité du contribuable.
5. **Impression** : le reçu imprimable comporte un lien de vérification lorsque le jeton correspondant est disponible au profil connecté.

## Installation / déploiement

- Déployer cette archive complète avec la même procédure Netlify que la version Phase 6 précédente.
- Conserver les variables d'environnement Netlify existantes, notamment les secrets côté serveur. Aucun secret `service_role` n'est ajouté au navigateur.
- Cette livraison ne demande aucune nouvelle migration SQL si la correction globale Phase 6 est déjà exécutée et si `public.verify_receipt(uuid)` existe.
- Ne pas exécuter à nouveau `0001_initial.sql`, `0002_phase4_agent_management.sql`, `0003_phase5_fiscalite.sql` ou `0004_phase6_encaissements_grand_livre.sql`.
- Ne pas réinitialiser la base Supabase.

## Tests à effectuer après déploiement

1. Se connecter comme receveur municipal : vérifier l'accès à Finances, à l'encaissement et au grand livre.
2. Vérifier que les quatre indicateurs affichent les valeurs correspondant aux 200 opérations les plus récentes visibles.
3. Tester chaque filtre et le bouton « Effacer les filtres ».
4. Vérifier qu'un reçu peut être imprimé et que son lien public ouvre la page de vérification.
5. Vérifier qu'un reçu valide apparaît comme authentique et qu'un reçu contrepassé apparaît comme annulé.
6. Vérifier qu'un jeton absent ou invalide ne révèle aucune donnée.
7. Se connecter comme maire et contrôleur : aucun bouton de contrepassation ne doit apparaître.
8. Se connecter comme agent collecteur : les données visibles doivent rester limitées aux villages affectés par les politiques RLS.
9. Vérifier que l'administrateur technique ne reçoit pas automatiquement les fonctions financières.

## Limites et précautions

- Les filtres s'appliquent aux 200 opérations les plus récentes accessibles au profil, pas à l'intégralité historique.
- Les indicateurs ne sont pas encore des états comptables certifiés. Les rapports détaillés par village, catégorie, période et agent restent une évolution ultérieure.
- Les paiements mobiles Wave et Orange Money ne sont pas activés par cette livraison.
- Le modèle imprimable doit être validé par la Commune avant d'être utilisé comme reçu administratif officiel (mentions, signatures, cachet et numérotation réglementaire).
- Les tests avec de vrais encaissements ne doivent être effectués qu'avec une évaluation réelle autorisée et après validation par la commune. Ne pas créer de faux paiements pour tester en production.
