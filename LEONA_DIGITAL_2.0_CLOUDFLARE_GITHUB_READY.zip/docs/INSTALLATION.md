# Installation et exploitation

## Configuration Supabase
- Exécuter la migration sur un projet vierge de test.
- Vérifier que les enums et tables sont créés.
- Créer les utilisateurs dans Authentication > Users.
- Créer les lignes `profiles` avec rôle et commune via une procédure administrateur sécurisée. Ne pas donner la clé service_role aux agents.
- Les permissions sont définies dans `role_permissions`. L'accès aux données reste également conditionné par RLS.

## Variables Netlify
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` (secret Netlify uniquement)

## Configuration navigateur
Modifier `public/assets/js/config.js` avec URL Supabase et clé anon publique. Cette clé est publique par conception ; RLS doit protéger chaque table.

## Données initiales
Les 59 villages, codes officiels, textes légaux et tarifs ne sont pas préremplis. Les importer uniquement depuis des sources administratives vérifiées.

## Paiement en ligne
Désactivé volontairement. Ajouter les intégrations Wave Business et Orange Money Business après réception des identifiants marchands, spécifications API et procédure de signature des webhooks. Un webhook idempotent doit vérifier signature, montant, devise, référence et statut auprès du prestataire avant d'enregistrer le paiement.
