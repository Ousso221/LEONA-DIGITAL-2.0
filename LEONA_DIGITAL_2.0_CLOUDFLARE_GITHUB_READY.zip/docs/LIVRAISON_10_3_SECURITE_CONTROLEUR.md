# Livraison — Phase 10.3 : audit et correction de sécurité du contrôleur

## Objet
Séparer la permission `imports.review` (consultation et examen des imports) de la création directe des contribuables dans `public.taxpayers`.

## Modifications
- La politique RLS `taxpayers_insert` exige désormais `recensement.manage` et la commune courante.
- Le formulaire de création des contribuables n'est affiché que si le compte possède `recensement.manage`.
- La fonction `saveTaxpayer` vérifie également `recensement.manage` avant toute tentative d'insertion.
- La permission `imports.review` du rôle `controleur` est conservée pour le traitement des imports.

## Fichiers concernés
- `supabase/migrations/0006_phase10_3_securisation_creation_contribuables.sql`
- `public/assets/js/space.js`

## Déploiement
1. La correction SQL de cette migration a déjà été exécutée manuellement dans Supabase et validée par le résultat `VALIDATION_TAXPAYERS_INSERT = true`. Ne pas réexécuter automatiquement cette migration si la politique a déjà été corrigée.
2. Déployer le contenu du dossier `leona4` sur Netlify afin de publier la correction frontend.
3. Se connecter avec un compte `controleur` et vérifier que le formulaire « Nouvelle fiche de recensement » n'apparaît pas, tandis que la consultation du registre reste disponible selon `taxpayers.read`.
4. Vérifier avec un compte disposant de `recensement.manage` que le formulaire reste accessible.

## Limites de validation
La validation SQL est confirmée. La validation de l'interface nécessite le déploiement Netlify et un test réel avec les deux types de comptes.
