import { createClient } from '@supabase/supabase-js';
import { jsonResponse, readJson } from '../_shared/http.js';

export async function onRequestPost({ request, env }) {
  // Secure by default: activate only after anti-abuse protection is configured.
  if (env.PUBLIC_LOOKUP_ENABLED !== 'true') {
    return jsonResponse(503, { error: 'service_unavailable' });
  }
  if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
    return jsonResponse(503, { error: 'service_unavailable' });
  }

  const parsed = await readJson(request, 8192);
  if (parsed.error) return jsonResponse(400, { error: parsed.error });
  const body = parsed.value;
  const taxpayerId = typeof body.taxpayer_id === 'string' ? body.taxpayer_id.trim() : '';
  const phone = typeof body.phone === 'string' ? body.phone.replace(/[^\d+]/g, '') : '';
  if (!taxpayerId || taxpayerId.length > 40 || phone.length < 8 || phone.length > 24) {
    return jsonResponse(400, { error: 'invalid_request' });
  }

  try {
    const db = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    });
    // Production gate: configure Cloudflare rate limiting/WAF for /api/lookup-dues
    // before publishing this public endpoint to real taxpayers.
    const { data: taxpayer, error } = await db.from('taxpayers').select('id')
      .eq('taxpayer_code', taxpayerId).eq('phone', phone).eq('status', 'active').maybeSingle();
    if (error || !taxpayer) return jsonResponse(404, { error: 'not_found' });

    const { data: rows, error: dueError } = await db.from('v_taxpayer_balances')
      .select('assessment_id,label,balance').eq('taxpayer_id', taxpayer.id).gt('balance', 0);
    if (dueError) return jsonResponse(503, { error: 'service_unavailable' });
    return jsonResponse(200, {
      dues: (rows || []).map(row => ({
        assessment_id: row.assessment_id,
        label: row.label,
        balance: row.balance
      }))
    });
  } catch (error) {
    console.error('lookup_dues_unexpected_error', error?.message || 'unknown');
    return jsonResponse(503, { error: 'service_unavailable' });
  }
}

export async function onRequest(context) {
  return jsonResponse(405, { error: 'method_not_allowed' });
}
