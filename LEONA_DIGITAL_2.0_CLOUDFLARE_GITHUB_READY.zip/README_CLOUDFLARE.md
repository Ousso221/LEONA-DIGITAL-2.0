# LÉONA DIGITAL 2.0 — préparation Cloudflare Pages

Cette version conserve l'interface, les scripts applicatifs, les migrations Supabase et les documents de la livraison Phase 15. Les deux anciennes fonctions Netlify sont portées vers Cloudflare Pages Functions.

## Structure à conserver à la racine du dépôt GitHub

- `public/` : site statique publié.
- `functions/api/manage-agent.js` : route `POST /api/manage-agent`.
- `functions/api/lookup-dues.js` : route `POST /api/lookup-dues`.
- `functions/_shared/http.js` : réponses JSON et validation des requêtes.
- `supabase/` : migrations SQL et diagnostics existants (ne pas exécuter à nouveau sur la base de production sans audit).
- `docs/` : documentation du projet.
- `wrangler.toml` : configuration Pages.

## Réglages Cloudflare Pages / GitHub

- Dépôt : `Ousso221/LEONA-DIGITAL-2.0`
- Branche de production : `main`
- Root directory : `/` (laisser vide / valeur par défaut)
- Framework preset : `None` / aucun
- Build command : `npm install --no-audit --no-fund`
- Build output directory : `public`

Le dépôt doit contenir directement `public/`, `functions/`, `package.json` et `wrangler.toml` à sa racine. Ne pas téléverser le dossier parent `leona4` comme sous-dossier.

## Secrets Cloudflare Pages

Dans Settings > Variables and Secrets, créer les secrets côté Production (et Preview seulement si nécessaire) :

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` — clé très sensible, uniquement secret chiffré côté serveur.
- `SITE_URL` — variable non secrète contenant l’URL HTTPS de production, par exemple `https://nom-du-projet.pages.dev` (à renseigner après création du projet).
- `PUBLIC_LOOKUP_ENABLED` — laisser absent ou `false` au départ. Ne passer à `true` qu’après activation et vérification d’une protection anti-abus pour `/api/lookup-dues`.

Ne jamais mettre la clé `service_role` dans `public/`, GitHub, `config.js`, un fichier `.env` versionné ou une conversation. La clé publique/anon existante dans `public/assets/js/config.js` reste côté navigateur, protégée par les politiques RLS Supabase.

## Points de sécurité avant production

1. Configurer une règle Cloudflare WAF / Rate Limiting sur `POST /api/lookup-dues` avant d'ouvrir cette consultation publique. L'ancienne fonction comportait déjà un commentaire signalant l'absence de limitation durable. Cette migration ne prétend pas résoudre ce risque.
2. Vérifier que les URL de redirection Supabase autorisent l'URL Pages de production et `/activation`.
3. Tester l'invitation, la modification de profil et la consultation des sommes dues avec des comptes et données de test.
4. Ne pas effectuer de test de création, paiement ou annulation financière sur la base de production.
5. Garder Netlify disponible jusqu'à validation complète de Cloudflare.

## État

Portage du code effectué ; syntaxe et structure à vérifier localement. Aucun déploiement Cloudflare, test de bout en bout Supabase ou test réel d'invitation n'a encore été effectué.

### Protection de la consultation publique

La route `POST /api/lookup-dues` vérifie le numéro contribuable et le téléphone avant de renvoyer un solde. Elle utilise une clé serveur privilégiée : une règle de limitation des requêtes (par IP, sur le chemin exact `/api/lookup-dues`) doit donc être créée dans **Security rules > Rate limiting rules** lorsque cette fonction est exposée. La disponibilité et les seuils proposés par Cloudflare dépendent du plan. La fonction est désactivée par défaut (`PUBLIC_LOOKUP_ENABLED` différent de `true`). Ne l'activer qu'après avoir confirmé qu'une protection adaptée fonctionne. Si aucune protection adaptée n'est disponible, la laisser désactivée.
