-- À exécuter APRÈS avoir créé le compte dans Supabase > Authentication > Users.
-- Remplacer l'UUID et le nom par les valeurs exactes de l'utilisateur créé.
do $$
declare
  v_user_id uuid := 'REMPLACER-PAR-UUID-AUTH'::uuid;
  v_full_name text := 'Administrateur technique';
  v_commune_id uuid;
begin
  select id into v_commune_id from public.communes where code='SN-LOU-LEONA';
  if v_commune_id is null then raise exception 'Commune SN-LOU-LEONA introuvable'; end if;
  if not exists(select 1 from auth.users where id=v_user_id) then
    raise exception 'Utilisateur Auth introuvable : vérifiez son UUID';
  end if;
  insert into public.profiles(id,commune_id,full_name,role,active)
  values(v_user_id,v_commune_id,v_full_name,'administrateur_technique',true)
  on conflict(id) do update set
    commune_id=excluded.commune_id,
    full_name=excluded.full_name,
    role='administrateur_technique',
    active=true;
end $$;

select p.id, u.email, p.full_name, p.role, p.active, c.name as commune
from public.profiles p
join auth.users u on u.id=p.id
join public.communes c on c.id=p.commune_id
where p.role='administrateur_technique';
