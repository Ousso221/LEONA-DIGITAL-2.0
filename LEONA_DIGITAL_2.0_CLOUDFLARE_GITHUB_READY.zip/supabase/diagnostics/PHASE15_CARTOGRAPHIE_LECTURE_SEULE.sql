-- LÉONA DIGITAL 2.0 — PHASE 15
-- Diagnostic de disponibilité des données cartographiques et fiscales.
-- SCRIPT STRICTEMENT EN LECTURE SEULE : aucun INSERT, UPDATE, DELETE, DDL ou appel RPC.
-- Les résultats sont agrégés ; aucune donnée nominative ou coordonnée individuelle n'est exposée.

-- 1) Vérifier les champs nécessaires au module cartographique.
select table_name, column_name, data_type
from information_schema.columns
where table_schema = 'public'
  and (
    (table_name = 'taxpayers' and column_name in
      ('id','commune_id','taxpayer_code','first_name','last_name','village_id',
       'activity','tax_category','tax_category_id','gps_lat','gps_lon','status'))
    or (table_name = 'villages' and column_name in ('id','commune_id','name'))
    or (table_name = 'v_assessment_balances' and column_name in
      ('assessment_id','taxpayer_id','commune_id','village_id','period_start',
       'period_end','amount_due','amount_paid','balance'))
  )
order by table_name, column_name;

-- 2) Couverture de géolocalisation et recouvrement par village.
with taxpayer_stats as (
  select
    village_id,
    count(*)::bigint as taxpayers_count,
    count(*) filter (where gps_lat is not null and gps_lon is not null)::bigint as gps_count,
    count(*) filter (where nullif(trim(coalesce(activity,'')), '') is not null)::bigint as activity_count
  from public.taxpayers
  where commune_id = '4ff58202-4615-4d1f-8412-d06fdc0967ad'::uuid
  group by village_id
), fiscal_stats as (
  select
    village_id,
    count(*)::bigint as assessments_count,
    coalesce(sum(amount_due),0)::numeric(14,2) as amount_due,
    coalesce(sum(amount_paid),0)::numeric(14,2) as amount_paid,
    coalesce(sum(balance),0)::numeric(14,2) as balance
  from public.v_assessment_balances
  where commune_id = '4ff58202-4615-4d1f-8412-d06fdc0967ad'::uuid
  group by village_id
)
select
  v.id as village_id,
  v.name as village,
  coalesce(t.taxpayers_count,0) as taxpayers_count,
  coalesce(t.gps_count,0) as gps_count,
  coalesce(t.activity_count,0) as activity_count,
  coalesce(f.assessments_count,0) as assessments_count,
  coalesce(f.amount_due,0) as amount_due_fcfa,
  coalesce(f.amount_paid,0) as amount_paid_net_fcfa,
  coalesce(f.balance,0) as balance_fcfa,
  case when coalesce(f.amount_due,0) > 0
       then round(100 * f.amount_paid / f.amount_due, 2)
       else null end as recovery_rate_pct
from public.villages v
left join taxpayer_stats t on t.village_id = v.id
left join fiscal_stats f on f.village_id = v.id
where v.commune_id = '4ff58202-4615-4d1f-8412-d06fdc0967ad'::uuid
order by v.name;

-- 3) Comparaison des activités entre villages.
select
  v.name as village,
  coalesce(nullif(trim(tp.activity),''),'Activité non renseignée') as activity,
  count(distinct tp.id)::bigint as taxpayers_count,
  count(distinct tp.id) filter (where tp.gps_lat is not null and tp.gps_lon is not null)::bigint as gps_count,
  coalesce(sum(b.amount_due),0)::numeric(14,2) as amount_due_fcfa,
  coalesce(sum(b.amount_paid),0)::numeric(14,2) as amount_paid_net_fcfa,
  coalesce(sum(b.balance),0)::numeric(14,2) as balance_fcfa,
  case when coalesce(sum(b.amount_due),0) > 0
       then round(100 * sum(b.amount_paid) / sum(b.amount_due), 2)
       else null end as recovery_rate_pct
from public.taxpayers tp
left join public.villages v on v.id = tp.village_id and v.commune_id = tp.commune_id
left join public.v_assessment_balances b on b.taxpayer_id = tp.id and b.commune_id = tp.commune_id
where tp.commune_id = '4ff58202-4615-4d1f-8412-d06fdc0967ad'::uuid
group by v.name, coalesce(nullif(trim(tp.activity),''),'Activité non renseignée')
order by v.name, activity;

-- 4) Répartition des natures fiscales déclarées au registre.
select
  coalesce(tc.label, nullif(trim(tp.tax_category),''), 'Nature fiscale non renseignée') as tax_nature,
  count(*)::bigint as taxpayers_count,
  count(*) filter (where tp.gps_lat is not null and tp.gps_lon is not null)::bigint as gps_count
from public.taxpayers tp
left join public.tax_categories tc on tc.id = tp.tax_category_id
where tp.commune_id = '4ff58202-4615-4d1f-8412-d06fdc0967ad'::uuid
group by coalesce(tc.label, nullif(trim(tp.tax_category),''), 'Nature fiscale non renseignée')
order by tax_nature;
