-- LÉONA DIGITAL 2.0 — Schéma initial sécurisé
-- À exécuter UNE SEULE FOIS dans un projet Supabase neuf.
-- Ne contient aucun mot de passe ni aucune clé secrète.
-- Les villages, tarifs et données fiscales officiels doivent être ajoutés après vérification.

begin;

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum (
    'maire','secretaire_general','receveur_municipal','controleur',
    'agent_recensement','agent_collecte','administrateur_technique'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.taxpayer_status as enum ('pending','active','inactive');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.import_status as enum ('draft','submitted','approved','rejected');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.payment_method as enum ('cash','cheque','bank_transfer','wave','orange_money');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.ledger_entry_type as enum ('collection','reversal');
exception when duplicate_object then null; end $$;

create table if not exists public.communes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  country_code char(2) not null default 'SN',
  created_at timestamptz not null default now()
);

insert into public.communes(code,name,country_code)
values ('SN-LOU-LEONA','Commune de Léona','SN')
on conflict (code) do nothing;

create table if not exists public.role_permissions (
  role public.app_role not null,
  permission text not null,
  primary key(role,permission)
);

insert into public.role_permissions(role,permission) values
 ('maire','reports.read'),('maire','finance.read'),('maire','agents.read'),('maire','administration.read'),('maire','taxpayers.read'),('maire','payments.read'),
 ('secretaire_general','reports.read'),('secretaire_general','taxpayers.read'),('secretaire_general','recensement.read'),('secretaire_general','agents.read'),('secretaire_general','administration.read'),('secretaire_general','imports.review'),
 ('receveur_municipal','taxpayers.read'),('receveur_municipal','payments.collect'),('receveur_municipal','finance.read'),('receveur_municipal','receipts.read'),('receveur_municipal','reports.read'),('receveur_municipal','payments.read'),
 ('controleur','taxpayers.read'),('controleur','imports.review'),('controleur','audit.read'),('controleur','payments.read'),('controleur','reports.read'),('controleur','finance.read'),
 ('agent_recensement','taxpayers.read'),('agent_recensement','recensement.manage'),('agent_recensement','imports.create'),('agent_recensement','recensement.read'),
 ('agent_collecte','taxpayers.read'),('agent_collecte','payments.collect'),('agent_collecte','collections.read'),
 ('administrateur_technique','users.manage'),('administrateur_technique','settings.manage'),('administrateur_technique','audit.read'),('administrateur_technique','agents.read'),('administrateur_technique','agents.manage'),('administrateur_technique','administration.read')
on conflict do nothing;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  commune_id uuid not null references public.communes(id),
  full_name text not null,
  role public.app_role not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists profiles_commune_idx on public.profiles(commune_id);

create table if not exists public.villages (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  official_code text,
  name text not null,
  geom_geojson jsonb,
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique(commune_id,official_code)
);

create table if not exists public.agent_assignments (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  agent_id uuid not null references public.profiles(id),
  village_id uuid not null references public.villages(id),
  assignment_type text not null check (assignment_type in ('recensement','collecte','both')),
  starts_on date not null default current_date,
  ends_on date,
  created_at timestamptz not null default now(),
  check (ends_on is null or ends_on >= starts_on)
);

create table if not exists public.taxpayers (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  taxpayer_code text not null,
  first_name text not null,
  last_name text not null,
  phone text,
  village_id uuid references public.villages(id),
  activity text,
  tax_category text,
  location_label text,
  gps_lat numeric(9,6),
  gps_lon numeric(9,6),
  extra jsonb not null default '{}'::jsonb,
  status public.taxpayer_status not null default 'pending',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(commune_id,taxpayer_code),
  check (gps_lat is null or gps_lat between -90 and 90),
  check (gps_lon is null or gps_lon between -180 and 180)
);
create index if not exists taxpayers_name_idx on public.taxpayers(commune_id,last_name,first_name);
create index if not exists taxpayers_phone_idx on public.taxpayers(commune_id,phone);
create index if not exists taxpayers_village_idx on public.taxpayers(village_id);

create table if not exists public.tax_categories (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  code text not null,
  label text not null,
  legal_reference text not null,
  active boolean not null default false,
  created_at timestamptz not null default now(),
  unique(commune_id,code)
);

create table if not exists public.tariffs (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  category_id uuid not null references public.tax_categories(id),
  amount numeric(14,2) not null check(amount > 0),
  currency char(3) not null default 'XOF',
  valid_from date not null,
  valid_to date,
  legal_reference text not null,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  check(valid_to is null or valid_to >= valid_from),
  check((approved_by is null) = (approved_at is null))
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  taxpayer_id uuid not null references public.taxpayers(id),
  tariff_id uuid not null references public.tariffs(id),
  period_start date not null,
  period_end date not null,
  amount_due numeric(14,2) not null check(amount_due > 0),
  created_at timestamptz not null default now(),
  unique(taxpayer_id,tariff_id,period_start,period_end),
  check(period_end >= period_start)
);

create table if not exists public.import_batches (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  submitted_by uuid not null references public.profiles(id),
  status public.import_status not null default 'draft',
  file_name text,
  row_count integer not null default 0 check(row_count >= 0),
  review_reason text,
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check(status <> 'rejected' or length(trim(coalesce(review_reason,''))) >= 5),
  check((status in ('approved','rejected')) = (reviewed_at is not null))
);

create table if not exists public.import_rows (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.import_batches(id) on delete cascade,
  row_number integer not null,
  payload jsonb not null,
  validation_errors jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  unique(batch_id,row_number)
);

-- Grand livre append-only : une annulation est une nouvelle ligne négative logique,
-- jamais une modification ou suppression de la collecte initiale.
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  commune_id uuid not null references public.communes(id),
  assessment_id uuid not null references public.assessments(id),
  entry_type public.ledger_entry_type not null default 'collection',
  amount numeric(14,2) not null check(amount > 0),
  method public.payment_method not null,
  external_reference text unique,
  collected_by uuid references public.profiles(id),
  reversal_of uuid unique references public.payments(id),
  reason text,
  confirmed_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  check (
    (entry_type='collection' and reversal_of is null and reason is null)
    or
    (entry_type='reversal' and reversal_of is not null and length(trim(coalesce(reason,''))) >= 5)
  )
);
create index if not exists payments_assessment_idx on public.payments(assessment_id,confirmed_at);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null unique references public.payments(id),
  commune_id uuid not null references public.communes(id),
  receipt_number text not null unique,
  verification_token uuid not null unique default gen_random_uuid(),
  issued_at timestamptz not null default now()
);

create sequence if not exists public.receipt_seq start 1;

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  commune_id uuid,
  actor_id uuid,
  table_name text not null,
  record_id text,
  operation text not null,
  old_data jsonb,
  new_data jsonb,
  reason text,
  occurred_at timestamptz not null default now()
);
create index if not exists audit_logs_commune_date_idx on public.audit_logs(commune_id,occurred_at desc);

create or replace function public.current_commune()
returns uuid language sql stable security definer
set search_path=public,pg_temp
as $$ select commune_id from public.profiles where id=auth.uid() and active=true limit 1 $$;

create or replace function public.current_role()
returns public.app_role language sql stable security definer
set search_path=public,pg_temp
as $$ select role from public.profiles where id=auth.uid() and active=true limit 1 $$;

create or replace function public.has_permission(p_permission text)
returns boolean language sql stable security definer
set search_path=public,pg_temp
as $$
 select exists (
   select 1 from public.profiles p
   join public.role_permissions rp on rp.role=p.role
   where p.id=auth.uid() and p.active=true and rp.permission=p_permission
 )
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql
set search_path=public,pg_temp
as $$ begin new.updated_at=now(); return new; end $$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute function public.touch_updated_at();
drop trigger if exists taxpayers_touch_updated_at on public.taxpayers;
create trigger taxpayers_touch_updated_at before update on public.taxpayers
for each row execute function public.touch_updated_at();

create or replace function public.audit_row()
returns trigger language plpgsql security definer
set search_path=public,pg_temp
as $$
declare v_commune uuid; v_id text;
begin
 if tg_op='DELETE' then
   v_commune := coalesce((to_jsonb(old)->>'commune_id')::uuid, public.current_commune());
   v_id := to_jsonb(old)->>'id';
   insert into public.audit_logs(commune_id,actor_id,table_name,record_id,operation,old_data)
   values(v_commune,auth.uid(),tg_table_name,v_id,tg_op,to_jsonb(old));
   return old;
 else
   v_commune := coalesce((to_jsonb(new)->>'commune_id')::uuid, public.current_commune());
   v_id := to_jsonb(new)->>'id';
   insert into public.audit_logs(commune_id,actor_id,table_name,record_id,operation,old_data,new_data)
   values(v_commune,auth.uid(),tg_table_name,v_id,tg_op,
          case when tg_op='UPDATE' then to_jsonb(old) end,to_jsonb(new));
   return new;
 end if;
end $$;

do $$
declare t text;
begin
 foreach t in array array[
  'profiles','villages','agent_assignments','taxpayers','tax_categories',
  'tariffs','assessments','import_batches','payments','receipts'
 ] loop
   execute format('drop trigger if exists audit_%I on public.%I',t,t);
   execute format('create trigger audit_%I after insert or update or delete on public.%I for each row execute function public.audit_row()',t,t);
 end loop;
end $$;

create or replace function public.prevent_ledger_mutation()
returns trigger language plpgsql
set search_path=public,pg_temp
as $$ begin raise exception 'ledger_is_append_only'; end $$;

drop trigger if exists payments_no_update_delete on public.payments;
create trigger payments_no_update_delete before update or delete on public.payments
for each row execute function public.prevent_ledger_mutation();
drop trigger if exists receipts_no_update_delete on public.receipts;
create trigger receipts_no_update_delete before update or delete on public.receipts
for each row execute function public.prevent_ledger_mutation();
drop trigger if exists audit_no_update_delete on public.audit_logs;
create trigger audit_no_update_delete before update or delete on public.audit_logs
for each row execute function public.prevent_ledger_mutation();

create or replace function public.approve_tariff(p_tariff uuid)
returns void language plpgsql security definer
set search_path=public,pg_temp
as $$
begin
 if not public.has_permission('settings.manage') then raise exception 'permission_denied'; end if;
 update public.tariffs
 set approved_by=auth.uid(), approved_at=now()
 where id=p_tariff and commune_id=public.current_commune() and approved_at is null;
 if not found then raise exception 'tariff_not_found_or_already_approved'; end if;
end $$;

create or replace function public.record_physical_payment(
 p_assessment uuid, p_amount numeric, p_method public.payment_method
)
returns table(payment_id uuid, receipt_number text)
language plpgsql security definer
set search_path=public,pg_temp
as $$
declare
 a public.assessments%rowtype;
 v_paid numeric;
 v_payment uuid;
 v_receipt text;
 v_year text;
begin
 if not public.has_permission('payments.collect') then raise exception 'permission_denied'; end if;
 if p_method not in ('cash','cheque','bank_transfer') then raise exception 'invalid_physical_method'; end if;
 if p_amount is null or p_amount<=0 then raise exception 'invalid_amount'; end if;

 select * into a from public.assessments
 where id=p_assessment and commune_id=public.current_commune()
 for update;
 if not found then raise exception 'assessment_not_found'; end if;

 if public.current_role()='agent_collecte' and not exists (
   select 1 from public.taxpayers tp
   join public.agent_assignments aa on aa.village_id=tp.village_id
   where tp.id=a.taxpayer_id and aa.agent_id=auth.uid()
     and aa.commune_id=a.commune_id
     and aa.assignment_type in ('collecte','both')
     and aa.starts_on<=current_date and (aa.ends_on is null or aa.ends_on>=current_date)
 ) then raise exception 'village_not_assigned'; end if;

 select coalesce(sum(case when p.entry_type='collection' then p.amount else -p.amount end),0)
 into v_paid from public.payments p where p.assessment_id=a.id;

 if p_amount > a.amount_due-v_paid then raise exception 'amount_exceeds_balance'; end if;

 insert into public.payments(commune_id,assessment_id,entry_type,amount,method,collected_by)
 values(a.commune_id,a.id,'collection',p_amount,p_method,auth.uid())
 returning id into v_payment;

 v_year:=to_char(now(),'YYYY');
 insert into public.receipts(payment_id,commune_id,receipt_number)
 values(v_payment,a.commune_id,'Q'||v_year||'-'||lpad(nextval('public.receipt_seq')::text,7,'0'))
 returning receipt_number into v_receipt;

 return query select v_payment,v_receipt;
end $$;

create or replace function public.reverse_payment(p_payment uuid,p_reason text)
returns uuid language plpgsql security definer
set search_path=public,pg_temp
as $$
declare original public.payments%rowtype; reversal_id uuid;
begin
 if not (public.has_permission('finance.read') or public.has_permission('payments.read')) then
   raise exception 'permission_denied';
 end if;
 if length(trim(coalesce(p_reason,''))) < 5 then raise exception 'reversal_reason_required'; end if;

 select * into original from public.payments
 where id=p_payment and commune_id=public.current_commune()
 and entry_type='collection'
 for update;
 if not found then raise exception 'original_payment_not_found'; end if;

 if exists(select 1 from public.payments where reversal_of=original.id) then
   raise exception 'payment_already_reversed';
 end if;

 insert into public.payments(
   commune_id,assessment_id,entry_type,amount,method,collected_by,reversal_of,reason
 ) values (
   original.commune_id,original.assessment_id,'reversal',original.amount,
   original.method,auth.uid(),original.id,trim(p_reason)
 ) returning id into reversal_id;

 return reversal_id;
end $$;

create or replace view public.v_taxpayer_balances
with (security_invoker=true) as
select a.id as assessment_id,a.taxpayer_id,a.commune_id,tc.label,
       a.amount_due-coalesce(sum(case when p.entry_type='collection' then p.amount else -p.amount end),0) as balance
from public.assessments a
join public.tariffs t on t.id=a.tariff_id
join public.tax_categories tc on tc.id=t.category_id
left join public.payments p on p.assessment_id=a.id
group by a.id,a.taxpayer_id,a.commune_id,tc.label,a.amount_due;

-- RLS : toutes les tables métier sont isolées par commune et permission.
alter table public.communes enable row level security;
alter table public.role_permissions enable row level security;
alter table public.profiles enable row level security;
alter table public.villages enable row level security;
alter table public.agent_assignments enable row level security;
alter table public.taxpayers enable row level security;
alter table public.tax_categories enable row level security;
alter table public.tariffs enable row level security;
alter table public.assessments enable row level security;
alter table public.import_batches enable row level security;
alter table public.import_rows enable row level security;
alter table public.payments enable row level security;
alter table public.receipts enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists commune_read on public.communes;
create policy commune_read on public.communes for select to authenticated
using(id=public.current_commune());

drop policy if exists role_permissions_read on public.role_permissions;
create policy role_permissions_read on public.role_permissions for select to authenticated
using(public.current_role() is not null);

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated
using(commune_id=public.current_commune() and
      (id=auth.uid() or public.has_permission('agents.read') or public.has_permission('users.manage')));

drop policy if exists profiles_admin on public.profiles;
create policy profiles_admin on public.profiles for all to authenticated
using(public.has_permission('users.manage') and commune_id=public.current_commune())
with check(public.has_permission('users.manage') and commune_id=public.current_commune());

drop policy if exists villages_read on public.villages;
create policy villages_read on public.villages for select to authenticated
using(commune_id=public.current_commune());

drop policy if exists villages_admin on public.villages;
create policy villages_admin on public.villages for all to authenticated
using(public.has_permission('settings.manage') and commune_id=public.current_commune())
with check(public.has_permission('settings.manage') and commune_id=public.current_commune());

drop policy if exists assignments_read on public.agent_assignments;
create policy assignments_read on public.agent_assignments for select to authenticated
using(commune_id=public.current_commune() and
      (agent_id=auth.uid() or public.has_permission('agents.read')));

drop policy if exists assignments_admin on public.agent_assignments;
create policy assignments_admin on public.agent_assignments for all to authenticated
using(public.has_permission('agents.manage') and commune_id=public.current_commune())
with check(public.has_permission('agents.manage') and commune_id=public.current_commune());

drop policy if exists taxpayers_read on public.taxpayers;
create policy taxpayers_read on public.taxpayers for select to authenticated
using(commune_id=public.current_commune() and public.has_permission('taxpayers.read'));

drop policy if exists taxpayers_insert on public.taxpayers;
create policy taxpayers_insert on public.taxpayers for insert to authenticated
with check(commune_id=public.current_commune() and
           (public.has_permission('recensement.manage') or public.has_permission('imports.review')));

drop policy if exists taxpayers_update on public.taxpayers;
create policy taxpayers_update on public.taxpayers for update to authenticated
using(commune_id=public.current_commune() and public.has_permission('recensement.manage'))
with check(commune_id=public.current_commune());

drop policy if exists categories_read on public.tax_categories;
create policy categories_read on public.tax_categories for select to authenticated
using(commune_id=public.current_commune());

drop policy if exists categories_admin on public.tax_categories;
create policy categories_admin on public.tax_categories for all to authenticated
using(public.has_permission('settings.manage') and commune_id=public.current_commune())
with check(public.has_permission('settings.manage') and commune_id=public.current_commune());

drop policy if exists tariffs_read on public.tariffs;
create policy tariffs_read on public.tariffs for select to authenticated
using(commune_id=public.current_commune());

drop policy if exists tariffs_admin on public.tariffs;
create policy tariffs_admin on public.tariffs for all to authenticated
using(public.has_permission('settings.manage') and commune_id=public.current_commune())
with check(public.has_permission('settings.manage') and commune_id=public.current_commune());

drop policy if exists assessments_read on public.assessments;
create policy assessments_read on public.assessments for select to authenticated
using(commune_id=public.current_commune() and public.has_permission('taxpayers.read'));

drop policy if exists imports_read on public.import_batches;
create policy imports_read on public.import_batches for select to authenticated
using(commune_id=public.current_commune() and
      (submitted_by=auth.uid() or public.has_permission('imports.review')));

drop policy if exists imports_insert on public.import_batches;
create policy imports_insert on public.import_batches for insert to authenticated
with check(commune_id=public.current_commune() and submitted_by=auth.uid()
           and public.has_permission('imports.create'));

drop policy if exists import_rows_read on public.import_rows;
create policy import_rows_read on public.import_rows for select to authenticated
using(exists(select 1 from public.import_batches b
             where b.id=batch_id and b.commune_id=public.current_commune()
             and (b.submitted_by=auth.uid() or public.has_permission('imports.review'))));

drop policy if exists payments_read on public.payments;
create policy payments_read on public.payments for select to authenticated
using(commune_id=public.current_commune() and
      (public.has_permission('payments.read') or public.has_permission('finance.read')
       or public.has_permission('payments.collect')));

drop policy if exists receipts_read on public.receipts;
create policy receipts_read on public.receipts for select to authenticated
using(commune_id=public.current_commune() and
      (public.has_permission('receipts.read') or public.has_permission('payments.collect')
       or public.has_permission('finance.read')));

drop policy if exists audit_read on public.audit_logs;
create policy audit_read on public.audit_logs for select to authenticated
using(commune_id=public.current_commune() and public.has_permission('audit.read'));

-- Aucun accès direct d'écriture aux journaux et au grand livre depuis le navigateur.
revoke all on public.audit_logs from anon,authenticated;
grant select on public.audit_logs to authenticated;
revoke insert,update,delete on public.payments,public.receipts from anon,authenticated;
grant select on public.payments,public.receipts to authenticated;

grant execute on function public.record_physical_payment(uuid,numeric,public.payment_method) to authenticated;
grant execute on function public.reverse_payment(uuid,text) to authenticated;
grant execute on function public.approve_tariff(uuid) to authenticated;
grant select on public.v_taxpayer_balances to authenticated;

commit;

-- Après création du premier utilisateur dans Authentication > Users,
-- exécuter le script d'affectation administrateur fourni séparément.
