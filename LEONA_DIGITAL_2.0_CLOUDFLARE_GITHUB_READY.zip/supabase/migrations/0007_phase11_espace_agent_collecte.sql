-- ============================================================
-- LÉONA DIGITAL 2.0 — PHASE 11
-- Sécurisation de la consultation des contribuables par l'agent de collecte
-- Commune de Léona uniquement — migration additive ciblée
-- ============================================================
-- Pré-requis : schéma existant des phases 1 à 10.4 déjà déployé.
-- Cette migration ne supprime aucune table ni aucune donnée.
-- Elle remplace uniquement la politique SELECT taxpayers_read.

BEGIN;

DROP POLICY IF EXISTS taxpayers_read ON public.taxpayers;

CREATE POLICY taxpayers_read
ON public.taxpayers
FOR SELECT
TO authenticated
USING (
    commune_id = public.current_commune()
    AND public.has_permission('taxpayers.read'::text)
    AND (
        public.current_role() <> 'agent_collecte'::public.app_role
        OR EXISTS (
            SELECT 1
            FROM public.agent_assignments aa
            WHERE aa.agent_id = auth.uid()
              AND aa.commune_id = taxpayers.commune_id
              AND aa.village_id = taxpayers.village_id
              AND aa.assignment_type = ANY (ARRAY['collecte'::text, 'both'::text])
              AND aa.starts_on <= CURRENT_DATE
              AND (aa.ends_on IS NULL OR aa.ends_on >= CURRENT_DATE)
        )
    )
);

COMMIT;

-- Résultat attendu :
-- * les autres profils conservent la règle commune + taxpayers.read ;
-- * agent_collecte ne lit que les contribuables des villages où son
--   affectation collecte/both est active à la date du jour ;
-- * aucune permission de collecte supplémentaire n'est attribuée ici.
