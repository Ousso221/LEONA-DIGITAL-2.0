-- LÉONA DIGITAL 2.0 — Phase 6 : encaissements, reçus et grand livre
-- Migration additive : ne pas réexécuter 0001_initial.sql ni 0003_phase5_fiscalite.sql.
-- Aucun paiement, reçu, contribuable ou tarif fictif n'est créé.

begin;

-- Séparation des responsabilités : seul le receveur municipal peut contrepasser
-- une écriture. Le contrôleur, le maire et les agents conservent leurs droits de lecture
-- déjà définis, sans pouvoir annuler un paiement.
insert into public.role_permissions(role, permission) values
  ('receveur_municipal','payments.reverse'),
  ('receveur_municipal','payments.collect'),
  ('receveur_municipal','payments.read'),
  ('receveur_municipal','receipts.read'),
  ('receveur_municipal','finance.read'),
  ('receveur_municipal','reports.read'),
  ('controleur','payments.read'),
  ('controleur','receipts.read'),
  ('controleur','finance.read'),
  ('controleur','reports.read'),
  ('maire','payments.read'),
  ('maire','receipts.read'),
  ('maire','finance.read'),
  ('maire','reports.read'),
  ('agent_collecte','payments.read'),
  ('agent_collecte','receipts.read')
on conflict (role, permission) do nothing;

-- Indexes de consultation du grand livre et des reçus.
create index if not exists payments_commune_confirmed_idx
  on public.payments(commune_id, confirmed_at desc);
create index if not exists receipts_commune_issued_idx
  on public.receipts(commune_id, issued_at desc);

-- La fonction historique autorisait à tort finance.read/payments.read à annuler.
-- La nouvelle fonction exige la permission dédiée payments.reverse.
create or replace function public.reverse_payment(p_payment uuid,p_reason text)
returns uuid
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  original public.payments%rowtype;
  reversal_id uuid;
begin
  if auth.uid() is null then
    raise exception 'authentication_required' using errcode='42501';
  end if;
  if not public.has_permission('payments.reverse') then
    raise exception 'permission_denied' using errcode='42501';
  end if;
  if length(trim(coalesce(p_reason,''))) < 10 then
    raise exception 'reversal_reason_required';
  end if;

  select * into original
  from public.payments
  where id=p_payment
    and commune_id=public.current_commune()
    and entry_type='collection'
  for update;

  if not found then
    raise exception 'original_payment_not_found';
  end if;

  if exists(select 1 from public.payments where reversal_of=original.id) then
    raise exception 'payment_already_reversed';
  end if;

  insert into public.payments(
    commune_id,assessment_id,entry_type,amount,method,collected_by,reversal_of,reason
  ) values (
    original.commune_id,original.assessment_id,'reversal',original.amount,
    original.method,auth.uid(),original.id,trim(p_reason)
  ) returning id into reversal_id;

  return reversal_id;
end;
$$;

-- Vues en security_invoker : les politiques RLS des tables sources restent appliquées
-- à l'utilisateur connecté. Elles ne donnent aucun accès transversal aux communes.
create or replace view public.v_assessment_balances
with (security_invoker=true) as
select
  a.id as assessment_id,
  a.commune_id,
  a.taxpayer_id,
  tp.taxpayer_code,
  tp.first_name,
  tp.last_name,
  tp.village_id,
  a.period_start,
  a.period_end,
  a.amount_due,
  coalesce(sum(case when p.entry_type='collection' then p.amount else -p.amount end),0)::numeric(14,2) as amount_paid,
  greatest(a.amount_due - coalesce(sum(case when p.entry_type='collection' then p.amount else -p.amount end),0),0)::numeric(14,2) as balance
from public.assessments a
join public.taxpayers tp on tp.id=a.taxpayer_id and tp.commune_id=a.commune_id
left join public.payments p on p.assessment_id=a.id and p.commune_id=a.commune_id
group by a.id,a.commune_id,a.taxpayer_id,tp.taxpayer_code,tp.first_name,tp.last_name,tp.village_id,
         a.period_start,a.period_end,a.amount_due;

create or replace view public.v_financial_ledger
with (security_invoker=true) as
select
  p.id as payment_id,
  p.commune_id,
  p.assessment_id,
  p.entry_type,
  p.amount,
  p.method,
  p.confirmed_at,
  p.collected_by,
  p.reversal_of,
  p.reason,
  r.receipt_number,
  r.issued_at,
  case
    when p.entry_type='reversal' then 'CONTREPASSÉE'
    when exists(select 1 from public.payments rv where rv.reversal_of=p.id) then 'ANNULÉE'
    else 'VALIDE'
  end as receipt_status,
  tp.taxpayer_code,
  tp.first_name,
  tp.last_name,
  a.period_start,
  a.period_end
from public.payments p
join public.assessments a on a.id=p.assessment_id and a.commune_id=p.commune_id
join public.taxpayers tp on tp.id=a.taxpayer_id and tp.commune_id=a.commune_id
left join public.receipts r on r.payment_id=p.id and r.commune_id=p.commune_id;

grant select on public.v_assessment_balances to authenticated;
grant select on public.v_financial_ledger to authenticated;

-- Aucun accès anonyme ni exécution implicite PUBLIC aux fonctions financières.
revoke all privileges on function public.record_physical_payment(uuid,numeric,public.payment_method) from public,anon;
revoke all privileges on function public.reverse_payment(uuid,text) from public,anon;
grant execute on function public.record_physical_payment(uuid,numeric,public.payment_method) to authenticated;
grant execute on function public.reverse_payment(uuid,text) to authenticated;

commit;
