-- LÉONA DIGITAL 2.0 — Phase 5 : catégories fiscales, tarifs et évaluations
-- Migration additive. Ne pas exécuter 0001_initial.sql une seconde fois.
-- Aucun tarif, catégorie ou montant officiel n'est préchargé.

begin;

-- Permissions fiscales séparées de l'administration technique.
insert into public.role_permissions(role, permission) values
  ('maire','categories.read'),
  ('maire','tariffs.read'),
  ('maire','tariffs.approve'),
  ('maire','assessments.read'),
  ('secretaire_general','categories.read'),
  ('secretaire_general','categories.manage'),
  ('secretaire_general','tariffs.read'),
  ('secretaire_general','tariffs.manage'),
  ('secretaire_general','assessments.read'),
  ('secretaire_general','assessments.create'),
  ('secretaire_general','taxpayers.validate'),
  ('secretaire_general','taxpayers.classify'),
  ('receveur_municipal','categories.read'),
  ('receveur_municipal','tariffs.read'),
  ('receveur_municipal','assessments.read'),
  ('controleur','categories.read'),
  ('controleur','tariffs.read'),
  ('controleur','assessments.read'),
  ('agent_recensement','categories.read'),
  ('agent_collecte','categories.read'),
  ('agent_collecte','tariffs.read'),
  ('agent_collecte','assessments.read')
on conflict (role, permission) do nothing;

-- Champs complémentaires non destructifs.
alter table public.tax_categories
  add column if not exists description text;

-- Nature de la recette et autorité de recouvrement : évite de confondre
-- les impôts recouvrés par l'État avec les recettes encaissables par la commune.
alter table public.tax_categories
  add column if not exists revenue_type text not null default 'taxe_communale';
alter table public.tax_categories
  add column if not exists collection_scope text not null default 'reference_seule';

do $$
begin
  if not exists (select 1 from pg_constraint where conname='tax_categories_revenue_type_check' and conrelid='public.tax_categories'::regclass) then
    alter table public.tax_categories add constraint tax_categories_revenue_type_check
      check (revenue_type in ('impot_local','taxe_communale','redevance_domaine','service_administratif','recette_partagee','reference_etat'));
  end if;
  if not exists (select 1 from pg_constraint where conname='tax_categories_collection_scope_check' and conrelid='public.tax_categories'::regclass) then
    alter table public.tax_categories add constraint tax_categories_collection_scope_check
      check (collection_scope in ('commune_encaissement','etat_recouvrement','quote_part','reference_seule'));
  end if;
end $$;

alter table public.tariffs
  add column if not exists billing_unit text not null default 'forfait';

alter table public.assessments
  add column if not exists quantity numeric(14,3) not null default 1;

alter table public.taxpayers
  add column if not exists tax_category_id uuid;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'taxpayers_tax_category_id_fkey'
      and conrelid = 'public.taxpayers'::regclass
  ) then
    alter table public.taxpayers
      add constraint taxpayers_tax_category_id_fkey
      foreign key (tax_category_id) references public.tax_categories(id)
      on delete restrict;
  end if;
end $$;

alter table public.assessments
  drop constraint if exists assessments_quantity_positive;
alter table public.assessments
  add constraint assessments_quantity_positive check (quantity > 0);

create index if not exists tax_categories_commune_active_idx
  on public.tax_categories(commune_id, active, label);
create index if not exists tariffs_commune_category_validity_idx
  on public.tariffs(commune_id, category_id, valid_from, valid_to);
create index if not exists assessments_commune_period_idx
  on public.assessments(commune_id, period_start, period_end);
create index if not exists taxpayers_tax_category_idx
  on public.taxpayers(tax_category_id);

-- Les catégories et tarifs ne sont plus administrés par le rôle technique.
drop policy if exists categories_read on public.tax_categories;
create policy categories_read on public.tax_categories
for select to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('categories.read'));

drop policy if exists categories_admin on public.tax_categories;
drop policy if exists categories_insert on public.tax_categories;
drop policy if exists categories_update on public.tax_categories;
create policy categories_insert on public.tax_categories
for insert to authenticated
with check (commune_id = public.current_commune()
            and public.has_permission('categories.manage'));
create policy categories_update on public.tax_categories
for update to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('categories.manage'))
with check (commune_id = public.current_commune()
            and public.has_permission('categories.manage'));
-- Pas de politique DELETE : une catégorie ayant servi dans l'historique est conservée.

drop policy if exists tariffs_read on public.tariffs;
create policy tariffs_read on public.tariffs
for select to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('tariffs.read'));

drop policy if exists tariffs_admin on public.tariffs;
drop policy if exists tariffs_insert on public.tariffs;
drop policy if exists tariffs_update_draft on public.tariffs;
create policy tariffs_insert on public.tariffs
for insert to authenticated
with check (commune_id = public.current_commune()
            and public.has_permission('tariffs.manage')
            and approved_by is null and approved_at is null);
create policy tariffs_update_draft on public.tariffs
for update to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('tariffs.manage')
       and approved_at is null)
with check (commune_id = public.current_commune()
            and public.has_permission('tariffs.manage')
            and approved_by is null and approved_at is null);
-- Aucun DELETE direct sur les tarifs.

drop policy if exists assessments_read on public.assessments;
create policy assessments_read on public.assessments
for select to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('assessments.read'));
-- Aucun INSERT/UPDATE/DELETE direct : création par fonction contrôlée uniquement.

-- Seul le secrétaire général habilité peut valider une fiche de contribuable.
-- Le trigger ci-dessous empêche un agent de recensement de changer lui-même le statut.
create or replace function public.guard_taxpayer_status_change()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if tg_op = 'INSERT' then
    if new.status <> 'pending' and not public.has_permission('taxpayers.validate') then
      raise exception 'taxpayer_initial_status_must_be_pending';
    end if;
    return new;
  end if;

  if new.status is distinct from old.status
     and not public.has_permission('taxpayers.validate') then
    raise exception 'taxpayer_status_change_forbidden';
  end if;

  if new.tax_category_id is distinct from old.tax_category_id
     and not public.has_permission('taxpayers.classify') then
    raise exception 'taxpayer_classification_forbidden';
  end if;
  return new;
end;
$$;

drop trigger if exists taxpayers_guard_status_change on public.taxpayers;
create trigger taxpayers_guard_status_change
before insert or update on public.taxpayers
for each row execute function public.guard_taxpayer_status_change();

-- Validation contrôlée d'une fiche recensée.
drop policy if exists taxpayers_validate on public.taxpayers;
create policy taxpayers_validate on public.taxpayers
for update to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('taxpayers.validate'))
with check (commune_id = public.current_commune()
            and public.has_permission('taxpayers.validate'));

-- Classification fiscale distincte de la validation du statut du contribuable.
drop policy if exists taxpayers_classify on public.taxpayers;
create policy taxpayers_classify on public.taxpayers
for update to authenticated
using (commune_id = public.current_commune()
       and public.has_permission('taxpayers.classify'))
with check (commune_id = public.current_commune()
            and public.has_permission('taxpayers.classify'));


-- Vérification de l'appartenance communale des catégories référencées.
create or replace function public.validate_fiscal_category_scope()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare v_category_commune uuid; v_category_active boolean;
begin
  if new.tax_category_id is not null then
    select commune_id, active into v_category_commune, v_category_active
    from public.tax_categories where id = new.tax_category_id;
    if v_category_commune is null or v_category_commune <> new.commune_id then
      raise exception 'tax_category_commune_mismatch';
    end if;
    if not v_category_active then raise exception 'tax_category_inactive'; end if;
  end if;
  return new;
end;
$$;

drop trigger if exists taxpayers_validate_category_scope on public.taxpayers;
create trigger taxpayers_validate_category_scope
before insert or update of tax_category_id, commune_id on public.taxpayers
for each row execute function public.validate_fiscal_category_scope();

create or replace function public.validate_tariff_category_scope()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare v_category_commune uuid; v_category_active boolean;
begin
  select commune_id, active into v_category_commune, v_category_active
  from public.tax_categories where id = new.category_id;
  if v_category_commune is null or v_category_commune <> new.commune_id then
    raise exception 'tariff_category_commune_mismatch';
  end if;
  if not v_category_active then raise exception 'tax_category_inactive'; end if;
  return new;
end;
$$;

drop trigger if exists tariffs_validate_category_scope on public.tariffs;
create trigger tariffs_validate_category_scope
before insert or update of category_id, commune_id on public.tariffs
for each row execute function public.validate_tariff_category_scope();

-- Une fois approuvé, un tarif devient immuable. Les nouvelles décisions créent une nouvelle ligne.
create or replace function public.guard_fiscal_record_mutation()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  if tg_table_name = 'tariffs' then
    if tg_op = 'DELETE' then
      raise exception 'tariff_history_is_preserved';
    end if;
    if old.approved_at is not null then
      raise exception 'approved_tariff_is_immutable';
    end if;
    return new;
  elsif tg_table_name = 'tax_categories' then
    if tg_op = 'DELETE' then
      raise exception 'tax_category_history_is_preserved';
    end if;
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists tariffs_guard_mutation on public.tariffs;
create trigger tariffs_guard_mutation
before update or delete on public.tariffs
for each row execute function public.guard_fiscal_record_mutation();
drop trigger if exists categories_guard_delete on public.tax_categories;
create trigger categories_guard_delete
before delete on public.tax_categories
for each row execute function public.guard_fiscal_record_mutation();

-- Approbation réservée au maire (permission explicite), avec contrôle des chevauchements.
create or replace function public.approve_tariff(p_tariff uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_tariff public.tariffs%rowtype;
  v_category public.tax_categories%rowtype;
begin
  if not public.has_permission('tariffs.approve') then
    raise exception 'permission_denied';
  end if;

  select * into v_tariff
  from public.tariffs
  where id = p_tariff and commune_id = public.current_commune()
  for update;
  if not found then raise exception 'tariff_not_found'; end if;
  if v_tariff.approved_at is not null then raise exception 'tariff_already_approved'; end if;
  if v_tariff.amount <= 0 or length(trim(coalesce(v_tariff.legal_reference,''))) < 8 then
    raise exception 'tariff_legal_reference_or_amount_invalid';
  end if;
  if length(trim(coalesce(v_tariff.billing_unit,''))) = 0 then
    raise exception 'tariff_billing_unit_required';
  end if;

  select * into v_category from public.tax_categories
  where id = v_tariff.category_id
    and commune_id = public.current_commune()
    and active = true
  for update;
  if not found then raise exception 'tax_category_inactive_or_missing'; end if;
  if v_category.collection_scope <> 'commune_encaissement' then
    raise exception 'category_not_collectible_by_municipal_agent';
  end if;
  if length(trim(coalesce(v_category.legal_reference,''))) < 8 then
    raise exception 'category_legal_reference_required';
  end if;

  if exists (
    select 1 from public.tariffs t
    where t.commune_id = v_tariff.commune_id
      and t.category_id = v_tariff.category_id
      and t.approved_at is not null
      and t.id <> v_tariff.id
      and t.valid_from <= coalesce(v_tariff.valid_to, 'infinity'::date)
      and coalesce(t.valid_to, 'infinity'::date) >= v_tariff.valid_from
  ) then
    raise exception 'approved_tariff_period_overlap';
  end if;

  update public.tariffs
  set approved_by = auth.uid(), approved_at = now()
  where id = v_tariff.id and approved_at is null;
  if not found then raise exception 'tariff_not_found_or_already_approved'; end if;
end;
$$;

-- Évaluation calculée côté base : aucun montant transmis par le navigateur.
create or replace function public.create_assessment(
  p_taxpayer_id uuid,
  p_tariff_id uuid,
  p_period_start date,
  p_period_end date,
  p_quantity numeric default 1
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_taxpayer public.taxpayers%rowtype;
  v_tariff public.tariffs%rowtype;
  v_category public.tax_categories%rowtype;
  v_assessment_id uuid;
begin
  if not public.has_permission('assessments.create') then
    raise exception 'permission_denied';
  end if;
  if p_period_start is null or p_period_end is null or p_period_end < p_period_start then
    raise exception 'invalid_assessment_period';
  end if;
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'invalid_assessment_quantity';
  end if;

  select * into v_taxpayer from public.taxpayers
  where id = p_taxpayer_id and commune_id = public.current_commune()
    and status = 'active';
  if not found then raise exception 'taxpayer_not_validated_or_missing'; end if;

  select * into v_tariff from public.tariffs
  where id = p_tariff_id and commune_id = public.current_commune()
    and approved_at is not null;
  if not found then raise exception 'approved_tariff_not_found'; end if;

  select * into v_category from public.tax_categories
  where id = v_tariff.category_id and commune_id = public.current_commune()
    and active = true;
  if not found then raise exception 'tax_category_inactive_or_missing'; end if;
  if v_taxpayer.tax_category_id is distinct from v_tariff.category_id then
    raise exception 'taxpayer_category_tariff_mismatch';
  end if;
  if v_category.collection_scope <> 'commune_encaissement' then
    raise exception 'category_not_collectible_by_municipal_agent';
  end if;

  if p_period_start < v_tariff.valid_from
     or (v_tariff.valid_to is not null and p_period_end > v_tariff.valid_to) then
    raise exception 'assessment_outside_tariff_validity';
  end if;

  insert into public.assessments(
    commune_id, taxpayer_id, tariff_id, period_start, period_end, quantity, amount_due
  ) values (
    public.current_commune(), p_taxpayer_id, p_tariff_id,
    p_period_start, p_period_end, p_quantity,
    round(v_tariff.amount * p_quantity, 2)
  ) returning id into v_assessment_id;

  return v_assessment_id;
end;
$$;

-- Fonctions appelables par les utilisateurs authentifiés ; les contrôles de rôle sont internes.
revoke all on function public.approve_tariff(uuid) from public;
grant execute on function public.approve_tariff(uuid) to authenticated;
revoke all on function public.create_assessment(uuid,uuid,date,date,numeric) from public;
grant execute on function public.create_assessment(uuid,uuid,date,date,numeric) to authenticated;

commit;
