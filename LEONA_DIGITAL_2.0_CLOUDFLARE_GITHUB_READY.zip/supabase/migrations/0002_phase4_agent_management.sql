-- LÉONA DIGITAL 2.0 — Phase 4 : sécurisation des affectations d'agents
-- Migration ADDITIVE : ne recrée ni ne supprime aucune table/colonne/donnée.
-- À exécuter une seule fois dans Supabase SQL Editor après sauvegarde.

begin;

create index if not exists agent_assignments_commune_village_dates_idx
  on public.agent_assignments (commune_id, village_id, starts_on desc);
create index if not exists agent_assignments_agent_dates_idx
  on public.agent_assignments (agent_id, starts_on desc);

create or replace function public.validate_agent_assignment_scope()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_agent_commune uuid;
  v_agent_active boolean;
  v_agent_role public.app_role;
  v_village_commune uuid;
begin
  if new.commune_id is distinct from public.current_commune() then
    raise exception 'assignment_wrong_commune' using errcode = '42501';
  end if;

  select commune_id, active, role
    into v_agent_commune, v_agent_active, v_agent_role
  from public.profiles where id = new.agent_id;
  if not found or v_agent_commune is distinct from new.commune_id or not v_agent_active then
    raise exception 'assignment_agent_invalid_or_inactive' using errcode = '23514';
  end if;
  if v_agent_role not in ('agent_recensement'::public.app_role, 'agent_collecte'::public.app_role) then
    raise exception 'assignment_target_must_be_field_agent' using errcode = '23514';
  end if;

  select commune_id into v_village_commune from public.villages where id = new.village_id;
  if not found or v_village_commune is distinct from new.commune_id then
    raise exception 'assignment_village_wrong_commune' using errcode = '23514';
  end if;
  if new.ends_on is not null and new.ends_on < new.starts_on then
    raise exception 'assignment_end_before_start' using errcode = '23514';
  end if;
  return new;
end;
$$;

 drop trigger if exists agent_assignments_validate_scope on public.agent_assignments;
create trigger agent_assignments_validate_scope
before insert or update of commune_id, agent_id, village_id, assignment_type, starts_on, ends_on
on public.agent_assignments
for each row execute function public.validate_agent_assignment_scope();

revoke all on function public.validate_agent_assignment_scope() from public, anon, authenticated;

comment on function public.validate_agent_assignment_scope() is
'Vérifie que agent et village appartiennent à la Commune de Léona, que le compte est actif et qu il s agit d un agent de terrain. N attribue aucune permission applicative.';

commit;

-- Contrôle après installation (lecture seule) :
-- select indexname from pg_indexes where schemaname='public' and tablename='agent_assignments';
-- select tgname, tgenabled from pg_trigger where tgrelid='public.agent_assignments'::regclass and not tgisinternal;
