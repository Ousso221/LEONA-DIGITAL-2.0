-- Phase 9.6 - Approbation des catégories fiscales par le maire
-- Migration déjà appliquée dans le projet Supabase avant livraison de cette version.
-- Réexécutable : insertion permission idempotente, fonctions remplacées, trigger recréé.

BEGIN;

INSERT INTO public.role_permissions (role, permission)
VALUES ('maire', 'categories.approve')
ON CONFLICT (role, permission) DO NOTHING;

CREATE OR REPLACE FUNCTION public.guard_tax_category_activation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public', 'pg_temp'
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.active = true
           AND NOT public.has_permission('categories.approve') THEN
            RAISE EXCEPTION 'category_activation_requires_mayor_approval';
        END IF;
        RETURN NEW;
    END IF;

    IF NEW.active IS DISTINCT FROM OLD.active
       AND NOT public.has_permission('categories.approve') THEN
        RAISE EXCEPTION 'category_activation_requires_mayor_approval';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS categories_activation_guard
ON public.tax_categories;

CREATE TRIGGER categories_activation_guard
BEFORE INSERT OR UPDATE ON public.tax_categories
FOR EACH ROW
EXECUTE FUNCTION public.guard_tax_category_activation();

CREATE OR REPLACE FUNCTION public.activate_tax_category_by_mayor(
    p_category uuid
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
DECLARE
    v_category public.tax_categories%ROWTYPE;
BEGIN
    IF auth.uid() IS NULL
       OR NOT public.has_permission('categories.approve') THEN
        RAISE EXCEPTION 'permission_denied_category_approval';
    END IF;

    SELECT *
    INTO v_category
    FROM public.tax_categories
    WHERE id = p_category
      AND commune_id = public.current_commune()
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'category_not_found_or_not_authorized';
    END IF;

    IF v_category.active = true THEN
        RAISE EXCEPTION 'category_already_active';
    END IF;

    IF length(trim(coalesce(v_category.legal_reference, ''))) < 8 THEN
        RAISE EXCEPTION 'category_legal_reference_invalid';
    END IF;

    UPDATE public.tax_categories
    SET active = true
    WHERE id = p_category
      AND commune_id = public.current_commune();

    RETURN p_category;
END;
$$;

REVOKE ALL ON FUNCTION public.activate_tax_category_by_mayor(uuid)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.activate_tax_category_by_mayor(uuid)
TO authenticated;

COMMIT;
