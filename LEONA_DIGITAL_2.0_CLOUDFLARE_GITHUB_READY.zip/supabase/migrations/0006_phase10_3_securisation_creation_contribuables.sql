-- Phase 10.3 — Séparer l'examen des imports de la création directe des contribuables
-- La permission imports.review ne doit pas autoriser une insertion directe dans taxpayers.

BEGIN;

DROP POLICY IF EXISTS taxpayers_insert ON public.taxpayers;

CREATE POLICY taxpayers_insert
ON public.taxpayers
FOR INSERT
TO authenticated
WITH CHECK (
    commune_id = current_commune()
    AND has_permission('recensement.manage'::text)
);

COMMIT;
