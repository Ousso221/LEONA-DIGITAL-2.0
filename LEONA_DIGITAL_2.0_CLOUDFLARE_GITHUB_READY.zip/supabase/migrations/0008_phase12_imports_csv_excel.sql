-- LÉONA DIGITAL 2.0 — PHASE 12 : IMPORTS CSV / EXCEL
-- À exécuter une seule fois dans Supabase SQL Editor.
-- Ne supprime aucune table ni donnée existante.

begin;

create or replace function public.submit_taxpayer_import(p_file_name text, p_rows jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_commune uuid := public.current_commune();
  v_batch uuid;
  v_item jsonb;
  v_payload jsonb;
  v_errors jsonb;
  v_row_number integer := 0;
  v_seen text[] := array[]::text[];
  v_code text;
  v_first text;
  v_last text;
  v_village uuid;
  v_village_name text;
  v_valid_count integer := 0;
  v_error_count integer := 0;
begin
  if v_uid is null or not public.has_permission('imports.create') then
    raise exception 'permission_denied_import_create';
  end if;
  if coalesce(jsonb_typeof(p_rows),'') <> 'array' then
    raise exception 'invalid_import_payload_array_required';
  end if;
  if jsonb_array_length(p_rows) < 1 or jsonb_array_length(p_rows) > 1000 then
    raise exception 'invalid_import_rows_count_max_1000';
  end if;
  if v_commune is null then raise exception 'commune_context_missing'; end if;

  insert into public.import_batches(commune_id, submitted_by, status, file_name, row_count)
  values (v_commune, v_uid, 'submitted', left(coalesce(p_file_name,'import'),255), jsonb_array_length(p_rows))
  returning id into v_batch;

  for v_item in select value from jsonb_array_elements(p_rows) loop
    v_row_number := v_row_number + 1;
    v_payload := jsonb_build_object(
      'taxpayer_code', nullif(trim(coalesce(v_item->>'taxpayer_code','')), ''),
      'first_name', nullif(trim(coalesce(v_item->>'first_name','')), ''),
      'last_name', nullif(trim(coalesce(v_item->>'last_name','')), ''),
      'phone', nullif(trim(coalesce(v_item->>'phone','')), ''),
      'village_id', nullif(trim(coalesce(v_item->>'village_id','')), ''),
      'activity', nullif(trim(coalesce(v_item->>'activity','')), ''),
      'tax_category', nullif(trim(coalesce(v_item->>'tax_category','')), ''),
      'location_label', nullif(trim(coalesce(v_item->>'location_label','')), ''),
      'gps_lat', nullif(trim(coalesce(v_item->>'gps_lat','')), ''),
      'gps_lon', nullif(trim(coalesce(v_item->>'gps_lon','')), '')
    );
    v_code := v_payload->>'taxpayer_code';
    v_first := v_payload->>'first_name';
    v_last := v_payload->>'last_name';
    v_errors := '[]'::jsonb;

    if v_code is null then v_errors := v_errors || jsonb_build_array('Code contribuable obligatoire'); end if;
    if v_first is null then v_errors := v_errors || jsonb_build_array('Prénom obligatoire'); end if;
    if v_last is null then v_errors := v_errors || jsonb_build_array('Nom obligatoire'); end if;

    v_village := null;
    if v_payload->>'village_id' is null then
      v_errors := v_errors || jsonb_build_array('Village obligatoire');
    else
      begin
        v_village := (v_payload->>'village_id')::uuid;
        select name into v_village_name from public.villages
        where id = v_village and commune_id = v_commune;
        if not found then
          v_village := null;
          v_errors := v_errors || jsonb_build_array('Village inconnu ou hors de la commune');
        end if;
      exception when others then
        v_village := null;
        v_errors := v_errors || jsonb_build_array('Identifiant de village invalide');
      end;
    end if;

    if v_code is not null then
      if lower(v_code) = any(v_seen) then
        v_errors := v_errors || jsonb_build_array('Code répété dans le fichier');
      else
        v_seen := array_append(v_seen, lower(v_code));
      end if;
      if exists(select 1 from public.taxpayers t where t.commune_id = v_commune and lower(t.taxpayer_code) = lower(v_code)) then
        v_errors := v_errors || jsonb_build_array('Code déjà présent dans le registre');
      end if;
    end if;

    if coalesce(v_payload->>'gps_lat','') <> '' then
      if (v_payload->>'gps_lat') !~ '^-?[0-9]+(\.[0-9]+)?$' then
        v_errors := v_errors || jsonb_build_array('Latitude invalide');
      elsif (v_payload->>'gps_lat')::numeric not between -90 and 90 then
        v_errors := v_errors || jsonb_build_array('Latitude hors limites');
      end if;
    end if;
    if coalesce(v_payload->>'gps_lon','') <> '' then
      if (v_payload->>'gps_lon') !~ '^-?[0-9]+(\.[0-9]+)?$' then
        v_errors := v_errors || jsonb_build_array('Longitude invalide');
      elsif (v_payload->>'gps_lon')::numeric not between -180 and 180 then
        v_errors := v_errors || jsonb_build_array('Longitude hors limites');
      end if;
    end if;
    if (coalesce(v_payload->>'gps_lat','') = '') <> (coalesce(v_payload->>'gps_lon','') = '') then
      v_errors := v_errors || jsonb_build_array('Latitude et longitude doivent être renseignées ensemble');
    end if;

    insert into public.import_rows(batch_id,row_number,payload,validation_errors)
    values (v_batch,v_row_number,
      v_payload || jsonb_build_object('village_id',v_village),v_errors);
    if jsonb_array_length(v_errors) = 0 then v_valid_count := v_valid_count + 1;
    else v_error_count := v_error_count + 1; end if;
  end loop;

  return jsonb_build_object('batch_id',v_batch,'row_count',v_row_number,
    'valid_count',v_valid_count,'error_count',v_error_count,'status','submitted');
end;
$$;

create or replace function public.review_taxpayer_import(p_batch uuid, p_decision text, p_reason text default null)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_commune uuid := public.current_commune();
  v_batch public.import_batches%rowtype;
  v_row record;
  v_inserted integer := 0;
begin
  if v_uid is null or public.current_role() <> 'secretaire_general'::public.app_role
     or not public.has_permission('imports.review') then
    raise exception 'permission_denied_import_review';
  end if;
  if coalesce(p_decision,'') not in ('approve','reject') then raise exception 'invalid_import_decision'; end if;
  if p_decision = 'reject' and length(trim(coalesce(p_reason,''))) < 5 then
    raise exception 'rejection_reason_required_min_5_chars';
  end if;

  select * into v_batch from public.import_batches
  where id = p_batch and commune_id = v_commune
  for update;
  if not found then raise exception 'import_batch_not_found'; end if;
  if v_batch.status <> 'submitted' then raise exception 'import_batch_not_pending'; end if;

  if p_decision = 'reject' then
    update public.import_batches set status='rejected', review_reason=trim(p_reason),
      reviewed_by=v_uid, reviewed_at=now() where id=p_batch;
    return jsonb_build_object('batch_id',p_batch,'status','rejected','inserted_count',0);
  end if;

  if exists(select 1 from public.import_rows r where r.batch_id=p_batch and jsonb_array_length(r.validation_errors)>0) then
    raise exception 'import_contains_invalid_rows';
  end if;

  -- Contrôle final anti-doublon juste avant intégration.
  if exists(
    select 1 from public.import_rows r
    join public.taxpayers t on t.commune_id=v_commune
      and lower(t.taxpayer_code)=lower(r.payload->>'taxpayer_code')
    where r.batch_id=p_batch
  ) then raise exception 'duplicate_taxpayer_code_since_submission'; end if;

  for v_row in select payload from public.import_rows where batch_id=p_batch order by row_number loop
    insert into public.taxpayers(
      commune_id,taxpayer_code,first_name,last_name,phone,village_id,activity,
      tax_category,location_label,gps_lat,gps_lon,status,created_by
    ) values (
      v_commune,v_row.payload->>'taxpayer_code',v_row.payload->>'first_name',v_row.payload->>'last_name',
      v_row.payload->>'phone',(v_row.payload->>'village_id')::uuid,v_row.payload->>'activity',
      v_row.payload->>'tax_category',v_row.payload->>'location_label',
      nullif(v_row.payload->>'gps_lat','')::numeric,nullif(v_row.payload->>'gps_lon','')::numeric,
      'pending'::public.taxpayer_status,v_batch.submitted_by
    );
    v_inserted := v_inserted + 1;
  end loop;

  update public.import_batches set status='approved', review_reason=null,
    reviewed_by=v_uid, reviewed_at=now() where id=p_batch;
  return jsonb_build_object('batch_id',p_batch,'status','approved','inserted_count',v_inserted);
end;
$$;

revoke all on function public.submit_taxpayer_import(text,jsonb) from public, anon;
revoke all on function public.review_taxpayer_import(uuid,text,text) from public, anon;
grant execute on function public.submit_taxpayer_import(text,jsonb) to authenticated;
grant execute on function public.review_taxpayer_import(uuid,text,text) to authenticated;

commit;
