const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event) => {
  const headers = {'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  if(event.httpMethod !== 'POST') return {statusCode:405,headers,body:JSON.stringify({error:'method_not_allowed'})};
  let body;
  try { body=JSON.parse(event.body||'{}'); } catch { return {statusCode:400,headers,body:JSON.stringify({error:'invalid_request'})}; }
  const taxpayerId=String(body.taxpayer_id||'').trim();
  const phone=String(body.phone||'').replace(/[^\d+]/g,'');
  if(!taxpayerId||taxpayerId.length>40||phone.length<8||phone.length>24) return {statusCode:400,headers,body:JSON.stringify({error:'invalid_request'})};
  if(!process.env.SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY) return {statusCode:503,headers,body:JSON.stringify({error:'service_unavailable'})};
  const db=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
  // NOTE: Rate limiting durable (Redis/Upstash/API gateway) must be added before production.
  const {data:taxpayer,error}=await db.from('taxpayers').select('id').eq('taxpayer_code',taxpayerId).eq('phone',phone).eq('status','active').maybeSingle();
  if(error||!taxpayer) return {statusCode:404,headers,body:JSON.stringify({error:'not_found'})};
  const {data:rows,error:dueError}=await db.from('v_taxpayer_balances').select('assessment_id,label,balance').eq('taxpayer_id',taxpayer.id).gt('balance',0);
  if(dueError) return {statusCode:503,headers,body:JSON.stringify({error:'service_unavailable'})};
  return {statusCode:200,headers,body:JSON.stringify({dues:(rows||[]).map(x=>({assessment_id:x.assessment_id,label:x.label,balance:x.balance}))})};
};
