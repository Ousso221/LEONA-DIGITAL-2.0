const { createClient } = require('@supabase/supabase-js');

const HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store, no-cache, must-revalidate',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Vary': 'Authorization'
};
const COMMUNE_ID = '4ff58202-4615-4d1f-8412-d06fdc0967ad';
const ALLOWED_ROLES = new Set([
  'maire', 'secretaire_general', 'receveur_municipal', 'controleur',
  'agent_recensement', 'agent_collecte'
]);
const response = (statusCode, error, extra = {}) => ({
  statusCode, headers: HEADERS, body: JSON.stringify(error ? { error, ...extra } : extra)
});
const clean = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return response(405, 'method_not_allowed');
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY || !process.env.SUPABASE_ANON_KEY) {
    return response(503, 'service_unavailable');
  }
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { return response(400, 'invalid_request'); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return response(400, 'invalid_request');

  const authHeader = event.headers?.authorization || event.headers?.Authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(authHeader);
  if (!match) return response(401, 'unauthorized');
  const token = match[1];

  const authClient = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false }
  });

  try {
    const { data: authData, error: authError } = await authClient.auth.getUser(token);
    if (authError || !authData?.user) return response(401, 'unauthorized');
    const actorId = authData.user.id;
    const { data: actor, error: actorError } = await admin.from('profiles')
      .select('id,commune_id,role,active').eq('id', actorId).maybeSingle();
    if (actorError || !actor || !actor.active || actor.commune_id !== COMMUNE_ID) return response(403, 'forbidden');
    const { data: perms, error: permError } = await admin.from('role_permissions')
      .select('permission').eq('role', actor.role).in('permission', ['users.manage', 'agents.manage']);
    const granted = new Set((perms || []).map(x => x.permission));
    if (permError || !granted.has('users.manage') || !granted.has('agents.manage')) return response(403, 'forbidden');

    if (body.action === 'create') {
      const fullName = clean(body.full_name, 160);
      const email = clean(body.email, 254).toLowerCase();
      const role = clean(body.role, 40);
      if (!fullName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !ALLOWED_ROLES.has(role)) return response(400, 'invalid_request');
      const siteUrl = (process.env.URL || process.env.DEPLOY_PRIME_URL || '').replace(/\/$/, '');
      if (!siteUrl || !/^https:\/\//i.test(siteUrl)) return response(503, 'service_unavailable');
      const { data: invited, error: inviteError } = await admin.auth.admin.inviteUserByEmail(email, {
        data: { full_name: fullName, commune_code: 'SN-LOU-LEONA' },
        redirectTo: `${siteUrl}/activation`
      });
      if (inviteError) {
        const duplicate = /already|registered|exists/i.test(inviteError.message || '');
        return response(duplicate ? 409 : 400, duplicate ? 'email_already_exists' : 'invalid_request');
      }
      const userId = invited?.user?.id;
      if (!userId) return response(502, 'service_unavailable');
      const { error: profileError } = await admin.from('profiles').insert({
        id: userId, commune_id: COMMUNE_ID, full_name: fullName, role, active: true
      });
      if (profileError) {
        await admin.auth.admin.deleteUser(userId);
        console.error('profile_insert_failed', profileError.code);
        return response(500, 'service_unavailable');
      }
      const { error: auditError } = await admin.from('audit_logs').insert({
        commune_id: COMMUNE_ID, actor_id: actorId, table_name: 'profiles', record_id: userId,
        operation: 'INVITE', old_data: null,
        new_data: { full_name: fullName, role, active: true, email },
        reason: 'Invitation de compte par administration technique'
      });
      if (auditError) {
        await admin.from('profiles').delete().eq('id', userId);
        await admin.auth.admin.deleteUser(userId);
        console.error('invite_audit_failed', auditError.code);
        return response(500, 'service_unavailable');
      }
      return response(201, null, { ok: true, user_id: userId });
    }

    if (body.action === 'update') {
      const userId = clean(body.user_id, 64);
      const fullName = clean(body.full_name, 160);
      const role = clean(body.role, 40);
      if (!/^[0-9a-f-]{36}$/i.test(userId) || !fullName || !ALLOWED_ROLES.has(role) || typeof body.active !== 'boolean') return response(400, 'invalid_request');
      if (userId === actorId) return response(403, 'forbidden');
      const { data: target, error: targetError } = await admin.from('profiles')
        .select('id,commune_id,full_name,role,active').eq('id', userId).maybeSingle();
      if (targetError || !target || target.commune_id !== COMMUNE_ID || target.role === 'administrateur_technique') return response(404, 'invalid_request');
      const before = { full_name: target.full_name, role: target.role, active: target.active };
      const after = { full_name: fullName, role, active: body.active };
      if (role !== target.role || body.active !== target.active) {
        const { count, error: assignmentError } = await admin.from('agent_assignments')
          .select('id', { count: 'exact', head: true }).eq('agent_id', userId)
          .or(`ends_on.is.null,ends_on.gte.${new Date().toISOString().slice(0,10)}`);
        if (assignmentError) return response(500, 'service_unavailable');
        if ((count || 0) > 0) return response(409, 'assignment_must_be_closed');
      }
      const { error: updateError } = await admin.from('profiles').update(after).eq('id', userId).eq('commune_id', COMMUNE_ID);
      if (updateError) return response(500, 'service_unavailable');
      const { error: auditError } = await admin.from('audit_logs').insert({
        commune_id: COMMUNE_ID, actor_id: actorId, table_name: 'profiles', record_id: userId,
        operation: 'UPDATE', old_data: before, new_data: after,
        reason: 'Modification de compte par administration technique'
      });
      if (auditError) {
        await admin.from('profiles').update(before).eq('id', userId);
        console.error('profile_update_audit_failed', auditError.code);
        return response(500, 'service_unavailable');
      }
      return response(200, null, { ok: true });
    }
    return response(400, 'invalid_request');
  } catch (error) {
    console.error('manage_agent_unexpected_error', error?.message || 'unknown');
    return response(500, 'service_unavailable');
  }
};
