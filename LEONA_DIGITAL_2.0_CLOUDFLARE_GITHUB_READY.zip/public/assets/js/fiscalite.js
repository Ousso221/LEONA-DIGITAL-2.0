(() => {
  'use strict';

  const cfg = window.APP_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const COMMUNE_ID = '4ff58202-4615-4d1f-8412-d06fdc0967ad';
  const state = { db: null, userId: null, role: null, permissions: new Set(), categories: [], tariffs: [], assessmentTaxpayers: [], initialized: false };
  const has = (permission) => state.permissions.has(permission);

  function message(id, value, type = '') {
    const node = $(id);
    if (!node) return;
    node.textContent = value;
    node.className = `form-message ${type}`.trim();
  }

  function dateLabel(value) {
    if (!value) return 'Sans date de fin';
    const d = new Date(`${value}T00:00:00`);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('fr-FR');
  }

  function categoryNatureLabel(value) {
    return ({ impot_local: 'Impôt local', taxe_communale: 'Taxe communale', redevance_domaine: 'Redevance du domaine', service_administratif: 'Service administratif', recette_partagee: 'Recette partagée', reference_etat: 'Référence fiscale de l’État' })[value] || value || '—';
  }

  function collectionScopeLabel(value) {
    return ({ commune_encaissement: 'Encaissement communal', etat_recouvrement: 'Recouvrement par l’État', quote_part: 'Quote-part', reference_seule: 'Référence informative' })[value] || value || '—';
  }

  function money(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `${n.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} FCFA` : '—';
  }

  function cell(value) {
    const td = document.createElement('td');
    td.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
    return td;
  }

  function makeTable(headers, rows) {
    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const thead = document.createElement('thead');
    const hr = document.createElement('tr');
    headers.forEach((label) => {
      const th = document.createElement('th');
      th.textContent = label;
      hr.append(th);
    });
    thead.append(hr);
    table.append(thead);
    const tbody = document.createElement('tbody');
    rows.forEach((row) => tbody.append(row));
    table.append(tbody);
    wrap.append(table);
    return wrap;
  }

  function setSelect(select, placeholder, rows, labelFn, valueFn) {
    if (!select) return;
    const previous = select.value;
    select.replaceChildren(new Option(placeholder, ''));
    rows.forEach((row) => select.add(new Option(labelFn(row), valueFn(row))));
    if (previous && [...select.options].some((option) => option.value === previous)) select.value = previous;
  }

  async function init() {
    if (!window.supabase || !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) return;
    state.db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    const { data: sessionData, error: sessionError } = await state.db.auth.getSession();
    if (sessionError || !sessionData?.session) return;
    state.userId = sessionData.session.user.id;
    const { data: profile, error: profileError } = await state.db.from('profiles')
      .select('role,active,commune_id').eq('id', state.userId).single();
    if (profileError || !profile?.active || profile.commune_id !== COMMUNE_ID) return;
    state.role = profile.role;
    const { data: permissions, error: permissionError } = await state.db.from('role_permissions')
      .select('permission').eq('role', profile.role);
    if (permissionError) return;
    state.permissions = new Set((permissions || []).map((item) => item.permission));
    state.initialized = true;
    if (has('categories.read') || has('categories.manage') || has('tariffs.read') || has('tariffs.manage') || has('tariffs.approve') || has('assessments.read') || has('assessments.create')) {
      const nav = $('nav-fiscalite');
      if (nav) {
        nav.classList.remove('hidden');
        nav.addEventListener('click', () => {
          document.querySelectorAll('[id^="view-"]').forEach((section) => section.classList.add('hidden'));
          $('view-fiscalite')?.classList.remove('hidden');
          document.querySelectorAll('.nav-btn').forEach((button) => button.classList.toggle('active', button === nav));
          loadFiscalite();
        });
      }
    }
    if (has('categories.manage')) $('category-manager')?.classList.remove('hidden');
    if (state.role === 'secretaire_general') $('secretary-overview')?.classList.remove('hidden');
    if (has('taxpayers.classify')) $('taxpayer-classifier')?.classList.remove('hidden');
    if (has('tariffs.manage')) $('tariff-manager')?.classList.remove('hidden');
    if (has('assessments.create')) $('assessment-manager')?.classList.remove('hidden');
    $('category-form')?.addEventListener('submit', createCategory);
    $('tariff-form')?.addEventListener('submit', createTariff);
    $('assessment-form')?.addEventListener('submit', createAssessment);
    $('categories-refresh')?.addEventListener('click', loadCategories);
    $('classification-refresh')?.addEventListener('click', loadTaxpayerClassification);
    $('tariffs-refresh')?.addEventListener('click', loadTariffs);
    $('assessments-refresh')?.addEventListener('click', loadAssessments);
    $('classification-search')?.addEventListener('input', loadTaxpayerClassification);
    $('classification-status')?.addEventListener('change', loadTaxpayerClassification);
    $('assessment-tariff')?.addEventListener('change', refreshAssessmentTaxpayerOptions);
    const today = new Date().toISOString().slice(0, 10);
    if ($('tariff-start') && !$('tariff-start').value) $('tariff-start').value = today;
    if ($('assessment-start') && !$('assessment-start').value) $('assessment-start').value = today;
    if ($('assessment-end') && !$('assessment-end').value) $('assessment-end').value = today;
    const status = $('fiscal-status');
    if (status) status.textContent = 'Permissions contrôlées';
  }

  async function loadCategories() {
    const root = $('categories-content');
    if (!root || !state.initialized) return;
    if (!has('categories.read') && !has('categories.manage')) {
      root.textContent = 'Consultation des catégories non autorisée.';
      return;
    }
    root.textContent = 'Chargement des catégories…';
    const { data, error } = await state.db.from('tax_categories')
      .select('id,code,label,description,legal_reference,revenue_type,collection_scope,active,created_at')
      .eq('commune_id', COMMUNE_ID).order('label').limit(500);
    root.replaceChildren();
    if (error) {
      root.textContent = 'Impossible de lire les catégories. Vérifiez la migration Phase 5 et les permissions RLS.';
      console.error('Phase 5 categories:', error);
      return;
    }
    state.categories = data || [];
    if (!state.categories.length) root.textContent = 'Aucune catégorie enregistrée. Les catégories officielles devront être saisies à partir des décisions vérifiées.';
    else {
      const rows = state.categories.map((item) => {
        const tr = document.createElement('tr');
        tr.append(cell(item.code), cell(item.label), cell(categoryNatureLabel(item.revenue_type)), cell(collectionScopeLabel(item.collection_scope)), cell(item.description), cell(item.legal_reference), cell(item.active ? 'Active' : 'En attente du maire'));
        const action = document.createElement('td');
        if (!item.active && has('categories.approve')) {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = 'btn btn-small';
          button.textContent = 'Approuver et activer';
          button.addEventListener('click', () => approveCategory(item.id, button));
          action.append(button);
        } else {
          action.textContent = item.active ? 'Validée' : 'En attente de validation';
        }
        tr.append(action);
        return tr;
      });
      root.append(makeTable(['Code', 'Libellé', 'Nature', 'Recouvrement', 'Critères / description', 'Référence juridique', 'État', 'Action'], rows));
    }
    setSelect($('tariff-category'), 'Choisir une catégorie active', state.categories.filter((c) => c.active && c.collection_scope === 'commune_encaissement'), (c) => `${c.code} — ${c.label}`, (c) => c.id);
  }

  async function createCategory(event) {
    event.preventDefault();
    if (!has('categories.manage')) return message('category-message', 'Permission categories.manage requise.', 'error');
    const payload = {
      commune_id: COMMUNE_ID,
      code: $('category-code').value.trim(),
      label: $('category-label').value.trim(),
      description: $('category-description').value.trim() || null,
      revenue_type: $('category-revenue-type').value,
      collection_scope: $('category-collection-scope').value,
      legal_reference: $('category-legal').value.trim(),
      active: false
    };
    if (!payload.code || !payload.label || payload.legal_reference.length < 8) return message('category-message', 'Code, libellé et référence juridique complète sont obligatoires.', 'error');
    $('category-save').disabled = true;
    const { error } = await state.db.from('tax_categories').insert(payload);
    $('category-save').disabled = false;
    if (error) {
      console.error(error);
      return message('category-message', error.code === '23505' ? 'Ce code de catégorie existe déjà.' : `Enregistrement refusé : ${error.message}`, 'error');
    }
    $('category-form').reset();
    message('category-message', 'Catégorie enregistrée inactive. Elle sera activée uniquement après approbation du maire.', 'success');
    await loadCategories();
  }

  async function approveCategory(id, button) {
    if (!has('categories.approve')) return;
    if (!window.confirm('Confirmez-vous avoir vérifié la base juridique et les pièces officielles justifiant cette catégorie ? Cette action l’activera pour la commune.')) return;
    button.disabled = true;
    const { error } = await state.db.rpc('activate_tax_category_by_mayor', { p_category: id });
    button.disabled = false;
    if (error) {
      console.error('Approbation catégorie:', error);
      window.alert(`Activation refusée : ${error.message}`);
      return;
    }
    window.alert('Catégorie approuvée et activée. La décision est inscrite dans le journal d’audit.');
    await loadCategories();
    await loadTariffs();
    await loadAssessmentOptions();
  }

  async function loadTaxpayerClassification() {
    const root = $('classification-content');
    if (!root || !state.initialized) return;
    if (!has('taxpayers.classify')) {
      root.textContent = 'La classification des contribuables est réservée au Secrétaire général habilité.';
      return;
    }
    root.textContent = 'Chargement des contribuables…';
    const { data, error } = await state.db.from('taxpayers')
      .select('id,taxpayer_code,first_name,last_name,activity,status,tax_category,tax_category_id')
      .eq('commune_id', COMMUNE_ID).order('last_name').limit(1000);
    root.replaceChildren();
    if (error) {
      root.textContent = 'Impossible de lire les fiches de contribuables pour classification.';
      console.error('Phase 5 taxpayer classification:', error);
      return;
    }
    if (!data?.length) {
      root.textContent = 'Aucun contribuable enregistré.';
      return;
    }
    const term = ($('classification-search')?.value || '').trim().toLocaleLowerCase('fr');
    const statusFilter = $('classification-status')?.value || 'all';
    const filtered = data.filter((t) => {
      const haystack = `${t.taxpayer_code || ''} ${t.first_name || ''} ${t.last_name || ''} ${t.activity || ''}`.toLocaleLowerCase('fr');
      return (!term || haystack.includes(term)) && (statusFilter === 'all' || t.status === statusFilter);
    });
    if (!filtered.length) { root.textContent = 'Aucun contribuable ne correspond aux filtres sélectionnés.'; return; }
    const activeCategories = state.categories.filter((c) => c.active);
    const rows = filtered.map((taxpayer) => {
      const tr = document.createElement('tr');
      tr.append(cell(taxpayer.taxpayer_code), cell(`${taxpayer.first_name} ${taxpayer.last_name}`), cell(taxpayer.activity), cell(taxpayer.status));
      const selectCell = document.createElement('td');
      const select = document.createElement('select');
      select.add(new Option('Non classé', ''));
      activeCategories.forEach((category) => select.add(new Option(`${category.code} — ${category.label}`, category.id)));
      select.value = taxpayer.tax_category_id || '';
      selectCell.append(select);
      tr.append(selectCell);
      const actionCell = document.createElement('td');
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'btn btn-small'; button.textContent = 'Enregistrer';
      button.addEventListener('click', async () => {
        const selected = activeCategories.find((c) => c.id === select.value);
        button.disabled = true;
        const { error: updateError } = await state.db.from('taxpayers').update({
          tax_category_id: selected?.id || null,
          tax_category: selected?.label || null
        }).eq('id', taxpayer.id);
        button.disabled = false;
        if (updateError) {
          console.error(updateError);
          window.alert(`Classification refusée : ${updateError.message}`);
        } else {
          window.alert('Classification fiscale enregistrée.');
          await loadTaxpayerClassification();
        }
      });
      actionCell.append(button);
      if (has('taxpayers.validate') && taxpayer.status === 'pending') {
        const validateButton = document.createElement('button');
        validateButton.type = 'button'; validateButton.className = 'btn btn-small'; validateButton.textContent = 'Valider la fiche';
        validateButton.addEventListener('click', async () => {
          if (!window.confirm('Confirmer que les informations du contribuable ont été vérifiées ?')) return;
          validateButton.disabled = true;
          const { error: validationError } = await state.db.from('taxpayers').update({ status: 'active' }).eq('id', taxpayer.id).eq('status', 'pending');
          validateButton.disabled = false;
          if (validationError) { console.error(validationError); window.alert(`Validation refusée : ${validationError.message}`); }
          else { window.alert('Fiche validée.'); await loadTaxpayerClassification(); }
        });
        actionCell.append(document.createTextNode(' '), validateButton);
      }
      tr.append(actionCell);
      return tr;
    });
    root.append(makeTable(['Code', 'Contribuable', 'Activité recensée', 'Statut', 'Catégorie officielle', 'Action'], rows));
  }

  async function loadTariffs() {
    const root = $('tariffs-content');
    if (!root || !state.initialized) return;
    if (!has('tariffs.read') && !has('tariffs.manage') && !has('tariffs.approve')) {
      root.textContent = 'Consultation des tarifs non autorisée.';
      return;
    }
    root.textContent = 'Chargement des tarifs…';
    const { data, error } = await state.db.from('tariffs')
      .select('id,category_id,amount,currency,billing_unit,valid_from,valid_to,legal_reference,approved_by,approved_at,created_at')
      .eq('commune_id', COMMUNE_ID).order('valid_from', { ascending: false }).limit(500);
    root.replaceChildren();
    if (error) {
      root.textContent = 'Impossible de lire les tarifs. Vérifiez la migration Phase 5 et les permissions RLS.';
      console.error('Phase 5 tariffs:', error);
      return;
    }
    state.tariffs = data || [];
    const categoryNames = new Map(state.categories.map((c) => [c.id, `${c.code} — ${c.label}`]));
    if (!state.tariffs.length) root.textContent = 'Aucun tarif enregistré. Aucun montant officiel n’a été ajouté automatiquement.';
    else {
      const rows = state.tariffs.map((item) => {
        const tr = document.createElement('tr');
        tr.append(cell(categoryNames.get(item.category_id) || 'Catégorie non consultable'), cell(money(item.amount)), cell(item.billing_unit), cell(dateLabel(item.valid_from)), cell(item.valid_to ? dateLabel(item.valid_to) : 'Sans échéance'), cell(item.legal_reference), cell(item.approved_at ? `Approuvé le ${dateLabel(item.approved_at.slice(0,10))}` : 'Brouillon'));
        const action = document.createElement('td');
        if (!item.approved_at && has('tariffs.approve')) {
          const button = document.createElement('button');
          button.type = 'button'; button.className = 'btn btn-small'; button.textContent = 'Approuver';
          button.addEventListener('click', () => approveTariff(item.id, button));
          action.append(button);
        } else action.textContent = item.approved_at ? 'Verrouillé' : 'En attente du maire';
        tr.append(action);
        return tr;
      });
      root.append(makeTable(['Catégorie', 'Montant unitaire', 'Unité', 'Début', 'Fin', 'Référence', 'Statut', 'Action'], rows));
    }
    setSelect($('assessment-tariff'), 'Choisir un tarif approuvé', state.tariffs.filter((t) => !!t.approved_at && state.categories.some((c) => c.id === t.category_id && c.collection_scope === 'commune_encaissement')), (t) => {
      const cat = categoryNames.get(t.category_id) || 'Catégorie';
      return `${cat} — ${money(t.amount)} ${t.billing_unit} (${dateLabel(t.valid_from)} au ${t.valid_to ? dateLabel(t.valid_to) : '…'})`;
    }, (t) => t.id);
  }

  async function createTariff(event) {
    event.preventDefault();
    if (!has('tariffs.manage')) return message('tariff-message', 'Permission tariffs.manage requise.', 'error');
    const amount = Number($('tariff-amount').value);
    const start = $('tariff-start').value;
    const end = $('tariff-end').value || null;
    if (!Number.isFinite(amount) || amount <= 0 || !start || (end && end < start)) return message('tariff-message', 'Vérifiez le montant et les dates de validité.', 'error');
    const payload = {
      commune_id: COMMUNE_ID, category_id: $('tariff-category').value,
      amount, currency: 'XOF', billing_unit: $('tariff-unit').value.trim(),
      valid_from: start, valid_to: end, legal_reference: $('tariff-legal').value.trim(),
      approved_by: null, approved_at: null
    };
    if (!payload.category_id || !payload.billing_unit || payload.legal_reference.length < 8) return message('tariff-message', 'Catégorie, unité et référence officielle complète obligatoires.', 'error');
    $('tariff-save').disabled = true;
    const { error } = await state.db.from('tariffs').insert(payload);
    $('tariff-save').disabled = false;
    if (error) {
      console.error(error);
      return message('tariff-message', `Création du brouillon impossible : ${error.message}`, 'error');
    }
    $('tariff-form').reset();
    $('tariff-start').value = new Date().toISOString().slice(0,10);
    message('tariff-message', 'Brouillon enregistré. Il ne sera utilisable qu’après approbation par le maire.', 'success');
    await loadTariffs();
  }

  async function approveTariff(id, button) {
    if (!has('tariffs.approve')) return;
    if (!window.confirm('Confirmez-vous que la décision officielle, le montant, l’unité et les dates ont été vérifiés ?')) return;
    button.disabled = true;
    const { error } = await state.db.rpc('approve_tariff', { p_tariff: id });
    button.disabled = false;
    if (error) {
      console.error(error);
      window.alert(`Approbation refusée : ${error.message}`);
      return;
    }
    window.alert('Tarif approuvé. Il est désormais verrouillé et peut servir aux évaluations dans sa période de validité.');
    await loadTariffs();
  }

  async function loadAssessmentOptions() {
    if (has('assessments.create')) {
      const { data: taxpayers, error: taxpayerError } = await state.db.from('taxpayers')
        .select('id,taxpayer_code,first_name,last_name,tax_category_id').eq('commune_id', COMMUNE_ID).eq('status', 'active')
        .order('last_name').limit(2000);
      if (taxpayerError) console.error('Phase 5 taxpayers:', taxpayerError);
      state.assessmentTaxpayers = taxpayers || [];
      refreshAssessmentTaxpayerOptions();
    }
  }

  function refreshAssessmentTaxpayerOptions() {
    const tariff = state.tariffs.find((t) => t.id === $('assessment-tariff')?.value && !!t.approved_at);
    const matching = tariff ? state.assessmentTaxpayers.filter((t) => t.tax_category_id === tariff.category_id) : state.assessmentTaxpayers;
    setSelect($('assessment-taxpayer'), tariff ? 'Choisir un contribuable de cette catégorie' : 'Choisir un contribuable validé', matching, (t) => `${t.taxpayer_code} — ${t.first_name} ${t.last_name}`, (t) => t.id);
  }

  async function createAssessment(event) {
    event.preventDefault();
    if (!has('assessments.create')) return message('assessment-message', 'Permission assessments.create requise.', 'error');
    const quantity = Number($('assessment-quantity').value);
    const start = $('assessment-start').value;
    const end = $('assessment-end').value;
    if (!Number.isFinite(quantity) || quantity <= 0 || !start || !end || end < start) return message('assessment-message', 'Vérifiez la quantité et la période.', 'error');
    const payload = {
      p_taxpayer_id: $('assessment-taxpayer').value,
      p_tariff_id: $('assessment-tariff').value,
      p_period_start: start,
      p_period_end: end,
      p_quantity: quantity
    };
    if (!payload.p_taxpayer_id || !payload.p_tariff_id) return message('assessment-message', 'Sélectionnez un contribuable validé et un tarif approuvé.', 'error');
    $('assessment-save').disabled = true;
    const { data, error } = await state.db.rpc('create_assessment', payload);
    $('assessment-save').disabled = false;
    if (error) {
      console.error(error);
      const detail = error.message.includes('duplicate') || error.code === '23505' ? 'Une évaluation identique existe déjà pour cette période.' : `Évaluation refusée : ${error.message}`;
      return message('assessment-message', detail, 'error');
    }
    message('assessment-message', `Évaluation enregistrée (référence ${data}). Le montant a été calculé côté serveur.`, 'success');
    await loadAssessments();
  }

  async function loadAssessments() {
    const root = $('assessments-content');
    if (!root || !state.initialized) return;
    if (!has('assessments.read') && !has('assessments.create')) {
      root.textContent = 'Consultation des évaluations non autorisée.';
      return;
    }
    root.textContent = 'Chargement des évaluations…';
    const { data, error } = await state.db.from('assessments')
      .select('id,taxpayer_id,tariff_id,period_start,period_end,quantity,amount_due,created_at')
      .eq('commune_id', COMMUNE_ID).order('created_at', { ascending: false }).limit(500);
    root.replaceChildren();
    if (error) {
      root.textContent = 'Impossible de lire les évaluations. Vérifiez assessments.read et les règles RLS.';
      console.error('Phase 5 assessments:', error);
      return;
    }
    if (!data?.length) {
      root.textContent = 'Aucune évaluation fiscale enregistrée.';
      return;
    }
    const taxpayerIds = [...new Set(data.map((a) => a.taxpayer_id))];
    const tariffIds = [...new Set(data.map((a) => a.tariff_id))];
    const [taxpayersResult, tariffsResult] = await Promise.all([
      state.db.from('taxpayers').select('id,taxpayer_code,first_name,last_name').in('id', taxpayerIds),
      state.db.from('tariffs').select('id,category_id,amount,billing_unit').in('id', tariffIds)
    ]);
    const taxpayerNames = new Map((taxpayersResult.data || []).map((t) => [t.id, `${t.taxpayer_code} — ${t.first_name} ${t.last_name}`]));
    const tariffMap = new Map((tariffsResult.data || []).map((t) => [t.id, t]));
    const categoryNames = new Map(state.categories.map((c) => [c.id, c.label]));
    const rows = data.map((a) => {
      const tariff = tariffMap.get(a.tariff_id);
      const tr = document.createElement('tr');
      tr.append(cell(taxpayerNames.get(a.taxpayer_id) || 'Contribuable'), cell(tariff ? categoryNames.get(tariff.category_id) || 'Catégorie' : 'Tarif'), cell(`${a.quantity} × ${tariff ? money(tariff.amount) : '—'}`), cell(money(a.amount_due)), cell(`${dateLabel(a.period_start)} au ${dateLabel(a.period_end)}`));
      return tr;
    });
    root.append(makeTable(['Contribuable', 'Catégorie', 'Calcul', 'Montant dû', 'Période'], rows));
  }

  async function loadFiscalite() {
    await ready;
    if (!state.initialized) {
      const status = $('fiscal-status');
      if (status) status.textContent = 'Accès non disponible';
      return;
    }
    await loadCategories();
    await loadTaxpayerClassification();
    await loadTariffs();
    await loadAssessmentOptions();
    await loadAssessments();
    await loadSecretaryOverview();
  }

  async function loadSecretaryOverview() {
    if (state.role !== 'secretaire_general') return;
    const ids = ['sg-categories-count', 'sg-pending-taxpayers', 'sg-pending-tariffs', 'sg-assessments-count'];
    ids.forEach((id) => { if ($(id)) $(id).textContent = '…'; });
    const queries = await Promise.all([
      state.db.from('taxpayers').select('id', { count: 'exact', head: true }).eq('commune_id', COMMUNE_ID).eq('status', 'pending'),
      state.db.from('tariffs').select('id', { count: 'exact', head: true }).eq('commune_id', COMMUNE_ID).is('approved_at', null),
      state.db.from('assessments').select('id', { count: 'exact', head: true }).eq('commune_id', COMMUNE_ID)
    ]);
    $('sg-categories-count').textContent = String(state.categories.filter((c) => c.active).length);
    $('sg-pending-taxpayers').textContent = queries[0].error ? '—' : String(queries[0].count ?? 0);
    $('sg-pending-tariffs').textContent = queries[1].error ? '—' : String(queries[1].count ?? 0);
    $('sg-assessments-count').textContent = queries[2].error ? '—' : String(queries[2].count ?? 0);
    queries.forEach((q, i) => { if (q.error) console.warn('Synthèse secrétaire général indisponible pour indicateur', i, q.error); });
  }

  window.loadFiscalite = loadFiscalite;
  window.loadTaxCategoryOptions = async () => { await ready; if (state.initialized) await loadCategories(); };
  const ready = init().catch((error) => {
    console.error('Initialisation Phase 5:', error);
    const status = $('fiscal-status');
    if (status) status.textContent = 'Erreur de chargement';
  });
})();
