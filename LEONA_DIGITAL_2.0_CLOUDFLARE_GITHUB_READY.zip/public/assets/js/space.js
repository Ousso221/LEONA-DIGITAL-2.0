(() => {
  'use strict';

  const cfg = window.APP_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const state = { db: null, profile: null, userId: null, session: null, permissions: new Set(), activeView: 'dashboard', villages: [], agents: [], assignments: [], financeRows: [], fiscalRows: [], mapTaxpayers: [], mapFiscalRows: [], mapCategories: [], map: null, mapCluster: null, mapMarkers: [], mapVillageChart: null, mapActivityChart: null };
  const LEONA_COMMUNE_ID = '4ff58202-4615-4d1f-8412-d06fdc0967ad';

  function showGlobalError(message) {
    const box = $('global-error');
    box.textContent = message;
    box.classList.remove('hidden');
  }

  function hideGlobalError() {
    $('global-error').classList.add('hidden');
    $('global-error').textContent = '';
  }

  function has(...permissions) {
    return permissions.some((permission) => state.permissions.has(permission));
  }

  function makeCell(value) {
    const td = document.createElement('td');
    td.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
    return td;
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString('fr-FR');
  }

  function formatAmount(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n.toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' FCFA' : '—';
  }

  function showView(view) {
    const allowed = {
      dashboard: true,
      villages: true,
      taxpayers: has('taxpayers.read'),
      imports: has('imports.create') || (state.profile?.role === 'secretaire_general' && has('imports.review')),
      finance: has('finance.read', 'payments.read', 'payments.collect'),
      'finance-admin': has('finance.read'),
      suivi: has('assessments.read', 'finance.read', 'payments.read'),
      cartographie: has('taxpayers.read'),
      administration: has('users.manage') && has('agents.manage'),
      audit: has('audit.read')
    };
    if (!allowed[view]) return;
    state.activeView = view;
    document.querySelectorAll('[id^="view-"]').forEach((section) => section.classList.add('hidden'));
    const target = $('view-' + view);
    if (target) target.classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
    if (view === 'villages') loadVillages();
    if (view === 'taxpayers') loadTaxpayers();
    if (view === 'imports') loadImportBatches();
    if (view === 'finance') loadFinance();
    if (view === 'finance-admin') loadLd14Finance();
    if (view === 'suivi') loadFiscalTracking();
    if (view === 'cartographie') loadFiscalMap();
    if (view === 'audit') loadAudit();
    if (view === 'administration') loadAdministration();
  }

  function addMetric(container, label, value, note) {
    const article = document.createElement('article');
    article.className = 'panel';
    const title = document.createElement('div');
    title.className = 'metric-label';
    title.textContent = label;
    const number = document.createElement('div');
    number.className = 'stat';
    number.textContent = value === null ? 'Non disponible' : String(value);
    const description = document.createElement('div');
    description.className = 'metric-note';
    description.textContent = note || '';
    article.append(title, number, description);
    container.append(article);
  }

  async function countRows(table, permission = true) {
    if (!permission) return null;
    const { count, error } = await state.db.from(table).select('id', { count: 'exact', head: true });
    if (error) {
      console.warn('Lecture du compteur impossible pour', table, error.message);
      return null;
    }
    return count ?? 0;
  }

  async function loadDashboard() {
    const metrics = $('metrics');
    metrics.replaceChildren();
    const tasks = [
      ['Villages enregistrés', 'villages', true, 'Territoire communal'],
      ['Contribuables recensés', 'taxpayers', has('taxpayers.read'), 'Registre consultable selon permission'],
      ['Évaluations fiscales', 'assessments', has('taxpayers.read'), 'Données fiscales autorisées'],
      ['Paiements enregistrés', 'payments', has('finance.read', 'payments.read', 'payments.collect'), 'Opérations visibles selon permission'],
      ['Agents et profils', 'profiles', has('agents.read', 'users.manage'), 'Comptes visibles selon permission'],
      ['Événements du journal d’audit', 'audit_logs', has('audit.read'), 'Traçabilité des opérations autorisées']
    ];
    for (const [label, table, allowed, note] of tasks) {
      const count = await countRows(table, allowed);
      addMetric(metrics, label, count === null ? '—' : count.toLocaleString('fr-FR'), allowed ? note : 'Permission non attribuée');
    }
    $('status').textContent = 'Session authentifiée. Les indicateurs proviennent des tables Supabase accessibles à votre profil ; les données non autorisées ne sont pas interrogées.';
    $('session-state').textContent = 'Session authentifiée';
    const controllerWorkspace = $('controller-workspace');
    const collectorWorkspace = $('collector-workspace');
    if (controllerWorkspace) controllerWorkspace.classList.toggle('hidden', state.profile?.role !== 'controleur');
    if (collectorWorkspace) collectorWorkspace.classList.toggle('hidden', state.profile?.role !== 'agent_collecte');
    if (state.profile?.role === 'controleur') {
      $('role').textContent = 'Profil : Contrôleur — consultation et contrôle en lecture seule';
    }
    if (state.profile?.role === 'agent_collecte') {
      $('role').textContent = 'Profil : Agent de collecte — opérations limitées aux villages affectés';
      const financeNav = $('nav-finance');
      if (financeNav) financeNav.textContent = 'Mes encaissements';
      const financeTitle = document.querySelector('#view-finance .page-heading h1');
      if (financeTitle) financeTitle.textContent = 'Mes encaissements et reçus';
      const financeIntro = document.querySelector('#view-finance .page-heading .muted');
      if (financeIntro) financeIntro.textContent = 'Enregistrement des paiements autorisés et consultation des opérations accessibles selon vos affectations.';
      const paymentDescription = $('payment-entry-description');
      if (paymentDescription) paymentDescription.textContent = 'Sélectionnez une évaluation non soldée d’un contribuable relevant de vos villages affectés. Supabase vérifie à nouveau votre affectation, le solde et votre permission avant de confirmer.';
    }
  }

  function setVillageMessage(message, type = '') {
    const node = $('village-form-message');
    if (!node) return;
    node.textContent = message;
    node.className = `form-message ${type}`.trim();
  }

  function resetVillageForm() {
    $('village-form').reset();
    $('village-id').value = '';
    $('village-form-title').textContent = 'Enregistrer un village';
    $('village-save').textContent = 'Enregistrer le village';
    $('village-cancel').classList.add('hidden');
    setVillageMessage('');
  }

  function renderVillages(rows) {
    const root = $('villages-content');
    root.replaceChildren();
    $('villages-count').textContent = `${rows.length} village(s)`;
    if (!rows.length) {
      const empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = 'Aucun village enregistré pour le moment. Utilisez le formulaire pour ajouter les villages officiels de la Commune de Léona.';
      root.append(empty);
      return;
    }
    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const thead = document.createElement('thead'); const head = document.createElement('tr');
    ['Code officiel', 'Nom du village', 'Vérification', 'Créé le', ...(has('settings.manage') ? ['Actions'] : [])].forEach((label) => {
      const th = document.createElement('th'); th.textContent = label; head.append(th);
    });
    thead.append(head); table.append(thead);
    const tbody = document.createElement('tbody');
    rows.forEach((row) => {
      const tr = document.createElement('tr');
      tr.append(makeCell(row.official_code), makeCell(row.name), makeCell(row.verified ? 'Vérifié' : 'À vérifier'), makeCell(formatDate(row.created_at)));
      if (has('settings.manage')) {
        const td = document.createElement('td');
        const edit = document.createElement('button');
        edit.type = 'button'; edit.className = 'btn ghost btn-small'; edit.textContent = 'Modifier';
        edit.addEventListener('click', () => {
          $('village-id').value = row.id;
          $('village-name').value = row.name || '';
          $('village-code').value = row.official_code || '';
          $('village-form-title').textContent = 'Modifier la fiche du village';
          $('village-save').textContent = 'Enregistrer les modifications';
          $('village-cancel').classList.remove('hidden');
          setVillageMessage(`Modification de : ${row.name}`);
          $('village-manager').scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        const verify = document.createElement('button');
        verify.type = 'button'; verify.className = 'btn btn-small';
        verify.textContent = row.verified ? 'Retirer vérification' : 'Marquer vérifié';
        verify.addEventListener('click', async () => {
          verify.disabled = true;
          const { error } = await state.db.from('villages').update({ verified: !row.verified }).eq('id', row.id);
          verify.disabled = false;
          if (error) {
            showGlobalError(`Modification du statut impossible : ${error.message}`);
            return;
          }
          await loadVillages();
        });
        td.append(edit, document.createTextNode(' '), verify);
        tr.append(td);
      }
      tbody.append(tr);
    });
    table.append(tbody); wrap.append(table); root.append(wrap);
  }

  async function loadVillages() {
    const root = $('villages-content');
    root.textContent = 'Chargement du registre territorial…';
    const { data, error } = await state.db.from('villages')
      .select('id,commune_id,official_code,name,verified,created_at')
      .eq('commune_id', LEONA_COMMUNE_ID)
      .order('name', { ascending: true })
      .limit(500);
    if (error) {
      root.textContent = 'Impossible de lire les villages. Vérifiez la session, la permission de lecture et les politiques RLS.';
      $('villages-count').textContent = 'Erreur de lecture';
      console.error(error);
      return;
    }
    state.villages = data || [];
    const term = ($('village-search')?.value || '').trim().toLocaleLowerCase('fr');
    const filtered = term ? state.villages.filter((v) => `${v.name || ''} ${v.official_code || ''}`.toLocaleLowerCase('fr').includes(term)) : state.villages;
    renderVillages(filtered);
  }

  async function saveVillage(event) {
    event.preventDefault();
    if (!has('settings.manage')) {
      setVillageMessage('Votre compte ne possède pas la permission settings.manage.', 'error');
      return;
    }
    const id = $('village-id').value;
    const name = $('village-name').value.trim();
    const code = $('village-code').value.trim();
    if (!name) {
      setVillageMessage('Le nom du village est obligatoire.', 'error');
      return;
    }
    const payload = { name, official_code: code || null };
    $('village-save').disabled = true;
    setVillageMessage(id ? 'Enregistrement des modifications…' : 'Enregistrement du village…');
    let result;
    if (id) {
      result = await state.db.from('villages').update(payload).eq('id', id).eq('commune_id', LEONA_COMMUNE_ID).select('id').single();
    } else {
      result = await state.db.from('villages').insert({ ...payload, commune_id: LEONA_COMMUNE_ID, verified: false }).select('id').single();
    }
    $('village-save').disabled = false;
    if (result.error) {
      const duplicate = result.error.code === '23505';
      setVillageMessage(duplicate ? 'Ce code officiel est déjà utilisé pour un autre village.' : `Enregistrement impossible : ${result.error.message}`, 'error');
      console.error(result.error);
      return;
    }
    resetVillageForm();
    setVillageMessage(id ? 'Village mis à jour avec succès.' : 'Village enregistré avec succès.', 'success');
    await loadVillages();
  }

  function setTaxpayerMessage(message, type = '') {
    const node = $('tp-message');
    if (!node) return;
    node.textContent = message;
    node.className = `form-message ${type}`.trim();
  }

  async function loadTaxpayerVillageOptions() {
    const select = $('tp-village');
    const filter = $('taxpayer-village-filter');
    const previous = filter?.value || '';
    const { data, error } = await state.db.from('villages')
      .select('id,name,official_code,verified')
      .eq('commune_id', LEONA_COMMUNE_ID)
      .order('name', { ascending: true })
      .limit(500);
    if (error) {
      console.warn('Liste des villages indisponible', error.message);
      return;
    }
    state.villages = data || [];
    if (select) {
      const entryPrevious = select.value;
      select.replaceChildren(new Option('Choisir un village (facultatif)', ''));
      state.villages.forEach((v) => select.add(new Option(`${v.name}${v.verified ? '' : ' — à vérifier'}`, v.id)));
      if (entryPrevious && [...select.options].some((o) => o.value === entryPrevious)) select.value = entryPrevious;
    }
    if (filter) {
      filter.replaceChildren(new Option('Choisir un village — obligatoire', ''));
      state.villages.forEach((v) => filter.add(new Option(v.name, v.id)));
      if (previous && [...filter.options].some((o) => o.value === previous)) filter.value = previous;
    }
  }

  async function saveTaxpayer(event) {
    event.preventDefault();
    if (!has('recensement.manage')) {
      setTaxpayerMessage('Votre compte ne possède pas la permission recensement.manage nécessaire pour enregistrer un contribuable.', 'error');
      return;
    }
    const code = $('tp-code').value.trim();
    const first = $('tp-first').value.trim();
    const last = $('tp-last').value.trim();
    const latText = $('tp-lat').value.trim();
    const lonText = $('tp-lon').value.trim();
    if (!code || !first || !last) {
      setTaxpayerMessage('Le code, le prénom et le nom sont obligatoires.', 'error');
      return;
    }
    if ((latText && !lonText) || (!latText && lonText)) {
      setTaxpayerMessage('Renseignez ensemble la latitude et la longitude, ou laissez les deux champs vides.', 'error');
      return;
    }
    const lat = latText === '' ? null : Number(latText);
    const lon = lonText === '' ? null : Number(lonText);
    if ((lat !== null && (!Number.isFinite(lat) || lat < -90 || lat > 90)) ||
        (lon !== null && (!Number.isFinite(lon) || lon < -180 || lon > 180))) {
      setTaxpayerMessage('Les coordonnées GPS sont hors des limites autorisées.', 'error');
      return;
    }
    const payload = {
      commune_id: LEONA_COMMUNE_ID,
      taxpayer_code: code,
      first_name: first,
      last_name: last,
      phone: $('tp-phone').value.trim() || null,
      village_id: $('tp-village').value || null,
      activity: $('tp-activity').value.trim() || null,
      tax_category: $('tp-category').value.trim() || null,
      location_label: $('tp-location').value.trim() || null,
      gps_lat: lat,
      gps_lon: lon,
      status: 'pending',
      created_by: state.userId,
      extra: {}
    };
    $('tp-save').disabled = true;
    setTaxpayerMessage('Enregistrement sécurisé de la fiche…');
    const { error } = await state.db.from('taxpayers').insert(payload);
    $('tp-save').disabled = false;
    if (error) {
      if (error.code === '23505') setTaxpayerMessage('Ce code contribuable existe déjà. Vérifiez le registre avant de réessayer.', 'error');
      else if (error.code === '42501' || error.code === 'PGRST301') setTaxpayerMessage('Écriture refusée par les règles de sécurité Supabase. Vérifiez le rôle et ses permissions.', 'error');
      else setTaxpayerMessage(`Enregistrement impossible : ${error.message}`, 'error');
      console.error('Insertion contribuable refusée ou échouée', error);
      return;
    }
    $('taxpayer-form').reset();
    setTaxpayerMessage('Fiche enregistrée avec succès avec le statut « En attente ».', 'success');
    await loadTaxpayers();
    await loadDashboard();
  }

  async function loadTaxpayers() {
    if (!has('taxpayers.read')) return;
    await loadTaxpayerVillageOptions();
    const root = $('taxpayers-content');
    const villageId = $('taxpayer-village-filter')?.value || '';
    if (!villageId) {
      $('taxpayers-count').textContent = 'Village requis';
      root.textContent = 'Sélectionnez un village pour ouvrir son registre de contribuables.';
      return;
    }
    root.textContent = 'Chargement du registre du village…';
    const search = $('taxpayer-search').value.trim().replace(/[%(),]/g, ' ').replace(/\s+/g, ' ');
    const sort = $('taxpayer-sort')?.value || 'name_asc';
    let query = state.db.from('taxpayers')
      .select('taxpayer_code,first_name,last_name,phone,activity,status,village_id,created_at')
      .eq('village_id', villageId)
      .order(sort.startsWith('name') ? 'last_name' : sort.startsWith('code') ? 'taxpayer_code' : 'created_at', { ascending: sort.endsWith('asc') })
      .limit(1000);
    if (search) query = query.or(`taxpayer_code.ilike.%${search}%,first_name.ilike.%${search}%,last_name.ilike.%${search}%,phone.ilike.%${search}%`);
    const { data, error } = await query;
    root.replaceChildren();
    if (error) {
      $('taxpayers-count').textContent = 'Erreur de lecture';
      root.textContent = 'Lecture du registre impossible. Vérifiez la permission taxpayers.read et les politiques RLS.';
      console.error(error);
      return;
    }
    currentTaxpayerRows = data || [];
    const village = state.villages.find((v) => v.id === villageId);
    $('taxpayers-count').textContent = `${data.length} contribuable(s) — ${village?.name || 'Village sélectionné'}`;
    if (!data.length) {
      root.textContent = search ? 'Aucun résultat dans ce village pour cette recherche.' : 'Aucun contribuable enregistré dans ce village.';
      return;
    }
    const heading = document.createElement('h3');
    heading.className = 'taxpayer-village-heading';
    heading.textContent = `Village : ${village?.name || 'Sélectionné'} — ${data.length} fiche(s)`;
    root.append(heading);
    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table'); table.className = 'taxpayer-register-table';
    const thead = document.createElement('thead'); const hr = document.createElement('tr');
    ['Code', 'Prénom et nom', 'Téléphone', 'Activité', 'Statut', 'Date de recensement'].forEach((label, index) => {
      const th = document.createElement('th'); th.textContent = label; th.className = `tax-col-${index + 1}`; hr.append(th);
    });
    thead.append(hr); table.append(thead);
    const tbody = document.createElement('tbody');
    data.forEach((row) => {
      const tr = document.createElement('tr');
      [row.taxpayer_code, `${row.first_name || ''} ${row.last_name || ''}`.trim(), row.phone, row.activity, row.status, formatDate(row.created_at)].forEach((value, index) => {
        const cell = makeCell(value); cell.classList.add(`tax-col-${index + 1}`); tr.append(cell);
      });
      tbody.append(tr);
    });
    table.append(tbody); wrap.append(table); root.append(wrap);
    if (data.length === 1000) {
      const note = document.createElement('p'); note.className = 'metric-note';
      note.textContent = 'Affichage limité à 1 000 résultats. Affinez la recherche si nécessaire.';
      root.append(note);
    }
  }
  async function loadFiscalTracking() {
    const root = $('suivi-content');
    root.textContent = 'Chargement du suivi fiscal…';
    const [villageResult, balanceResult] = await Promise.all([
      state.db.from('villages').select('id,name,official_code').eq('commune_id', LEONA_COMMUNE_ID).order('name').limit(500),
      state.db.from('v_assessment_balances')
        .select('assessment_id,taxpayer_code,first_name,last_name,village_id,period_start,period_end,amount_due,amount_paid,balance')
        .order('period_start', { ascending: false }).limit(1000)
    ]);
    if (villageResult.error) console.warn('VILLAGES_FOR_FISCAL_TRACKING', villageResult.error.message);
    const allVillages = villageResult.data || [];
    const accessibleIds = new Set((balanceResult.data || []).map(row => row.village_id).filter(Boolean));
    const villages = allVillages.filter(v => accessibleIds.has(v.id));
    const select = $('suivi-village');
    const previous = select.value;
    select.replaceChildren(new Option('Tous les villages accessibles', ''));
    villages.forEach(v => select.add(new Option(v.name, v.id)));
    if (previous && villages.some(v => v.id === previous)) select.value = previous;
    if (balanceResult.error) {
      state.fiscalRows = [];
      updateFiscalSummary([]);
      root.textContent = 'Impossible de charger le suivi fiscal. Vérifiez les droits de lecture sur les évaluations, les contribuables et le grand livre.';
      $('suivi-note').textContent = balanceResult.error.message;
      console.error('FISCAL_TRACKING_LOAD', balanceResult.error);
      return;
    }
    state.fiscalRows = (balanceResult.data || []).map(row => ({ ...row, village_name: villages.find(v => v.id === row.village_id)?.name || 'Village non renseigné' }));
    renderFiscalTracking();
    $('suivi-note').textContent = state.fiscalRows.length === 1000
      ? 'Affichage limité aux 1 000 évaluations les plus récentes accessibles. Affinez les filtres ou consultez les périodes séparément.'
      : `${state.fiscalRows.length} évaluation(s) accessibles à votre profil.`;
  }

  function filteredFiscalRows() {
    const village = $('suivi-village').value;
    const status = $('suivi-status').value;
    const from = $('suivi-from').value;
    const to = $('suivi-to').value;
    const term = $('suivi-search').value.trim().toLocaleLowerCase('fr');
    const sort = $('suivi-sort').value;
    const rows = state.fiscalRows.filter(row => {
      if (village && row.village_id !== village) return false;
      if (status === 'balance' && Number(row.balance) <= 0) return false;
      if (status === 'paid' && Number(row.balance) > 0) return false;
      if (from && row.period_end < from) return false;
      if (to && row.period_start > to) return false;
      const haystack = `${row.taxpayer_code || ''} ${row.first_name || ''} ${row.last_name || ''} ${row.village_name || ''}`.toLocaleLowerCase('fr');
      if (term && !haystack.includes(term)) return false;
      return true;
    });
    rows.sort((a, b) => {
      if (sort === 'balance_desc') return Number(b.balance) - Number(a.balance);
      if (sort === 'name') return `${a.last_name} ${a.first_name}`.localeCompare(`${b.last_name} ${b.first_name}`, 'fr');
      if (sort === 'period_desc') return String(b.period_start).localeCompare(String(a.period_start));
      return `${a.village_name} ${a.last_name} ${a.first_name}`.localeCompare(`${b.village_name} ${b.last_name} ${b.first_name}`, 'fr');
    });
    return rows;
  }

  function updateFiscalSummary(rows) {
    const due = rows.reduce((sum, row) => sum + Number(row.amount_due || 0), 0);
    const paid = rows.reduce((sum, row) => sum + Number(row.amount_paid || 0), 0);
    const balance = rows.reduce((sum, row) => sum + Number(row.balance || 0), 0);
    $('suivi-due').textContent = formatAmount(due);
    $('suivi-paid').textContent = formatAmount(paid);
    $('suivi-balance').textContent = formatAmount(balance);
    $('suivi-count').textContent = String(rows.length);
  }

  function renderFiscalTracking() {
    const rows = filteredFiscalRows();
    updateFiscalSummary(rows);
    const root = $('suivi-content');
    root.replaceChildren();
    if (!rows.length) {
      root.textContent = state.fiscalRows.length ? 'Aucune évaluation ne correspond aux filtres.' : 'Aucune évaluation accessible pour ce compte.';
      return;
    }
    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const thead = document.createElement('thead'); const hr = document.createElement('tr');
    ['Village','Code contribuable','Contribuable','Période','Évalué','Payé net','Solde restant','Situation'].forEach(label => { const th = document.createElement('th'); th.textContent = label; hr.append(th); });
    thead.append(hr); table.append(thead);
    const tbody = document.createElement('tbody');
    rows.forEach(row => {
      const tr = document.createElement('tr');
      const balance = Number(row.balance || 0);
      tr.append(makeCell(row.village_name), makeCell(row.taxpayer_code), makeCell(`${row.first_name || ''} ${row.last_name || ''}`.trim()), makeCell(`${formatDate(row.period_start)} – ${formatDate(row.period_end)}`), makeCell(formatAmount(row.amount_due)), makeCell(formatAmount(row.amount_paid)), makeCell(formatAmount(balance)), makeCell(balance > 0 ? 'Solde restant' : 'Soldée'));
      tr.classList.add(balance > 0 ? 'fiscal-balance-row' : 'fiscal-paid-row');
      tbody.append(tr);
    });
    table.append(tbody); wrap.append(table); root.append(wrap);
    const note = document.createElement('p'); note.className = 'metric-note';
    note.textContent = `${rows.length} évaluation(s) après filtrage. Les montants payés sont nets des contrepassations enregistrées.`;
    root.append(note);
  }

  function exportFiscalTracking() {
    const rows = filteredFiscalRows();
    if (!rows.length) { $('suivi-note').textContent = 'Aucune ligne à exporter pour les filtres actuels.'; return; }
    const headers = ['Village','Code contribuable','Prénom','Nom','Début période','Fin période','Montant évalué FCFA','Montant payé net FCFA','Solde restant FCFA','Situation'];
    const cell = value => {
      let text = String(value ?? '');
      if (/^[=+@\-]/.test(text)) text = `'${text}`;
      return `"${text.replaceAll('"','""')}"`;
    };
    const lines = [headers, ...rows.map(r => [r.village_name,r.taxpayer_code,r.first_name,r.last_name,r.period_start,r.period_end,r.amount_due,r.amount_paid,r.balance,Number(r.balance) > 0 ? 'Solde restant' : 'Soldée'])];
    const csv = '\ufeff' + lines.map(line => line.map(cell).join(';')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = `LEONA_SUIVI_FISCAL_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  }

  async function loadFinance() {
    const root = $('finance-content');
    root.textContent = 'Chargement du grand livre…';
    const canCollect = has('payments.collect');
    const canReverse = has('payments.reverse') && state.profile?.role === 'receveur_municipal';
    $('payment-entry-panel').classList.toggle('hidden', !canCollect);

    if (canCollect) await loadOpenAssessments();

    const { data, error } = await state.db.from('v_financial_ledger')
      .select('payment_id,entry_type,amount,method,confirmed_at,receipt_number,receipt_status,taxpayer_code,first_name,last_name,period_start,period_end,reason,reversal_of')
      .order('confirmed_at', { ascending: false })
      .limit(200);
    root.replaceChildren();
    if (error) {
      state.financeRows = [];
      updateFinanceSummary([]);
      root.textContent = 'Consultation du grand livre impossible avec les autorisations actuelles. Vérifiez les politiques RLS et les vues de la Phase 6.';
      console.error(error);
      return;
    }

    const rows = data || [];
    const paymentIds = rows.filter(row => row.receipt_number).map(row => row.payment_id);
    if (paymentIds.length) {
      const { data: receiptRows, error: receiptError } = await state.db.from('receipts')
        .select('payment_id,verification_token')
        .in('payment_id', paymentIds);
      if (receiptError) {
        console.warn('RECEIPT_VERIFICATION_TOKENS_UNAVAILABLE', receiptError.message);
      } else {
        const tokens = new Map((receiptRows || []).map(receipt => [receipt.payment_id, receipt.verification_token]));
        rows.forEach(row => { row.verification_token = tokens.get(row.payment_id) || null; });
      }
    }

    state.financeRows = rows;
    updateFinanceSummary(rows);
    renderFinanceRows(applyFinanceFilters(rows), canReverse);
  }

  function updateFinanceSummary(rows) {
    const collections = rows.filter(row => row.entry_type === 'collection')
      .reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const reversals = rows.filter(row => row.entry_type === 'reversal')
      .reduce((sum, row) => sum + Number(row.amount || 0), 0);
    $('finance-gross').textContent = formatAmount(collections);
    $('finance-reversed').textContent = formatAmount(reversals);
    $('finance-net').textContent = formatAmount(collections - reversals);
    $('finance-count').textContent = String(rows.length);
  }

  function applyFinanceFilters(rows) {
    const term = ($('finance-search')?.value || '').trim().toLocaleLowerCase('fr');
    const operation = $('finance-operation')?.value || 'all';
    const status = $('finance-status')?.value || 'all';
    const method = $('finance-method')?.value || 'all';
    const from = $('finance-date-from')?.value || '';
    const to = $('finance-date-to')?.value || '';
    return rows.filter(row => {
      const searchable = `${row.taxpayer_code || ''} ${row.first_name || ''} ${row.last_name || ''} ${row.receipt_number || ''}`.toLocaleLowerCase('fr');
      const day = row.confirmed_at ? new Date(row.confirmed_at).toISOString().slice(0, 10) : '';
      if (term && !searchable.includes(term)) return false;
      if (operation !== 'all' && row.entry_type !== operation) return false;
      if (status !== 'all' && row.receipt_status !== status) return false;
      if (method !== 'all' && row.method !== method) return false;
      if (from && (!day || day < from)) return false;
      if (to && (!day || day > to)) return false;
      return true;
    });
  }

  function renderFinanceRows(rows, canReverse = has('payments.reverse') && state.profile?.role === 'receveur_municipal') {
    const root = $('finance-content');
    root.replaceChildren();
    if (!rows || !rows.length) {
      root.textContent = state.financeRows.length
        ? 'Aucune opération ne correspond aux filtres sélectionnés.'
        : 'Aucune opération financière enregistrée ou visible pour ce compte.';
      return;
    }

    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const thead = document.createElement('thead'); const hr = document.createElement('tr');
    ['Date','Contribuable','Type','Montant','Mode','N° reçu','État','Action'].forEach((label) => {
      const th = document.createElement('th'); th.textContent = label; hr.append(th);
    });
    thead.append(hr); table.append(thead);
    const tbody = document.createElement('tbody');
    rows.forEach((row) => {
      const tr = document.createElement('tr');
      const taxpayer = `${row.taxpayer_code || ''} — ${row.first_name || ''} ${row.last_name || ''}`.trim();
      tr.append(
        makeCell(formatDate(row.confirmed_at)), makeCell(taxpayer),
        makeCell(row.entry_type === 'reversal' ? 'Contrepassation' : 'Encaissement'),
        makeCell(formatAmount(row.amount)), makeCell(paymentMethodLabel(row.method)),
        makeCell(row.receipt_number || '—'), makeCell(row.receipt_status || '—')
      );
      const action = document.createElement('td');
      if (row.entry_type === 'collection' && row.receipt_number) {
        const printButton = document.createElement('button');
        printButton.type = 'button'; printButton.className = 'btn ghost btn-small'; printButton.textContent = 'Imprimer reçu';
        printButton.addEventListener('click', () => printMunicipalReceipt(row));
        action.append(printButton);
        if (row.verification_token) {
          const verifyButton = document.createElement('button');
          verifyButton.type = 'button'; verifyButton.className = 'btn ghost btn-small'; verifyButton.textContent = 'Vérifier';
          verifyButton.addEventListener('click', () => {
            const url = `/verification-recu?token=${encodeURIComponent(row.verification_token)}`;
            window.open(url, '_blank', 'noopener,noreferrer');
          });
          action.append(verifyButton);
        }
      }
      if (canReverse && row.entry_type === 'collection' && row.receipt_status === 'VALIDE') {
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'btn danger btn-small'; button.textContent = 'Contrepasser';
        button.addEventListener('click', () => reversePayment(row.payment_id));
        action.append(button);
      }
      if (!action.childElementCount) action.textContent = '—';
      tr.append(action); tbody.append(tr);
    });
    table.append(tbody); wrap.append(table); root.append(wrap);
    const note = document.createElement('p'); note.className = 'metric-note';
    note.textContent = `${rows.length} opération(s) affichée(s) après filtrage. Les indicateurs de synthèse portent sur les ${state.financeRows.length} opérations les plus récentes accessibles. Les montants sont en FCFA.`;
    root.append(note);
  }

  function paymentMethodLabel(method) {
    return ({cash:'Espèces',cheque:'Chèque',bank_transfer:'Virement bancaire',wave:'Wave',orange_money:'Orange Money'})[method] || method || '—';
  }

  function escapeReceiptText(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  function printMunicipalReceipt(row) {
    const receiptWindow = window.open('', '_blank');
    if (!receiptWindow) {
      window.alert('Autorisez les fenêtres contextuelles pour imprimer le reçu.'); return;
    }
    const status = row.receipt_status === 'ANNULÉE' ? 'ANNULÉ — NE PAS UTILISER COMME JUSTIFICATIF DE PAIEMENT' : 'REÇU D’ENCAISSEMENT';
    const verificationUrl = row.verification_token ? `${window.location.origin}/verification-recu?token=${encodeURIComponent(row.verification_token)}` : '';
    const verificationLine = verificationUrl ? `<div class="line"><span>Vérification</span><strong><a href="${escapeReceiptText(verificationUrl)}">Vérifier l’authenticité du reçu</a></strong></div>` : '';
    const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reçu ${escapeReceiptText(row.receipt_number)}</title><style>body{font:15px Arial,sans-serif;color:#17251c;margin:32px}.receipt{max-width:760px;margin:auto;border:2px solid #174c32;padding:28px}.head{text-align:center;border-bottom:1px solid #9aa99f;padding-bottom:16px}.head h1{font-size:22px;margin:0 0 6px}.number{font-size:20px;font-weight:bold;margin:20px 0}.line{display:flex;justify-content:space-between;gap:16px;border-bottom:1px solid #ddd;padding:10px 0}.amount{font-size:24px;font-weight:bold}.status{margin-top:20px;padding:12px;background:#edf4ef;font-weight:bold;text-align:center}.foot{margin-top:28px;font-size:12px;color:#56645b}.actions{text-align:center;margin:20px}@media print{.actions{display:none}body{margin:0}.receipt{border:2px solid #174c32}}</style></head><body><div class="receipt"><div class="head"><h1>COMMUNE DE LÉONA</h1><div>République du Sénégal</div><div>Document généré par LÉONA DIGITAL 2.0</div></div><div class="number">N° ${escapeReceiptText(row.receipt_number)}</div><div class="status">${status}</div><div class="line"><span>Contribuable</span><strong>${escapeReceiptText(`${row.first_name || ''} ${row.last_name || ''}`.trim())}</strong></div><div class="line"><span>Code contribuable</span><strong>${escapeReceiptText(row.taxpayer_code)}</strong></div><div class="line"><span>Montant</span><strong class="amount">${escapeReceiptText(formatAmount(row.amount))}</strong></div><div class="line"><span>Mode de paiement</span><strong>${escapeReceiptText(paymentMethodLabel(row.method))}</strong></div><div class="line"><span>Date d’encaissement</span><strong>${escapeReceiptText(new Date(row.confirmed_at).toLocaleString('fr-FR'))}</strong></div><div class="line"><span>Période fiscale</span><strong>${escapeReceiptText(formatDate(row.period_start))} au ${escapeReceiptText(formatDate(row.period_end))}</strong></div>${verificationLine}<div class="foot">Ce reçu est délivré par le système municipal après confirmation de l’écriture dans le grand livre. Vérifier son état dans LÉONA DIGITAL 2.0 avant toute utilisation. Ce document ne remplace pas les mentions ou signatures officielles éventuellement exigées par les textes applicables.</div></div><div class="actions"><button onclick="window.print()">Imprimer / Enregistrer en PDF</button></div></body></html>`;
    receiptWindow.document.open(); receiptWindow.document.write(html); receiptWindow.document.close();
  }

  async function loadOpenAssessments() {
    const select = $('payment-assessment');
    select.replaceChildren();
    const placeholder = document.createElement('option');
    placeholder.value = ''; placeholder.textContent = 'Sélectionner une évaluation avec un solde';
    select.append(placeholder);
    const { data, error } = await state.db.from('v_assessment_balances')
      .select('assessment_id,taxpayer_code,first_name,last_name,period_start,period_end,amount_due,amount_paid,balance')
      .gt('balance', 0).order('period_start', { ascending: true }).limit(500);
    if (error) {
      placeholder.textContent = 'Impossible de charger les évaluations autorisées';
      console.error(error); return;
    }
    (data || []).forEach((row) => {
      const option = document.createElement('option');
      option.value = row.assessment_id;
      option.dataset.balance = String(row.balance);
      option.textContent = `${row.taxpayer_code} — ${row.first_name} ${row.last_name} | Solde : ${formatAmount(row.balance)} | ${formatDate(row.period_start)} au ${formatDate(row.period_end)}`;
      select.append(option);
    });
    if (!data || !data.length) {
      placeholder.textContent = 'Aucune évaluation avec solde disponible';
    }
  }

  async function submitPhysicalPayment(event) {
    event.preventDefault();
    const message = $('payment-entry-message');
    const assessment = $('payment-assessment').value;
    const amount = Number($('payment-amount').value);
    const method = $('payment-method').value;
    const selected = $('payment-assessment').selectedOptions[0];
    const balance = Number(selected?.dataset.balance || 0);
    if (!assessment || !Number.isFinite(amount) || amount <= 0 || amount > balance) {
      message.textContent = 'Sélectionnez une évaluation et saisissez un montant positif ne dépassant pas le solde affiché.';
      message.className = 'form-message error'; return;
    }
    $('payment-submit').disabled = true;
    message.textContent = 'Vérification et enregistrement sécurisé en cours…';
    message.className = 'form-message';
    try {
      const { data, error } = await state.db.rpc('record_physical_payment', {
        p_assessment: assessment, p_amount: amount, p_method: method
      });
      if (error) throw error;
      const result = Array.isArray(data) ? data[0] : data;
      if (!result?.receipt_number) throw new Error('receipt_not_returned');
      message.textContent = `Encaissement confirmé. Reçu officiel : ${result.receipt_number}. Conservez ce numéro.`;
      message.className = 'form-message success';
      $('payment-entry-form').reset();
      await loadFinance();
    } catch (error) {
      console.error('PHYSICAL_PAYMENT_FAILED', error);
      const messages = {
        amount_exceeds_balance: 'Le montant dépasse le solde restant. Actualisez les évaluations.',
        permission_denied: 'Votre profil ne dispose pas du droit d’encaissement.',
        village_not_assigned: 'Cette évaluation ne relève pas de votre affectation de collecte.',
        assessment_not_found: 'Évaluation introuvable ou non accessible.',
        invalid_physical_method: 'Mode de paiement non autorisé pour cet encaissement.'
      };
      message.textContent = messages[error.message] || 'Échec de l’encaissement. Vérifiez les autorisations et la migration Phase 6, puis réessayez après vérification du grand livre.';
      message.className = 'form-message error';
    } finally {
      $('payment-submit').disabled = false;
    }
  }

  async function reversePayment(paymentId) {
    const reason = window.prompt('Motif détaillé de la contrepassation (10 caractères minimum) :');
    if (reason === null) return;
    if (reason.trim().length < 10) {
      window.alert('Le motif doit comporter au moins 10 caractères.'); return;
    }
    if (!window.confirm('Confirmer la contrepassation ? Une nouvelle écriture sera créée ; le paiement initial ne sera pas supprimé.')) return;
    const { error } = await state.db.rpc('reverse_payment', { p_payment: paymentId, p_reason: reason.trim() });
    if (error) {
      console.error('PAYMENT_REVERSAL_FAILED', error);
      window.alert(error.message === 'payment_already_reversed' ? 'Ce paiement est déjà contrepassé.' : 'Contrepassation refusée. Vérifiez votre permission et le motif.');
      return;
    }
    window.alert('Contrepassation enregistrée dans le grand livre.');
    await loadFinance();
  }

  async function loadAudit() {
    const root = $('audit-content');
    root.textContent = 'Chargement du journal…';
    const { data, error } = await state.db.from('audit_logs')
      .select('table_name,record_id,operation,occurred_at,reason')
      .order('occurred_at', { ascending: false })
      .limit(100);
    root.replaceChildren();
    if (error) {
      root.textContent = 'Journal inaccessible. Vérifiez la permission audit.read.';
      console.error(error);
      return;
    }
    if (!data.length) {
      root.textContent = 'Aucune entrée de journal disponible.';
      return;
    }
    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const thead = document.createElement('thead'); const hr = document.createElement('tr');
    ['Table', 'Enregistrement', 'Opération', 'Date', 'Motif'].forEach((label) => {
      const th = document.createElement('th'); th.textContent = label; hr.append(th);
    });
    thead.append(hr); table.append(thead);
    const tbody = document.createElement('tbody');
    data.forEach((row) => {
      const tr = document.createElement('tr');
      tr.append(makeCell(row.table_name), makeCell(row.record_id), makeCell(row.operation), makeCell(formatDate(row.occurred_at)), makeCell(row.reason));
      tbody.append(tr);
    });
    table.append(tbody); wrap.append(table); root.append(wrap);
  }

  function setAdminMessage(message, type = '') {
    const node = $('admin-message');
    if (!node) return;
    node.textContent = message;
    node.className = `form-message ${type}`.trim();
  }

  function setAssignmentMessage(message, type = '') {
    const node = $('assignment-message');
    if (!node) return;
    node.textContent = message;
    node.className = `form-message ${type}`.trim();
  }

  async function callAgentAdmin(payload) {
    const { data } = await state.db.auth.getSession();
    const token = data?.session?.access_token;
    if (!token) throw new Error('Session expirée. Reconnectez-vous.');
    const response = await fetch('/api/manage-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify(payload)
    });
    let result = {};
    try { result = await response.json(); } catch { /* réponse invalide */ }
    if (!response.ok) {
      const messages = {
        unauthorized: 'Session non autorisée. Reconnectez-vous.',
        forbidden: 'Cette opération est réservée à l’administrateur technique autorisé.',
        email_already_exists: 'Cette adresse e-mail possède déjà un compte. Utilisez la modification du profil si nécessaire.',
        invalid_request: 'Les informations saisies sont incomplètes ou invalides.',
        service_unavailable: 'Le service sécurisé est indisponible. Vérifiez les variables Cloudflare Pages.'
      };
      throw new Error(messages[result.error] || 'Opération refusée par le serveur sécurisé. Consultez les journaux Netlify.');
    }
    return result;
  }

  function roleLabel(role) {
    return ({ maire: 'Maire', secretaire_general: 'Secrétaire général', receveur_municipal: 'Receveur municipal', controleur: 'Contrôleur', agent_recensement: 'Agent de recensement', agent_collecte: 'Agent de collecte', administrateur_technique: 'Administrateur technique' })[role] || role;
  }

  async function loadAdministration() {
    if (!has('users.manage') || !has('agents.manage')) return;
    $('agents-content').textContent = 'Chargement des comptes…';
    $('assignments-content').textContent = 'Chargement des affectations…';
    const [profilesResult, assignmentsResult, villagesResult] = await Promise.all([
      state.db.from('profiles').select('id,full_name,role,active,created_at').order('full_name').limit(500),
      state.db.from('agent_assignments').select('id,agent_id,village_id,assignment_type,starts_on,ends_on,created_at').order('starts_on', { ascending: false }).limit(1000),
      state.db.from('villages').select('id,name,official_code').order('name').limit(500)
    ]);
    if (profilesResult.error) {
      $('agents-content').textContent = 'Lecture des comptes refusée. Vérifiez la permission agents.read et les règles RLS.';
      console.error(profilesResult.error);
      return;
    }
    if (assignmentsResult.error) {
      $('assignments-content').textContent = 'Lecture des affectations impossible. Vérifiez la politique RLS de agent_assignments.';
      console.error(assignmentsResult.error);
      return;
    }
    if (villagesResult.error) {
      $('assignments-content').textContent = 'Impossible de charger les villages. Vérifiez le registre territorial.';
      console.error(villagesResult.error);
      return;
    }
    state.agents = profilesResult.data || [];
    state.assignments = assignmentsResult.data || [];
    const villages = villagesResult.data || [];
    const agentSelect = $('assignment-agent');
    const villageSelect = $('assignment-village');
    const oldAgent = agentSelect.value;
    const oldVillage = villageSelect.value;
    agentSelect.replaceChildren(new Option('Choisir un agent', ''));
    state.agents.filter(a => ['agent_recensement','agent_collecte'].includes(a.role) && a.active).forEach(a => agentSelect.add(new Option(`${a.full_name} — ${roleLabel(a.role)}`, a.id)));
    villageSelect.replaceChildren(new Option('Choisir un village', ''));
    villages.forEach(v => villageSelect.add(new Option(`${v.name}${v.official_code ? ` (${v.official_code})` : ''}`, v.id)));
    if (state.agents.some(a => a.id === oldAgent && a.active)) agentSelect.value = oldAgent;
    if (villages.some(v => v.id === oldVillage)) villageSelect.value = oldVillage;
    renderAgents();
    renderAssignments(villages);
    $('agent-count').textContent = `${state.agents.length} compte(s)`;
    $('assignment-count').textContent = `${state.assignments.length} affectation(s)`;
  }

  function renderAgents() {
    const root = $('agents-content'); root.replaceChildren();
    if (!state.agents.length) { root.textContent = 'Aucun profil trouvé.'; return; }
    const wrap = document.createElement('div'); wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const head = document.createElement('tr');
    ['Nom complet','Rôle','État','Créé le','Actions'].forEach(x => { const th=document.createElement('th'); th.textContent=x; head.append(th); });
    const thead=document.createElement('thead'); thead.append(head); table.append(thead);
    const body=document.createElement('tbody');
    state.agents.forEach(agent => {
      const tr=document.createElement('tr');
      tr.append(makeCell(agent.full_name),makeCell(roleLabel(agent.role)),makeCell(agent.active?'Actif':'Désactivé'),makeCell(formatDate(agent.created_at)));
      const td=document.createElement('td');
      const edit=document.createElement('button'); edit.type='button'; edit.className='btn ghost btn-small'; edit.textContent='Modifier';
      edit.disabled=agent.role==='administrateur_technique' || agent.id===state.userId;
      edit.title=edit.disabled?'Le compte technique principal et votre propre compte ne sont pas modifiables depuis cette fiche.':'';
      edit.addEventListener('click',()=>{
        $('agent-edit-id').value=agent.id; $('agent-edit-name').value=agent.full_name;
        $('agent-edit-role').value=agent.role; $('agent-edit-active').checked=agent.active;
        $('agent-edit-panel').classList.remove('hidden'); $('agent-edit-panel').scrollIntoView({behavior:'smooth',block:'start'});
      });
      td.append(edit); tr.append(td); body.append(tr);
    });
    table.append(body); wrap.append(table); root.append(wrap);
  }

  function renderAssignments(villages) {
    const root=$('assignments-content'); root.replaceChildren();
    if (!state.assignments.length) { root.textContent='Aucune affectation enregistrée. Créez les affectations après avoir enregistré les villages et les comptes agents.'; return; }
    const names=new Map(state.agents.map(a=>[a.id,a.full_name]));
    const villageNames=new Map(villages.map(v=>[v.id,v.name]));
    const wrap=document.createElement('div'); wrap.className='table-wrap'; const table=document.createElement('table');
    const thead=document.createElement('thead'); const hr=document.createElement('tr');
    ['Agent','Village','Mission','Début','Fin','État','Action'].forEach(x=>{const th=document.createElement('th');th.textContent=x;hr.append(th);}); thead.append(hr);table.append(thead);
    const tbody=document.createElement('tbody');
    state.assignments.forEach(a=>{
      const tr=document.createElement('tr'); const ended=a.ends_on && a.ends_on < new Date().toISOString().slice(0,10);
      tr.append(makeCell(names.get(a.agent_id)||'Compte indisponible'),makeCell(villageNames.get(a.village_id)||'Village indisponible'),makeCell(a.assignment_type==='both'?'Recensement et collecte':a.assignment_type==='recensement'?'Recensement':'Collecte'),makeCell(formatDate(a.starts_on)),makeCell(formatDate(a.ends_on)),makeCell(ended?'Terminée':a.ends_on?'Planifiée / en cours':'Sans date de fin'));
      const td=document.createElement('td'); const btn=document.createElement('button'); btn.type='button';btn.className='btn ghost btn-small';btn.textContent='Clôturer';btn.disabled=!!a.ends_on;
      btn.addEventListener('click',async()=>{
        if(!confirm('Clôturer cette affectation à la date du jour ?')) return;
        btn.disabled=true;
        const {error}=await state.db.from('agent_assignments').update({ends_on:new Date().toISOString().slice(0,10)}).eq('id',a.id).eq('commune_id',LEONA_COMMUNE_ID);
        if(error){btn.disabled=false;setAssignmentMessage('Clôture refusée : '+error.message,'error');return;}
        setAssignmentMessage('Affectation clôturée.','success'); await loadAdministration();
      }); td.append(btn);tr.append(td);tbody.append(tr);
    }); table.append(tbody);wrap.append(table);root.append(wrap);
  }

  async function createAgent(event) {
    event.preventDefault();
    if (!has('users.manage') || !has('agents.manage')) return setAdminMessage('Permission insuffisante.','error');
    const payload={action:'create',full_name:$('agent-name').value.trim(),email:$('agent-email').value.trim().toLowerCase(),role:$('agent-role').value};
    if(!payload.full_name||!payload.email||!payload.role) return setAdminMessage('Tous les champs sont obligatoires.','error');
    $('agent-create').disabled=true; setAdminMessage('Création sécurisée du compte et envoi de l’invitation…');
    try { await callAgentAdmin(payload); $('agent-create-form').reset(); setAdminMessage('Invitation envoyée. Le nouvel utilisateur doit ouvrir le courriel et définir son mot de passe. Le profil a été créé pour la Commune de Léona.','success'); await loadAdministration(); }
    catch(error){setAdminMessage(error.message,'error');}
    finally{$('agent-create').disabled=false;}
  }

  async function updateAgent(event) {
    event.preventDefault();
    const id=$('agent-edit-id').value;
    if(!id) return;
    $('agent-edit-save').disabled=true;
    try {
      await callAgentAdmin({action:'update',user_id:id,full_name:$('agent-edit-name').value.trim(),role:$('agent-edit-role').value,active:$('agent-edit-active').checked});
      $('agent-edit-panel').classList.add('hidden'); setAdminMessage('Profil mis à jour. Une trace a été ajoutée au journal d’audit.','success'); await loadAdministration();
    } catch(error){setAdminMessage(error.message,'error');}
    finally{$('agent-edit-save').disabled=false;}
  }

  async function createAssignment(event) {
    event.preventDefault();
    if(!has('agents.manage')) return setAssignmentMessage('Permission agents.manage requise.','error');
    const payload={commune_id:LEONA_COMMUNE_ID,agent_id:$('assignment-agent').value,village_id:$('assignment-village').value,assignment_type:$('assignment-type').value,starts_on:$('assignment-start').value,ends_on:$('assignment-end').value||null};
    if(!payload.agent_id||!payload.village_id||!payload.starts_on) return setAssignmentMessage('Choisissez un agent, un village et une date de début.','error');
    if(payload.ends_on && payload.ends_on<payload.starts_on) return setAssignmentMessage('La date de fin ne peut pas précéder la date de début.','error');
    $('assignment-save').disabled=true; setAssignmentMessage('Enregistrement de l’affectation…');
    const {error}=await state.db.from('agent_assignments').insert(payload);
    $('assignment-save').disabled=false;
    if(error){setAssignmentMessage(error.code==='23503'?'Agent ou village invalide. Actualisez les listes.':`Affectation refusée : ${error.message}`,'error');return;}
    $('assignment-form').reset(); $('assignment-start').value=new Date().toISOString().slice(0,10);
    setAssignmentMessage('Affectation enregistrée. Les permissions du compte restent déterminées par son rôle.','success'); await loadAdministration();
  }


  let preparedImportRows = [];
  let currentTaxpayerRows = [];
  let selectedImportBatch = null;

  function importMessage(id, message, type = '') {
    const node = $(id);
    if (!node) return;
    node.textContent = message;
    node.className = `form-message ${type}`.trim();
  }

  function downloadWorkbook(workbook, filename) {
    if (!window.XLSX) {
      window.alert('La bibliothèque Excel est indisponible. Rechargez la page et réessayez.');
      return;
    }
    window.XLSX.writeFile(workbook, filename, { bookType: 'xlsx', compression: true });
  }

  function downloadTaxpayerImportTemplate() {
    if (!window.XLSX) return window.alert('La bibliothèque Excel est indisponible. Rechargez la page et réessayez.');
    const headers = [
      'taxpayer_code', 'first_name', 'last_name', 'village',
      'phone', 'activity', 'tax_category', 'location_label', 'gps_lat', 'gps_lon'
    ];
    const ws = window.XLSX.utils.aoa_to_sheet([
      headers,
      ['', '', '', '', '', '', '', '', '', '']
    ]);
    ws['!cols'] = [
      { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 24 }, { wch: 18 },
      { wch: 24 }, { wch: 22 }, { wch: 28 }, { wch: 14 }, { wch: 14 }
    ];
    const help = window.XLSX.utils.aoa_to_sheet([
      ['GUIDE DE REMPLISSAGE — LÉONA DIGITAL 2.0'],
      ['Une ligne correspond à un contribuable. Ne modifiez pas les noms des colonnes de la première feuille.'],
      ['Champs obligatoires : taxpayer_code, first_name, last_name, village.'],
      ['Le village doit correspondre exactement au nom ou au code officiel d’un village enregistré dans la commune.'],
      ['Champs facultatifs : phone, activity, tax_category, location_label, gps_lat, gps_lon.'],
      ['Si une coordonnée est renseignée, renseignez aussi l’autre. Latitude : -90 à 90 ; longitude : -180 à 180.'],
      ['Ne remplissez pas village_id à la main : utilisez le nom exact ou le code officiel du village.'],
      ['Après remplissage, importez ce fichier dans le module Importation Excel / CSV. Le lot sera contrôlé avant intégration.']
    ]);
    help['!cols'] = [{ wch: 115 }];
    const villages = [['village_name', 'official_code']].concat((state.villages || []).map(v => [v.name || '', v.official_code || '']));
    const villagesWs = window.XLSX.utils.aoa_to_sheet(villages);
    villagesWs['!cols'] = [{ wch: 30 }, { wch: 20 }];
    const wb = window.XLSX.utils.book_new();
    window.XLSX.utils.book_append_sheet(wb, ws, 'A remplir');
    window.XLSX.utils.book_append_sheet(wb, help, 'Instructions');
    window.XLSX.utils.book_append_sheet(wb, villagesWs, 'Villages');
    downloadWorkbook(wb, 'MODELE_COLLECTE_CONTRIBUABLES_LEONA.xlsx');
  }

  async function exportVillageReference() {
    await loadTaxpayerVillageOptions();
    const rows = [['village_name', 'official_code']].concat((state.villages || []).map(v => [v.name || '', v.official_code || '']));
    const wb = window.XLSX.utils.book_new();
    const ws = window.XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = [{ wch: 32 }, { wch: 22 }];
    window.XLSX.utils.book_append_sheet(wb, ws, 'Villages');
    downloadWorkbook(wb, 'LISTE_VILLAGES_LEONA.xlsx');
  }

  async function exportCurrentVillageTaxpayers() {
    const villageId = $('taxpayer-village-filter')?.value || '';
    if (!villageId) return window.alert('Sélectionnez d’abord un village pour exporter son registre.');
    if (!window.XLSX) return window.alert('La bibliothèque Excel est indisponible. Rechargez la page et réessayez.');
    const search = $('taxpayer-search')?.value.trim().replace(/[%(),]/g, ' ').replace(/\s+/g, ' ') || '';
    let query = state.db.from('taxpayers')
      .select('taxpayer_code,first_name,last_name,phone,activity,tax_category,location_label,gps_lat,gps_lon,status,village_id,created_at')
      .eq('village_id', villageId)
      .order('last_name', { ascending: true })
      .limit(1000);
    if (search) query = query.or(`taxpayer_code.ilike.%${search}%,first_name.ilike.%${search}%,last_name.ilike.%${search}%,phone.ilike.%${search}%`);
    const { data, error } = await query;
    if (error) return window.alert(`Export impossible : ${error.message}`);
    const village = (state.villages || []).find(v => v.id === villageId);
    const rows = [['taxpayer_code','first_name','last_name','village','phone','activity','tax_category','location_label','gps_lat','gps_lon','status','created_at']];
    (data || []).forEach(r => rows.push([
      r.taxpayer_code || '', r.first_name || '', r.last_name || '', village?.name || '',
      r.phone || '', r.activity || '', r.tax_category || '', r.location_label || '',
      r.gps_lat ?? '', r.gps_lon ?? '', r.status || '', r.created_at || ''
    ]));
    const wb = window.XLSX.utils.book_new();
    const ws = window.XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = [{wch:20},{wch:20},{wch:20},{wch:26},{wch:18},{wch:24},{wch:22},{wch:28},{wch:14},{wch:14},{wch:16},{wch:24}];
    window.XLSX.utils.book_append_sheet(wb, ws, 'Contribuables');
    const safeVillage = (village?.name || 'village').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_');
    downloadWorkbook(wb, `CONTRIBUABLES_${safeVillage}.xlsx`);
  }

  function normalizeImportHeader(value) {
    return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  }

  function importField(row, aliases) {
    for (const key of aliases) {
      const value = row[key];
      if (value !== undefined && value !== null && String(value).trim() !== '') return String(value).trim();
    }
    return '';
  }

  async function previewTaxpayerImport() {
    const file = $('import-file')?.files?.[0];
    preparedImportRows = [];
    $('import-submit-btn').disabled = true;
    $('import-preview').replaceChildren();
    if (!file) return importMessage('import-submit-message', 'Choisissez un fichier Excel ou CSV.', 'error');
    if (file.size > 5 * 1024 * 1024) return importMessage('import-submit-message', 'Le fichier dépasse la limite de 5 Mo.', 'error');
    if (!window.XLSX) return importMessage('import-submit-message', 'Le lecteur Excel est indisponible. Rechargez la page et réessayez.', 'error');
    importMessage('import-submit-message', 'Lecture et contrôle du fichier…');
    try {
      const bytes = await file.arrayBuffer();
      const workbook = window.XLSX.read(bytes, { type: 'array', cellDates: false });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!firstSheet) throw new Error('Le fichier ne contient aucune feuille.');
      const raw = window.XLSX.utils.sheet_to_json(firstSheet, { defval: '', raw: false });
      if (!raw.length) throw new Error('La première feuille ne contient aucune ligne de données.');
      if (raw.length > 1000) throw new Error('Le fichier dépasse la limite de 1 000 lignes.');
      const villages = state.villages?.length ? state.villages : (await state.db.from('villages').select('id,name,official_code').eq('commune_id', LEONA_COMMUNE_ID).limit(500)).data || [];
      if (!state.villages.length) state.villages = villages;
      const seen = new Set();
      preparedImportRows = raw.map((source, index) => {
        const normalized = {};
        Object.entries(source).forEach(([key, value]) => { normalized[normalizeImportHeader(key)] = value; });
        const code = importField(normalized, ['taxpayer_code','code_contribuable','code','numero_contribuable']);
        const first = importField(normalized, ['first_name','prenom','prenoms','prenom_s']);
        const last = importField(normalized, ['last_name','nom','nom_famille']);
        const villageValue = importField(normalized, ['village_id','village','nom_village','code_village']);
        const village = villages.find(v => v.id === villageValue || (v.name || '').trim().toLocaleLowerCase('fr') === villageValue.toLocaleLowerCase('fr') || (v.official_code && v.official_code.toLocaleLowerCase('fr') === villageValue.toLocaleLowerCase('fr')));
        const errors = [];
        if (!code) errors.push('Code obligatoire');
        if (!first) errors.push('Prénom obligatoire');
        if (!last) errors.push('Nom obligatoire');
        if (!village) errors.push('Village inconnu ou manquant');
        if (code && seen.has(code.toLocaleLowerCase('fr'))) errors.push('Code répété dans le fichier');
        if (code) seen.add(code.toLocaleLowerCase('fr'));
        const phone = importField(normalized, ['phone','telephone','tel']);
        const lat = importField(normalized, ['gps_lat','latitude']);
        const lon = importField(normalized, ['gps_lon','longitude']);
        if ((lat && !lon) || (!lat && lon)) errors.push('Latitude et longitude doivent être ensemble');
        if (lat && (!Number.isFinite(Number(lat)) || Number(lat) < -90 || Number(lat) > 90)) errors.push('Latitude invalide');
        if (lon && (!Number.isFinite(Number(lon)) || Number(lon) < -180 || Number(lon) > 180)) errors.push('Longitude invalide');
        return {
          row_number: index + 2,
          payload: {
            taxpayer_code: code, first_name: first, last_name: last, phone,
            village_id: village?.id || '', activity: importField(normalized, ['activity','activite','activite_economique']),
            tax_category: importField(normalized, ['tax_category','categorie_fiscale','categorie']),
            location_label: importField(normalized, ['location_label','localisation','adresse','quartier']),
            gps_lat: lat, gps_lon: lon
          }, errors
        };
      });
      renderImportPreview();
      const bad = preparedImportRows.filter(r => r.errors.length).length;
      importMessage('import-submit-message', `${preparedImportRows.length} ligne(s) analysée(s) : ${preparedImportRows.length - bad} sans erreur locale, ${bad} avec anomalie. Le serveur effectuera un second contrôle.`, bad ? 'error' : 'success');
      $('import-submit-btn').disabled = false;
    } catch (error) {
      importMessage('import-submit-message', `Analyse impossible : ${error.message}`, 'error');
    }
  }

  function renderImportPreview() {
    const root = $('import-preview');
    root.replaceChildren();
    if (!preparedImportRows.length) return;
    const table = document.createElement('table');
    const head = document.createElement('thead');
    const trh = document.createElement('tr');
    ['Ligne','Code','Prénom','Nom','Village','Contrôle'].forEach(label => { const th=document.createElement('th'); th.textContent=label; trh.append(th); });
    head.append(trh); table.append(head);
    const body = document.createElement('tbody');
    preparedImportRows.slice(0,100).forEach(row => {
      const tr=document.createElement('tr');
      const village=state.villages.find(v=>v.id===row.payload.village_id);
      [row.row_number,row.payload.taxpayer_code,row.payload.first_name,row.payload.last_name,village?.name || '—',row.errors.join(' ; ') || 'À contrôler par Supabase'].forEach(value=>{const td=document.createElement('td');td.textContent=String(value ?? '—');tr.append(td);});
      body.append(tr);
    });
    table.append(body); root.append(table);
    if (preparedImportRows.length > 100) { const note=document.createElement('p');note.className='metric-note';note.textContent=`Aperçu des 100 premières lignes sur ${preparedImportRows.length}.`;root.append(note); }
  }

  async function submitTaxpayerImport() {
    if (!has('imports.create') || !preparedImportRows.length) return;
    const file = $('import-file')?.files?.[0];
    $('import-submit-btn').disabled = true;
    importMessage('import-submit-message','Transmission sécurisée du lot à Supabase…');
    const rows = preparedImportRows.map(r => r.payload);
    const { data, error } = await state.db.rpc('submit_taxpayer_import', { p_file_name: file?.name || 'import', p_rows: rows });
    if (error) {
      $('import-submit-btn').disabled = false;
      importMessage('import-submit-message',`Soumission refusée : ${error.message}`,'error');
      return;
    }
    preparedImportRows = [];
    $('import-preview').replaceChildren();
    $('import-file').value = '';
    importMessage('import-submit-message',`Lot soumis. ${data.row_count} ligne(s), ${data.valid_count} sans erreur serveur, ${data.error_count} avec anomalie. Référence : ${data.batch_id}`,'success');
  }

  async function loadImportBatches() {
    if (has('imports.create')) $('import-submit-panel').classList.remove('hidden');
    const canReview = state.profile?.role === 'secretaire_general' && has('imports.review');
    $('import-review-panel').classList.toggle('hidden', !canReview);
    if (!canReview) return;
    const root = $('import-review-list');
    root.textContent = 'Chargement des lots soumis…';
    const { data, error } = await state.db.from('import_batches')
      .select('id,file_name,row_count,status,created_at,review_reason')
      .eq('commune_id', LEONA_COMMUNE_ID).order('created_at',{ascending:false}).limit(100);
    root.replaceChildren();
    if (error) { root.textContent=`Impossible de lire les lots : ${error.message}`; return; }
    if (!data?.length) { root.textContent='Aucun lot importé pour le moment.'; return; }
    const table=document.createElement('table');const thead=document.createElement('thead');const hr=document.createElement('tr');
    ['Fichier','Lignes','Statut','Date','Action'].forEach(t=>{const th=document.createElement('th');th.textContent=t;hr.append(th);});thead.append(hr);table.append(thead);
    const tbody=document.createElement('tbody');
    data.forEach(batch=>{
      const tr=document.createElement('tr');
      [batch.file_name || 'Import',batch.row_count,batch.status,formatDate(batch.created_at)].forEach(v=>tr.append(makeCell(v)));
      const td=document.createElement('td');const btn=document.createElement('button');btn.type='button';btn.className='btn ghost';btn.textContent='Examiner';btn.addEventListener('click',()=>openImportBatch(batch));td.append(btn);tr.append(td);tbody.append(tr);
    });
    table.append(tbody);root.append(table);
  }

  async function openImportBatch(batch) {
    selectedImportBatch=batch;
    const root=$('import-review-detail');root.textContent='Chargement des lignes du lot…';
    const {data,error}=await state.db.from('import_rows').select('row_number,payload,validation_errors').eq('batch_id',batch.id).order('row_number');
    root.replaceChildren();
    if(error){root.textContent=`Lecture des lignes impossible : ${error.message}`;return;}
    const invalid=(data||[]).filter(r=>Array.isArray(r.validation_errors)&&r.validation_errors.length).length;
    const title=document.createElement('h3');title.textContent=`${batch.file_name || 'Import'} — ${data.length} ligne(s), ${invalid} anomalie(s)`;root.append(title);
    const table=document.createElement('table');const thead=document.createElement('thead');const hr=document.createElement('tr');
    ['Ligne','Code','Prénom','Nom','Village ID','Anomalies'].forEach(t=>{const th=document.createElement('th');th.textContent=t;hr.append(th);});thead.append(hr);table.append(thead);
    const tbody=document.createElement('tbody');(data||[]).slice(0,200).forEach(r=>{const tr=document.createElement('tr');[r.row_number,r.payload?.taxpayer_code,r.payload?.first_name,r.payload?.last_name,r.payload?.village_id,(r.validation_errors||[]).join(' ; ') || 'Aucune'].forEach(v=>tr.append(makeCell(v)));tbody.append(tr);});table.append(tbody);root.append(table);
    if(batch.status==='submitted'){
      const actions=document.createElement('div');actions.className='form-actions';
      const approve=document.createElement('button');approve.type='button';approve.className='btn';approve.textContent='Approuver et intégrer';approve.disabled=invalid>0;approve.addEventListener('click',()=>reviewImport('approve',''));
      const reject=document.createElement('button');reject.type='button';reject.className='btn danger';reject.textContent='Rejeter le lot';reject.addEventListener('click',()=>{const reason=window.prompt('Motif du rejet (5 caractères minimum) :');if(reason!==null)reviewImport('reject',reason);});
      actions.append(approve,reject);root.append(actions);
      if(invalid){const note=document.createElement('p');note.className='form-message error';note.textContent='Corrigez le fichier et soumettez un nouveau lot : ce lot contient des lignes invalides et ne peut pas être approuvé.';root.append(note);}
    }
  }

  async function reviewImport(decision, reason) {
    if(!selectedImportBatch || state.profile?.role!=='secretaire_general') return;
    importMessage('import-review-message','Traitement de la décision…');
    const {data,error}=await state.db.rpc('review_taxpayer_import',{p_batch:selectedImportBatch.id,p_decision:decision,p_reason:reason || null});
    if(error){importMessage('import-review-message',`Opération refusée : ${error.message}`,'error');return;}
    importMessage('import-review-message',decision==='approve'?`${data.inserted_count} contribuable(s) intégrés au registre au statut « en attente ».`:'Lot rejeté avec motif. Aucun contribuable n’a été intégré.','success');
    selectedImportBatch=null;$('import-review-detail').replaceChildren();await loadImportBatches();
  }

  // ============================================================
  // PHASE 14 — BUDGET, DÉPENSES ET TRÉSORERIE
  // Module distinct du grand livre fiscal (payments/receipts).
  // ============================================================
  const ld14 = { accounts: [], budgets: [], lines: [], categories: [], expenses: [], movements: [], balances: [], execution: [], reconciliations: [] };
  const can14 = (permission) => has(permission);
  const msg14 = (id, message, type = '') => { const n = $(id); if (n) { n.textContent = message; n.className = `form-message ${type}`.trim(); } };
  const esc14 = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const table14 = (headers, rows) => {
    if (!rows.length) return '<p class="muted">Aucune donnée enregistrée.</p>';
    return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${esc14(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  };
  const tr14 = (cells) => `<tr>${cells.map(v=>`<td>${esc14(v)}</td>`).join('')}</tr>`;
  const amount14 = (v) => formatAmount(v);
  const dateToday14 = () => new Date().toISOString().slice(0,10);
  function fillSelect14(id, rows, label, value='id', first='') {
    const node=$(id); if(!node) return;
    const old=node.value;
    node.replaceChildren();
    if(first){const opt=document.createElement('option');opt.value='';opt.textContent=first;node.append(opt);}
    rows.forEach(r=>{const opt=document.createElement('option');opt.value=r[value];opt.textContent=label(r);node.append(opt);});
    if([...node.options].some(o=>o.value===old)) node.value=old;
  }
  async function loadLd14Finance() {
    const root=$('ld14-global-message'); if(root) root.textContent='Chargement des données financières…';
    const queries = await Promise.all([
      state.db.from('ld14_treasury_accounts').select('id,account_name,account_type,institution,active,opening_balance,opening_balance_date').order('account_name'),
      state.db.from('ld14_budgets').select('id,fiscal_year,title,total_amount,status,created_by').order('fiscal_year',{ascending:false}),
      state.db.from('ld14_budget_lines').select('id,budget_id,code,label,allocated_amount').order('code'),
      state.db.from('ld14_expense_categories').select('id,name,active').eq('active',true).order('name'),
      state.db.from('ld14_expenses').select('id,description,beneficiary,amount,expense_date,status,reference,budget_line_id,category_id,created_by').order('expense_date',{ascending:false}).limit(200),
      state.db.from('ld14_v_treasury_balances').select('*').order('account_name'),
      state.db.from('ld14_v_budget_execution').select('*').order('fiscal_year',{ascending:false}).limit(300),
      state.db.from('ld14_v_treasury_ledger').select('*').order('movement_date',{ascending:false}).limit(200),
      state.db.from('ld14_reconciliations').select('id,account_id,period_start,period_end,declared_balance,calculated_balance,difference,status,created_at').order('created_at',{ascending:false}).limit(100)
    ]);
    const names=['comptes','budgets','lignes budgétaires','catégories','dépenses','soldes','exécution budgétaire','mouvements','rapprochements'];
    for(let i=0;i<queries.length;i++) if(queries[i].error) console.warn('LD14 lecture '+names[i],queries[i].error.message);
    const get=(i)=>queries[i].error?[]:(queries[i].data||[]);
    [ld14.accounts,ld14.budgets,ld14.lines,ld14.categories,ld14.expenses,ld14.balances,ld14.execution,ld14.movements,ld14.reconciliations]=[get(0),get(1),get(2),get(3),get(4),get(5),get(6),get(7),get(8)];
    renderLd14Finance();
    if(root) root.textContent='Données actualisées. Les modules affichent uniquement les enregistrements accessibles à votre profil.';
  }
  function renderLd14Finance() {
    const metrics=$('ld14-metrics'); metrics.replaceChildren();
    const total=ld14.balances.reduce((s,r)=>s+Number(r.current_balance||0),0);
    const expense=ld14.expenses.filter(e=>e.status==='paid').reduce((s,r)=>s+Number(r.amount||0),0);
    const budgets=ld14.budgets.filter(b=>b.status==='approved').reduce((s,r)=>s+Number(r.total_amount||0),0);
    addMetric(metrics,'Comptes actifs',ld14.accounts.filter(a=>a.active).length,'Comptes de trésorerie');
    addMetric(metrics,'Solde total calculé',amount14(total),'Somme des soldes des comptes visibles');
    addMetric(metrics,'Budgets approuvés',amount14(budgets),'Montants des budgets approuvés');
    addMetric(metrics,'Dépenses payées',amount14(expense),'Dépenses au statut payé');
    fillSelect14('ld14-inflow-account',ld14.accounts.filter(a=>a.active),a=>a.account_name,'id','Choisir un compte');
    fillSelect14('ld14-reconcile-account',ld14.accounts,a=>a.account_name,'id','Choisir un compte');
    fillSelect14('ld14-line-budget',ld14.budgets.filter(b=>b.status==='draft'),b=>`${b.fiscal_year} — ${b.title}`,'id','Choisir un budget brouillon');
    fillSelect14('ld14-expense-category',ld14.categories,c=>c.name,'id','Sans catégorie');
    fillSelect14('ld14-expense-line',ld14.lines.filter(l=>ld14.budgets.some(b=>b.id===l.budget_id&&b.status==='approved')),l=>`${l.code} — ${l.label} (${amount14(l.allocated_amount)})`,'id','Hors budget');
    $('ld14-accounts-list').innerHTML=table14(['Compte','Type','Solde initial','Solde actuel','Mouvements'],ld14.balances.map(a=>tr14([a.account_name,a.account_type,amount14(a.opening_balance),amount14(a.current_balance),a.movement_count])));
    $('ld14-budgets-list').innerHTML=table14(['Exercice','Budget','Montant','État','Action'],ld14.budgets.map(b=>{
      let action='';
      if(b.status==='draft'&&can14('budgets.manage')) action=`<button class="btn btn-small" data-ld14-submit-budget="${esc14(b.id)}">Soumettre</button>`;
      if(b.status==='submitted'&&can14('budgets.approve')) action=`<button class="btn btn-small" data-ld14-approve-budget="${esc14(b.id)}">Approuver</button>`;
      return `<tr>${[b.fiscal_year,b.title,amount14(b.total_amount),b.status].map(v=>`<td>${esc14(v)}</td>`).join('')}<td>${action||'—'}</td></tr>`;
    }));
    $('ld14-categories-list').innerHTML=table14(['Catégorie','État'],ld14.categories.map(c=>tr14([c.name,c.active?'Active':'Inactive'])));
    $('ld14-expenses-list').innerHTML=table14(['Date','Objet','Bénéficiaire','Montant','État','Action'],ld14.expenses.map(e=>{
      let actions='';
      if(e.status==='draft'&&can14('expenses.manage')) actions+=`<button class="btn btn-small" data-ld14-submit-expense="${esc14(e.id)}">Soumettre</button> `;
      if(e.status==='submitted'&&can14('expenses.approve')&&e.created_by!==state.userId) actions+=`<button class="btn btn-small" data-ld14-approve-expense="${esc14(e.id)}">Valider</button> `;
      if(e.status==='approved'&&can14('expenses.pay')&&can14('treasury.manage')) actions+=`<button class="btn btn-small" data-ld14-pay-expense="${esc14(e.id)}">Payer</button>`;
      return `<tr>${[formatDate(e.expense_date),e.description,e.beneficiary||'—',amount14(e.amount),e.status].map(v=>`<td>${esc14(v)}</td>`).join('')}<td>${actions||'—'}</td></tr>`;
    }));
    $('ld14-execution-list').innerHTML=table14(['Exercice','Ligne','Crédit','Engagé','Payé','Disponible','Exécution'],ld14.execution.map(e=>tr14([e.fiscal_year,`${e.line_code} — ${e.line_label}`,amount14(e.allocated_amount),amount14(e.committed_amount),amount14(e.paid_amount),amount14(e.available_amount),`${e.execution_rate}%`])));
    $('ld14-movements-list').innerHTML=table14(['Date','Compte','Type','Montant','Description','Action'],ld14.movements.map(m=>{
      const action=can14('treasury.manage')&&m.source_type!=='reversal'&&m.source_type!=='expense'?`<button class="btn btn-small danger" data-ld14-reverse="${esc14(m.movement_id)}">Contrepasser</button>`:'—';
      return `<tr>${[formatDate(m.movement_date),m.account_name,m.movement_type,amount14(m.amount),m.description].map(v=>`<td>${esc14(v)}</td>`).join('')}<td>${action}</td></tr>`;
    }));
    $('ld14-reconciliations-list').innerHTML=table14(['Période','Compte','Solde déclaré','Solde calculé','Écart','État'],ld14.reconciliations.map(r=>tr14([`${formatDate(r.period_start)} – ${formatDate(r.period_end)}`,ld14.accounts.find(a=>a.id===r.account_id)?.account_name||'Compte',amount14(r.declared_balance),amount14(r.calculated_balance),amount14(r.difference),r.status])));
    // Les formulaires de gestion sont masqués selon les permissions réelles.
    $('ld14-account-form').classList.toggle('hidden',!can14('treasury.manage'));
    $('ld14-inflow-form').classList.toggle('hidden',!can14('treasury.manage'));
    $('ld14-budget-form').classList.toggle('hidden',!can14('budgets.manage'));
    $('ld14-line-form').classList.toggle('hidden',!can14('budgets.manage'));
    $('ld14-category-form').classList.toggle('hidden',!can14('expenses.manage'));
    $('ld14-expense-form').classList.toggle('hidden',!can14('expenses.manage'));
    $('ld14-reconcile-form').classList.toggle('hidden',!can14('treasury.reconcile'));
  }
  async function rpc14(name,args,messageId) {
    const {data,error}=await state.db.rpc(name,args);
    if(error){msg14(messageId,`Opération refusée : ${error.message}`,'error');return null;}
    msg14(messageId,'Opération enregistrée avec succès.','success');
    await loadLd14Finance(); return data;
  }
  async function submit14Form(event,table,payload,messageId,success) {
    event.preventDefault();
    const {error}=await state.db.from(table).insert(payload);
    if(error){msg14(messageId,`Enregistrement refusé : ${error.message}`,'error');return false;}
    msg14(messageId,success,'success');event.target.reset();await loadLd14Finance();return true;
  }
  function bindLd14Events() {
    $('ld14-refresh').addEventListener('click',loadLd14Finance);
    $('ld14-account-form').addEventListener('submit',async e=>{
      e.preventDefault();
      const payload={commune_id:LEONA_COMMUNE_ID,account_name:$('ld14-account-name').value.trim(),account_type:$('ld14-account-type').value,institution:$('ld14-account-institution').value.trim()||null,account_reference:$('ld14-account-ref').value.trim()||null,currency:'XOF',active:true,created_by:state.userId};
      const {data,error}=await state.db.from('ld14_treasury_accounts').insert(payload).select('id').single();
      if(error){msg14('ld14-account-message',`Création refusée : ${error.message}`,'error');return;}
      const {error:openingError}=await state.db.rpc('ld14_set_opening_balance',{p_account_id:data.id,p_amount:Number($('ld14-opening').value),p_date:$('ld14-opening-date').value});
      if(openingError){msg14('ld14-account-message',`Compte créé, mais solde initial non enregistré : ${openingError.message}`,'error');await loadLd14Finance();return;}
      msg14('ld14-account-message','Compte et solde initial enregistrés.','success');e.target.reset();await loadLd14Finance();
    });
    $('ld14-inflow-form').addEventListener('submit',e=>{e.preventDefault();rpc14('ld14_record_inflow',{p_account_id:$('ld14-inflow-account').value,p_amount:Number($('ld14-inflow-amount').value),p_description:$('ld14-inflow-description').value.trim(),p_reference:$('ld14-inflow-reference').value.trim()||null,p_movement_date:new Date().toISOString()},'ld14-inflow-message');});
    $('ld14-budget-form').addEventListener('submit',e=>submit14Form(e,'ld14_budgets',{commune_id:LEONA_COMMUNE_ID,fiscal_year:Number($('ld14-budget-year').value),title:$('ld14-budget-title').value.trim(),description:$('ld14-budget-description').value.trim()||null,total_amount:Number($('ld14-budget-total').value),status:'draft',created_by:state.userId},'ld14-budget-message','Budget brouillon créé.'));
    $('ld14-line-form').addEventListener('submit',e=>submit14Form(e,'ld14_budget_lines',{commune_id:LEONA_COMMUNE_ID,budget_id:$('ld14-line-budget').value,code:$('ld14-line-code').value.trim(),label:$('ld14-line-label').value.trim(),allocated_amount:Number($('ld14-line-amount').value),created_by:state.userId},'ld14-line-message','Ligne budgétaire ajoutée.'));
    $('ld14-category-form').addEventListener('submit',e=>submit14Form(e,'ld14_expense_categories',{commune_id:LEONA_COMMUNE_ID,name:$('ld14-category-name').value.trim(),description:$('ld14-category-description').value.trim()||null,active:true},'ld14-category-message','Catégorie créée.'));
    $('ld14-expense-form').addEventListener('submit',e=>submit14Form(e,'ld14_expenses',{commune_id:LEONA_COMMUNE_ID,description:$('ld14-expense-description').value.trim(),beneficiary:$('ld14-expense-beneficiary').value.trim()||null,reference:$('ld14-expense-reference').value.trim()||null,amount:Number($('ld14-expense-amount').value),expense_date:$('ld14-expense-date').value,payment_method:$('ld14-expense-method').value,category_id:$('ld14-expense-category').value||null,budget_line_id:$('ld14-expense-line').value||null,status:'draft',created_by:state.userId},'ld14-expense-message','Dépense enregistrée en brouillon.'));
    $('ld14-reconcile-form').addEventListener('submit',e=>{e.preventDefault();rpc14('ld14_reconcile_account',{p_account_id:$('ld14-reconcile-account').value,p_period_start:$('ld14-period-start').value,p_period_end:$('ld14-period-end').value,p_declared_balance:Number($('ld14-declared-balance').value),p_notes:$('ld14-reconcile-notes').value.trim()||null},'ld14-reconcile-message');});
    document.addEventListener('click',async e=>{
      const b=e.target.closest('[data-ld14-submit-budget],[data-ld14-approve-budget],[data-ld14-submit-expense],[data-ld14-approve-expense],[data-ld14-pay-expense],[data-ld14-reverse]');if(!b)return;
      if(b.dataset.ld14SubmitBudget) return rpc14('ld14_submit_budget',{p_budget_id:b.dataset.ld14SubmitBudget},'ld14-global-message');
      if(b.dataset.ld14ApproveBudget) return rpc14('ld14_approve_budget',{p_budget_id:b.dataset.ld14ApproveBudget},'ld14-global-message');
      if(b.dataset.ld14SubmitExpense) return rpc14('ld14_submit_expense',{p_expense_id:b.dataset.ld14SubmitExpense},'ld14-global-message');
      if(b.dataset.ld14ApproveExpense) return rpc14('ld14_validate_expense',{p_expense_id:b.dataset.ld14ApproveExpense},'ld14-global-message');
      if(b.dataset.ld14PayExpense){const active=ld14.accounts.filter(a=>a.active);const choice=window.prompt('Choisissez le compte à utiliser en saisissant son numéro :\n'+active.map((a,i)=>`${i+1}. ${a.account_name} — ${amount14(a.current_balance||0)}`).join('\n'));const account=active[Number(choice)-1];if(account)return rpc14('ld14_pay_expense',{p_expense_id:b.dataset.ld14PayExpense,p_account_id:account.id},'ld14-global-message');}
      if(b.dataset.ld14Reverse){const reason=window.prompt('Motif obligatoire de la contrepassation (5 caractères minimum) :');if(reason!==null)return rpc14('ld14_reverse_movement',{p_movement_id:b.dataset.ld14Reverse,p_reason:reason.trim()},'ld14-global-message');}
    });
  }

  // PHASE 15 — cartographie fiscale. Toutes les lectures restent soumises aux politiques RLS existantes.
  const MAP_FINANCE_ACCESS = () => has('assessments.read');
  const MAP_COLORS = { paid:'#16834a', partial:'#e58b18', unpaid:'#d33d3d', none:'#7561b5', pending:'#e6c33b', inactive:'#7d8790', unknown:'#536b7a' };
  const MAP_EMOJI = [
    [/agric|mara[iî]ch|cult|ferme|paysan|horti/i,'🌱'], [/commerce|boutique|march|vente|vendeur/i,'🛒'],
    [/artisan|menuis|coutur|m[eé]can|forger|ma[cç]on/i,'🛠️'], [/transport|chauff|taxi|car|moto|livreur/i,'🛵'],
    [/restaur|aliment|boulanger|boucher|poisson|traiteur/i,'🍲'], [/service|conseil|bureau|profession/i,'💼'],
    [/p[eê]che|p[eê]cheur/i,'🎣'], [/elev|b[eê]tail|berger|ovin|bovin/i,'🐄'],
    [/construction|b[aâ]timent|entrepreneur/i,'🏗️'], [/enseignement|[eé]cole|formation/i,'📚'],
    [/sant[eé]|pharma|m[eé]decin/i,'⚕️'], [/num[eé]rique|informat|t[eé]l[eé]com/i,'💻']
  ];
  function mapEmoji(activity){ const a=String(activity||'').trim(); return MAP_EMOJI.find(([re])=>re.test(a))?.[1] || (a?'📍':'🧾'); }
  function mapSituation(taxpayer, totals){
    if(taxpayer.status==='inactive') return 'inactive';
    if(!MAP_FINANCE_ACCESS()) return taxpayer.status==='pending'?'pending':'unknown';
    if(taxpayer.status==='pending') return 'pending';
    if(!totals || totals.count===0 || totals.due<=0) return 'none';
    if(totals.balance<=0.01) return 'paid';
    if(totals.paid>0) return 'partial';
    return 'unpaid';
  }
  function mapAggregate(rows){ return rows.reduce((a,r)=>{a.due+=Number(r.amount_due||0);a.paid+=Number(r.amount_paid||0);a.balance+=Number(r.balance||0);a.count++;return a;},{due:0,paid:0,balance:0,count:0}); }
  function mapFilteredData(){
    const village=$('map-village').value, activity=$('map-activity').value, category=$('map-category').value, situation=$('map-status').value;
    const from=$('map-from').value, to=$('map-to').value, term=$('map-search').value.trim().toLocaleLowerCase('fr');
    const fiscalByTaxpayer=new Map();
    state.mapFiscalRows.forEach(r=>{ if(from && r.period_end<from) return; if(to && r.period_start>to) return; const list=fiscalByTaxpayer.get(r.taxpayer_id)||[]; list.push(r); fiscalByTaxpayer.set(r.taxpayer_id,list); });
    return state.mapTaxpayers.filter(t=>{
      if(village && t.village_id!==village) return false;
      if(activity && (t.activity||'').trim()!==activity) return false;
      if(category && (t.tax_category_display||t.tax_category||'').trim()!==category) return false;
      const rows=fiscalByTaxpayer.get(t.id)||[]; const totals=mapAggregate(rows); const status=mapSituation(t,totals);
      if(situation!=='all' && situation!==status) return false;
      if(term && !`${t.taxpayer_code||''} ${t.first_name||''} ${t.last_name||''} ${t.activity||''} ${t.location_label||''}`.toLocaleLowerCase('fr').includes(term)) return false;
      return true;
    }).map(t=>{const rows=fiscalByTaxpayer.get(t.id)||[];return {...t,fiscal:mapAggregate(rows),situation:mapSituation(t,mapAggregate(rows))};});
  }
  async function mapFetchAll(table, columns, orderColumn='created_at'){
    let all=[],start=0,chunk=1000;
    while(true){let q=state.db.from(table).select(columns).eq('commune_id',LEONA_COMMUNE_ID).order(orderColumn,{ascending:false}).range(start,start+chunk-1);const {data,error}=await q;if(error)throw error;all=all.concat(data||[]);if(!data||data.length<chunk)break;start+=chunk;if(start>=10000)break;}
    return all;
  }
  async function loadFiscalMap(){
    const note=$('map-data-note'); note.textContent='Chargement des contribuables, coordonnées et données fiscales autorisées…';
    $('map-detail').textContent='Sélectionnez un symbole sur la carte pour consulter la fiche et la situation fiscale du contribuable.';
    try{
      const [villages,taxpayers]=await Promise.all([
        state.db.from('villages').select('id,name,official_code').eq('commune_id',LEONA_COMMUNE_ID).order('name').limit(1000),
        mapFetchAll('taxpayers','id,commune_id,taxpayer_code,first_name,last_name,phone,village_id,activity,tax_category,tax_category_id,location_label,gps_lat,gps_lon,status,created_at')
      ]);
      if(villages.error) throw villages.error;
      state.villages=villages.data||[]; state.mapTaxpayers=taxpayers;
      state.mapCategories=[];
      if(has('categories.read')){const cats=await state.db.from('tax_categories').select('id,label').eq('commune_id',LEONA_COMMUNE_ID).order('label').limit(500);if(cats.error)console.warn('PHASE15_CATEGORY_READ',cats.error.message);else state.mapCategories=cats.data||[];}
      state.mapTaxpayers=state.mapTaxpayers.map(t=>({...t,tax_category_display:state.mapCategories.find(c=>c.id===t.tax_category_id)?.label||t.tax_category||''}));
      if(MAP_FINANCE_ACCESS()){
        state.mapFiscalRows=await mapFetchAll('v_assessment_balances','assessment_id,taxpayer_id,commune_id,taxpayer_code,first_name,last_name,village_id,period_start,period_end,amount_due,amount_paid,balance','period_start');
      } else state.mapFiscalRows=[];
      fillMapFilters(); renderFiscalMap(); note.textContent=`${state.mapTaxpayers.length} fiche(s) de contribuables accessibles ; ${state.mapFiscalRows.length} évaluation(s) fiscales accessibles. Les finances ${MAP_FINANCE_ACCESS()?'sont visibles selon vos droits':'ne sont pas affichées pour ce profil'}.`;
    }catch(error){console.error('PHASE15_MAP_LOAD',error);note.textContent=`Chargement impossible : ${error.message}. Vérifiez les permissions RLS de votre compte.`; $('map-village-table').textContent='Données indisponibles.';}
  }
  function fillMapFilters(){
    const fill=(id,items,label)=>{const node=$(id),previous=node.value;node.replaceChildren(new Option(label,''));items.forEach(v=>node.add(new Option(v,v)));if(items.includes(previous))node.value=previous;};
    const village=$('map-village'),previous=village.value;village.replaceChildren(new Option('Tous les villages accessibles',''));state.villages.forEach(v=>village.add(new Option(v.name,v.id)));if(state.villages.some(v=>v.id===previous))village.value=previous;
    fill('map-activity',[...new Set(state.mapTaxpayers.map(t=>(t.activity||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr')),'Toutes les activités');
    fill('map-category',[...new Set(state.mapTaxpayers.map(t=>(t.tax_category_display||t.tax_category||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr')),'Toutes les natures fiscales');
  }
  function mapSetKpis(rows){
    const due=rows.reduce((s,r)=>s+r.fiscal.due,0),paid=rows.reduce((s,r)=>s+r.fiscal.paid,0),balance=rows.reduce((s,r)=>s+r.fiscal.balance,0),rate=due>0?paid/due*100:0;
    $('map-kpi-taxpayers').textContent=rows.length.toLocaleString('fr-FR');$('map-kpi-located').textContent=rows.filter(t=>Number.isFinite(Number(t.gps_lat))&&Number.isFinite(Number(t.gps_lon))&&t.gps_lat!==null&&t.gps_lon!==null).length.toLocaleString('fr-FR');
    $('map-kpi-due').textContent=MAP_FINANCE_ACCESS()?formatAmount(due):'Non autorisé';$('map-kpi-paid').textContent=MAP_FINANCE_ACCESS()?formatAmount(paid):'Non autorisé';$('map-kpi-balance').textContent=MAP_FINANCE_ACCESS()?formatAmount(balance):'Non autorisé';$('map-kpi-rate').textContent=MAP_FINANCE_ACCESS()?(due>0?rate.toLocaleString('fr-FR',{maximumFractionDigits:1})+' %':'—'):'Non autorisé';
  }
  function mapIcon(t){return L.divIcon({className:'',html:`<div class="taxpayer-map-marker ${t.situation}"><span>${mapEmoji(t.activity)}</span></div>`,iconSize:[34,34],iconAnchor:[17,31],popupAnchor:[0,-29]});}
  function mapSafeText(value){return String(value??'—');}
  function showMapDetail(t){
    const root=$('map-detail');root.className='map-detail';root.replaceChildren();const title=document.createElement('h3');title.textContent=`${t.first_name||''} ${t.last_name||''}`.trim()||'Contribuable';root.append(title);
    const grid=document.createElement('div');grid.className='map-detail-grid';const village=state.villages.find(v=>v.id===t.village_id)?.name||'Village non renseigné';const items=[['Code contribuable',t.taxpayer_code],['Village',village],['Activité',t.activity],['Nature fiscale',t.tax_category_display||t.tax_category],['Localisation',t.location_label],['Situation',({paid:'À jour / soldé',partial:'Paiement partiel',unpaid:'Impayé',none:'Non évalué',pending:'En attente de validation',inactive:'Inactif',unknown:'Données fiscales non accessibles'})[t.situation]],['Montant prévu',MAP_FINANCE_ACCESS()?formatAmount(t.fiscal.due):'Non autorisé'],['Montant collecté net',MAP_FINANCE_ACCESS()?formatAmount(t.fiscal.paid):'Non autorisé'],['Reste à payer',MAP_FINANCE_ACCESS()?formatAmount(t.fiscal.balance):'Non autorisé'],['Taux de paiement',MAP_FINANCE_ACCESS()&&t.fiscal.due>0?(t.fiscal.paid/t.fiscal.due*100).toLocaleString('fr-FR',{maximumFractionDigits:1})+' %':'—'],['Coordonnées GPS',t.gps_lat!=null&&t.gps_lon!=null?`${t.gps_lat}, ${t.gps_lon}`:'Non renseignées']];
    items.forEach(([label,value])=>{const cell=document.createElement('div'),strong=document.createElement('strong'),span=document.createElement('span');strong.textContent=label;span.textContent=mapSafeText(value);cell.append(strong,span);grid.append(cell);});root.append(grid);
    if(MAP_FINANCE_ACCESS()&&t._assessments?.length){const h=document.createElement('h4');h.textContent='Détail des évaluations par période';root.append(h);const table=document.createElement('table'),thead=document.createElement('thead'),tr=document.createElement('tr');['Période','Prévu','Payé net','Reste'].forEach(x=>{const th=document.createElement('th');th.textContent=x;tr.append(th)});thead.append(tr);table.append(thead);const body=document.createElement('tbody');t._assessments.forEach(r=>{const row=document.createElement('tr');[`${formatDate(r.period_start)} – ${formatDate(r.period_end)}`,formatAmount(r.amount_due),formatAmount(r.amount_paid),formatAmount(r.balance)].forEach(v=>row.append(makeCell(v)));body.append(row)});table.append(body);root.append(table);}
  }
  function mapBuildVillageStats(rows){
    const groups=new Map();rows.forEach(t=>{const id=t.village_id||'unknown';if(!groups.has(id))groups.set(id,{id,name:state.villages.find(v=>v.id===id)?.name||'Village non renseigné',taxpayers:0,located:0,due:0,paid:0,balance:0});const g=groups.get(id);g.taxpayers++;if(t.gps_lat!=null&&t.gps_lon!=null)g.located++;g.due+=t.fiscal.due;g.paid+=t.fiscal.paid;g.balance+=t.fiscal.balance;});return [...groups.values()].map(g=>({...g,rate:g.due>0?g.paid/g.due*100:null})).sort((a,b)=>(b.rate??-1)-(a.rate??-1));
  }
  function mapBuildActivityStats(rows){const groups=new Map();rows.forEach(t=>{const name=(t.activity||'Activité non renseignée').trim();if(!groups.has(name))groups.set(name,{name,taxpayers:0,due:0,paid:0,balance:0});const g=groups.get(name);g.taxpayers++;g.due+=t.fiscal.due;g.paid+=t.fiscal.paid;g.balance+=t.fiscal.balance;});return [...groups.values()].map(g=>({...g,rate:g.due>0?g.paid/g.due*100:null})).sort((a,b)=>(b.rate??-1)-(a.rate??-1));}
  function mapRenderCharts(villages,activities){
    if(!window.Chart)return;
    if(state.mapVillageChart)state.mapVillageChart.destroy();if(state.mapActivityChart)state.mapActivityChart.destroy();
    const vctx=$('map-village-chart').getContext('2d'),actx=$('map-activity-chart').getContext('2d');
    if(MAP_FINANCE_ACCESS()){
      state.mapVillageChart=new Chart(vctx,{type:'bar',data:{labels:villages.map(v=>v.name),datasets:[{label:'Prévu (FCFA)',data:villages.map(v=>v.due),backgroundColor:'#9aa8a0'},{label:'Collecté net (FCFA)',data:villages.map(v=>v.paid),backgroundColor:'#16834a'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:true,ticks:{callback:v=>Number(v).toLocaleString('fr-FR')}}}}});
      state.mapActivityChart=new Chart(actx,{type:'bar',data:{labels:activities.map(a=>a.name),datasets:[{label:'Taux de recouvrement (%)',data:activities.map(a=>a.rate??0),backgroundColor:activities.map(a=>a.rate===null?'#aeb8b1':a.rate>=75?'#16834a':a.rate>=40?'#e0a12b':'#d34a4a')}]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,max:100,ticks:{callback:v=>v+' %'}}}}});
    } else {
      state.mapVillageChart=new Chart(vctx,{type:'bar',data:{labels:villages.map(v=>v.name),datasets:[{label:'Contribuables recensés',data:villages.map(v=>v.taxpayers),backgroundColor:'#16834a'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
      state.mapActivityChart=new Chart(actx,{type:'bar',data:{labels:activities.map(a=>a.name),datasets:[{label:'Contribuables recensés',data:activities.map(a=>a.taxpayers),backgroundColor:'#597caa'}]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});
    }
  }
  function mapRenderTables(villages,activities,rows){
    const vr=$('map-village-table');vr.replaceChildren();const table=document.createElement('table'),head=document.createElement('thead'),hr=document.createElement('tr');['Village','Contribuables','GPS','Prévu','Collecté','Reste','Taux'].forEach(x=>{const th=document.createElement('th');th.textContent=x;hr.append(th)});head.append(hr);table.append(head);const body=document.createElement('tbody');villages.forEach(v=>{const tr=document.createElement('tr');tr.className='map-village-row';tr.tabIndex=0;const vals=[v.name,v.taxpayers,v.located,MAP_FINANCE_ACCESS()?formatAmount(v.due):'—',MAP_FINANCE_ACCESS()?formatAmount(v.paid):'—',MAP_FINANCE_ACCESS()?formatAmount(v.balance):'—',MAP_FINANCE_ACCESS()?(v.rate===null?'—':v.rate.toLocaleString('fr-FR',{maximumFractionDigits:1})+' %'):'—'];vals.forEach((x,i)=>{const td=makeCell(x);if(i===6&&v.rate!==null){td.className=`map-rate ${v.rate>=75?'high':v.rate>=40?'mid':'low'}`;}tr.append(td)});const choose=()=>{$('map-village').value=v.id==='unknown'?'':v.id;renderFiscalMap();};tr.addEventListener('click',choose);tr.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose();}});body.append(tr)});table.append(body);vr.append(table);
    const ar=$('map-activity-table');ar.replaceChildren();const at=document.createElement('table'),ah=document.createElement('thead'),ahr=document.createElement('tr');['Activité','Village','Contribuables','Prévu','Collecté','Reste','Taux'].forEach(x=>{const th=document.createElement('th');th.textContent=x;ahr.append(th)});ah.append(ahr);at.append(ah);const ab=document.createElement('tbody');const activityFilter=$('map-activity').value;const villagesList=[...new Set(rows.map(t=>t.village_id||'unknown'))];villagesList.forEach(id=>{const villageName=state.villages.find(v=>v.id===id)?.name||'Village non renseigné';const acts=new Map();rows.filter(t=>(t.village_id||'unknown')===id).forEach(t=>{const n=(t.activity||'Activité non renseignée').trim();if(activityFilter&&n!==activityFilter)return;const g=acts.get(n)||{count:0,due:0,paid:0,balance:0};g.count++;g.due+=t.fiscal.due;g.paid+=t.fiscal.paid;g.balance+=t.fiscal.balance;acts.set(n,g)});acts.forEach((g,n)=>{const rate=g.due>0?g.paid/g.due*100:null,tr=document.createElement('tr');[n,villageName,g.count,MAP_FINANCE_ACCESS()?formatAmount(g.due):'—',MAP_FINANCE_ACCESS()?formatAmount(g.paid):'—',MAP_FINANCE_ACCESS()?formatAmount(g.balance):'—',MAP_FINANCE_ACCESS()&&rate!==null?rate.toLocaleString('fr-FR',{maximumFractionDigits:1})+' %':'—'].forEach(x=>tr.append(makeCell(x)));ab.append(tr)});});at.append(ab);ar.append(at);if(!ab.children.length)ar.textContent='Aucune donnée ne correspond aux filtres.';
  }
  function renderFiscalMap(){
    const rows=mapFilteredData();mapSetKpis(rows);const located=rows.filter(t=>t.gps_lat!==null&&t.gps_lon!==null&&Number.isFinite(Number(t.gps_lat))&&Number.isFinite(Number(t.gps_lon)));
    $('map-point-count').textContent=`${located.length} point(s) GPS / ${rows.length} fiche(s)`;
    if(!window.L){$('tax-map').textContent='La bibliothèque cartographique n’a pas pu être chargée. Vérifiez votre connexion Internet.';return;}
    if(!state.map){state.map=L.map('tax-map',{preferCanvas:true}).setView([15.05,-16.25],8);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(state.map);state.mapCluster=window.L.markerClusterGroup?L.markerClusterGroup({showCoverageOnHover:false,spiderfyOnMaxZoom:true,chunkedLoading:true}):L.layerGroup();state.mapCluster.addTo(state.map);}
    if(state.mapCluster)state.mapCluster.clearLayers();state.mapMarkers=[];
    located.forEach(t=>{const fiscalRows=state.mapFiscalRows.filter(r=>r.taxpayer_id===t.id&&(!$('map-from').value||r.period_end>=$('map-from').value)&&(!$('map-to').value||r.period_start<=$('map-to').value));t._assessments=fiscalRows;const marker=L.marker([Number(t.gps_lat),Number(t.gps_lon)],{icon:mapIcon(t)});const village=state.villages.find(v=>v.id===t.village_id)?.name||'Village non renseigné';const popup=document.createElement('div');const name=document.createElement('strong');name.textContent=`${t.first_name||''} ${t.last_name||''}`.trim();const line=document.createElement('div');line.textContent=`${village} • ${t.activity||'Activité non renseignée'}`;const status=document.createElement('div');status.textContent=({paid:'Soldé',partial:'Paiement partiel',unpaid:'Impayé',none:'Non évalué',pending:'En attente',inactive:'Inactif'})[t.situation];popup.append(name,line,status);marker.bindPopup(popup);marker.on('click',()=>showMapDetail(t));state.mapMarkers.push(marker);state.mapCluster.addLayer(marker);});
    if(located.length){const bounds=L.latLngBounds(located.map(t=>[Number(t.gps_lat),Number(t.gps_lon)]));state.map.fitBounds(bounds.pad(.15),{maxZoom:15});}else state.map.setView([15.05,-16.25],8);
    const villages=mapBuildVillageStats(rows),activities=mapBuildActivityStats(rows);mapRenderCharts(villages,activities);mapRenderTables(villages,activities,rows);setTimeout(()=>state.map.invalidateSize(),100);
    const missing=rows.length-located.length;$('map-data-note').textContent=`${rows.length} contribuable(s) filtré(s), ${located.length} géolocalisé(s), ${missing} sans coordonnées. ${MAP_FINANCE_ACCESS()?'Les calculs portent sur les évaluations accessibles et la période choisie.':'Les chiffres financiers sont masqués pour votre profil.'}`;
  }
  function exportFiscalMap(){
    const rows=mapFilteredData();const out=[['Code','Prénom','Nom','Village','Activité','Nature fiscale','Situation','Latitude','Longitude','Montant prévu','Montant collecté net','Reste','Taux (%)']];rows.forEach(t=>out.push([t.taxpayer_code,t.first_name,t.last_name,state.villages.find(v=>v.id===t.village_id)?.name||'',t.activity,t.tax_category_display||t.tax_category,t.situation,t.gps_lat??'',t.gps_lon??'',MAP_FINANCE_ACCESS()?t.fiscal.due:'',MAP_FINANCE_ACCESS()?t.fiscal.paid:'',MAP_FINANCE_ACCESS()?t.fiscal.balance:'',MAP_FINANCE_ACCESS()&&t.fiscal.due>0?(t.fiscal.paid/t.fiscal.due*100).toFixed(2):'']));const csv='\ufeff'+out.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(';')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='LEONA_PHASE15_ANALYSE_CARTOGRAPHIQUE.csv';a.click();URL.revokeObjectURL(url);
  }

  function configureNavigation() {
    bindLd14Events();
    $('nav-villages').classList.remove('hidden');
    if (has('taxpayers.read')) $('nav-taxpayers').classList.remove('hidden');
    if (has('imports.create') || (state.profile?.role === 'secretaire_general' && has('imports.review'))) $('nav-imports').classList.remove('hidden');
    if (has('finance.read', 'payments.read', 'payments.collect')) $('nav-finance').classList.remove('hidden');
    if (has('finance.read')) $('nav-finance-admin').classList.remove('hidden');
    if (has('assessments.read', 'finance.read', 'payments.read')) $('nav-suivi').classList.remove('hidden');
    if (has('taxpayers.read')) $('nav-cartographie').classList.remove('hidden');
    if (has('users.manage') && has('agents.manage')) $('nav-administration').classList.remove('hidden');
    if (has('audit.read')) $('nav-audit').classList.remove('hidden');

    document.querySelectorAll('.nav-btn').forEach((button) => {
      button.addEventListener('click', () => showView(button.dataset.view));
    });
    document.querySelectorAll('.controller-open, .collector-open').forEach((button) => {
      button.addEventListener('click', () => showView(button.dataset.target));
    });

    if (has('settings.manage')) $('village-manager').classList.remove('hidden');
    if (has('users.manage') && has('agents.manage')) {
      $('agent-create-form').addEventListener('submit', createAgent);
      $('agent-edit-form').addEventListener('submit', updateAgent);
      $('agent-edit-cancel').addEventListener('click', () => $('agent-edit-panel').classList.add('hidden'));
      $('assignment-form').addEventListener('submit', createAssignment);
      $('agents-refresh').addEventListener('click', loadAdministration);
      $('assignments-refresh').addEventListener('click', loadAdministration);
    }
    if (has('recensement.manage')) $('taxpayer-manager').classList.remove('hidden');
    $('taxpayer-form').addEventListener('submit', saveTaxpayer);
    $('import-preview-btn').addEventListener('click', previewTaxpayerImport);
    $('download-import-template').addEventListener('click', downloadTaxpayerImportTemplate);
    $('export-villages-reference').addEventListener('click', exportVillageReference);
    $('taxpayer-export-excel').addEventListener('click', exportCurrentVillageTaxpayers);
    $('import-submit-btn').addEventListener('click', submitTaxpayerImport);
    $('import-review-refresh').addEventListener('click', loadImportBatches);
    $('taxpayer-refresh').addEventListener('click', loadTaxpayers);
    $('village-form').addEventListener('submit', saveVillage);
    $('village-cancel').addEventListener('click', resetVillageForm);
    $('village-refresh').addEventListener('click', loadVillages);
    $('village-search-reset').addEventListener('click', () => { $('village-search').value = ''; loadVillages(); });
    $('village-search').addEventListener('input', () => {
      const term = $('village-search').value.trim().toLocaleLowerCase('fr');
      renderVillages(state.villages.filter((v) => `${v.name || ''} ${v.official_code || ''}`.toLocaleLowerCase('fr').includes(term)));
    });

    $('taxpayer-search-btn').addEventListener('click', loadTaxpayers);
    $('taxpayer-village-filter').addEventListener('change', loadTaxpayers);
    $('taxpayer-sort').addEventListener('change', loadTaxpayers);
    $('taxpayer-reset-btn').addEventListener('click', () => {
      $('taxpayer-search').value = '';
      $('taxpayer-sort').value = 'name_asc';
      $('taxpayer-village-filter').value = '';
      loadTaxpayers();
    });
    $('taxpayer-search').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') loadTaxpayers();
    });
    $('suivi-refresh').addEventListener('click', loadFiscalTracking);
    ['suivi-village','suivi-status','suivi-from','suivi-to','suivi-sort'].forEach(id => $(id).addEventListener('change', renderFiscalTracking));
    $('suivi-search').addEventListener('input', renderFiscalTracking);
    $('suivi-reset').addEventListener('click', () => {
      $('suivi-village').value = ''; $('suivi-status').value = 'all'; $('suivi-from').value = ''; $('suivi-to').value = ''; $('suivi-search').value = ''; $('suivi-sort').value = 'village'; renderFiscalTracking();
    });
    $('suivi-export').addEventListener('click', exportFiscalTracking);
    $('suivi-print').addEventListener('click', () => window.print());
    $('map-refresh').addEventListener('click', loadFiscalMap);
    ['map-village','map-activity','map-category','map-status','map-from','map-to'].forEach(id=>$(id).addEventListener('change',renderFiscalMap));
    $('map-search').addEventListener('input',renderFiscalMap);
    $('map-reset').addEventListener('click',()=>{['map-village','map-activity','map-category'].forEach(id=>$(id).value='');$('map-status').value='all';['map-from','map-to','map-search'].forEach(id=>$(id).value='');renderFiscalMap();});
    $('map-export').addEventListener('click',exportFiscalMap);
    $('map-print').addEventListener('click',()=>window.print());
    $('finance-refresh').addEventListener('click', loadFinance);
    ['finance-search','finance-operation','finance-status','finance-method','finance-date-from','finance-date-to'].forEach((id) => {
      const node = $(id);
      if (!node) return;
      node.addEventListener(id === 'finance-search' ? 'input' : 'change', () => {
        renderFinanceRows(applyFinanceFilters(state.financeRows));
      });
    });
    $('finance-filter-reset').addEventListener('click', () => {
      ['finance-search','finance-date-from','finance-date-to'].forEach(id => { $(id).value = ''; });
      ['finance-operation','finance-status','finance-method'].forEach(id => { $(id).value = 'all'; });
      renderFinanceRows(applyFinanceFilters(state.financeRows));
    });
    $('payment-entry-form').addEventListener('submit', submitPhysicalPayment);
  }

  async function init() {
    if (!window.supabase || typeof cfg.SUPABASE_URL !== 'string' ||
        !cfg.SUPABASE_URL.startsWith('https://') ||
        typeof cfg.SUPABASE_ANON_KEY !== 'string' || !cfg.SUPABASE_ANON_KEY.trim()) {
      showGlobalError('Configuration Supabase absente ou incomplète. Vérifiez public/assets/js/config.js.');
      $('session-state').textContent = 'Configuration requise';
      return;
    }

    state.db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    const { data: sessionData, error: sessionError } = await state.db.auth.getSession();
    if (sessionError) {
      showGlobalError('Impossible de vérifier la session. Réessayez ou contactez l’administrateur.');
      console.error(sessionError);
      return;
    }
    const session = sessionData?.session;
    state.session = session;
    if (!session) {
      window.location.replace('/connexion');
      return;
    }

    $('logout').addEventListener('click', async () => {
      $('logout').disabled = true;
      const { error } = await state.db.auth.signOut();
      if (error) {
        $('logout').disabled = false;
        showGlobalError('La déconnexion a échoué. Réessayez.');
        return;
      }
      window.location.replace('/connexion');
    });

    const { data: profile, error: profileError } = await state.db.from('profiles')
      .select('full_name,role,active')
      .eq('id', session.user.id)
      .single();

    if (profileError || !profile || !profile.active) {
      showGlobalError('Profil professionnel introuvable, inactif ou inaccessible. Contactez l’administrateur.');
      $('session-state').textContent = 'Profil non validé';
      console.error(profileError);
      return;
    }

    state.profile = profile;
    state.userId = session.user.id;
    $('welcome').textContent = `Bonjour ${profile.full_name || 'utilisateur'}`;
    $('role').textContent = `Profil : ${String(profile.role).replaceAll('_', ' ')}`;
    $('top-user').textContent = profile.full_name || session.user.email || 'Utilisateur connecté';

    const { data: permissions, error: permissionsError } = await state.db.from('role_permissions')
      .select('permission')
      .eq('role', profile.role);

    if (permissionsError) {
      showGlobalError('Impossible de lire les permissions du profil. Aucun module sensible ne sera affiché.');
      console.error(permissionsError);
      state.permissions = new Set();
    } else {
      state.permissions = new Set((permissions || []).map((item) => item.permission));
    }

    configureNavigation();
    await loadDashboard();
  }

  init().catch((error) => {
    console.error(error);
    showGlobalError('Une erreur inattendue empêche le chargement de l’espace municipal.');
  });
})();
