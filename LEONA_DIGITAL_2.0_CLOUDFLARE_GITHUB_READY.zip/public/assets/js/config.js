// Configuration publique uniquement.
// Ne jamais placer ici une clé service_role ou une clé secrète.
window.APP_CONFIG = Object.freeze({
  SUPABASE_URL: "https://ivklzdufnxmdiolmjvok.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_8Lkwk_eTU6bLEzb9o94PlQ_pMrnXdye"
});
