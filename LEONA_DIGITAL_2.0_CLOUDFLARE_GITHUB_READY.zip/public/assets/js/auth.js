(() => {
 const cfg=window.APP_CONFIG||{};
 const msg=document.getElementById('msg');
 if(!window.supabase||!cfg.SUPABASE_URL.startsWith('https://')||cfg.SUPABASE_ANON_KEY.startsWith('VOTRE_')){msg.textContent='Configuration Supabase à compléter.';return;}
 const client=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
 document.getElementById('login').addEventListener('submit',async e=>{
  e.preventDefault();msg.textContent='Connexion…';
  const {error}=await client.auth.signInWithPassword({email:document.getElementById('email').value.trim(),password:document.getElementById('password').value});
  if(error){msg.textContent='Connexion impossible. Vérifiez vos identifiants ou contactez l’administrateur.';return;}
  location.href='/espace';
 });
})();
