document.getElementById('lookup').addEventListener('submit',async e=>{
 e.preventDefault();const out=document.getElementById('result');out.textContent='Recherche…';
 try{
  const res=await fetch('/api/lookup-dues',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({taxpayer_id:document.getElementById('taxid').value.trim(),phone:document.getElementById('phone').value.trim()})});
  const data=await res.json();if(!res.ok)throw new Error('not_found');
  out.replaceChildren();const h=document.createElement('h2');h.textContent='Situation fiscale';out.append(h);
  (data.dues||[]).forEach(d=>{const p=document.createElement('p');p.textContent=`${d.label} — ${Number(d.balance).toLocaleString('fr-FR')} FCFA`;out.append(p);});
  if(!data.dues?.length){out.textContent='Aucune somme actuellement affichable.';}
 }catch(_){out.textContent='Informations introuvables ou indisponibles. Vérifiez vos données ou contactez la mairie.';}
});
