(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const config = window.APP_CONFIG || {};
  const token = new URLSearchParams(window.location.search).get('token') || '';

  function setStatus(label, kind, message) {
    const status = $('verification-status');
    status.textContent = label;
    status.className = `verification-status ${kind}`;
    $('verification-message').textContent = message;
  }

  function addDetail(root, label, value) {
    const line = document.createElement('div');
    line.className = 'verification-line';
    const name = document.createElement('span');
    name.textContent = label;
    const content = document.createElement('strong');
    content.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
    line.append(name, content);
    root.append(line);
  }

  function methodLabel(method) {
    return ({ cash: 'Espèces', cheque: 'Chèque', bank_transfer: 'Virement bancaire' })[method] || 'Autre mode';
  }

  function formatAmount(value) {
    const amount = Number(value);
    return Number.isFinite(amount)
      ? amount.toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' FCFA'
      : '—';
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString('fr-FR');
  }

  async function verify() {
    if (!/^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})$/i.test(token)) {
      setStatus('REÇU NON VÉRIFIABLE', 'invalid', 'Le lien est incomplet ou le jeton de vérification est invalide.');
      return;
    }

    if (!window.supabase || typeof config.SUPABASE_URL !== 'string' ||
        !config.SUPABASE_URL.startsWith('https://') ||
        typeof config.SUPABASE_ANON_KEY !== 'string' || !config.SUPABASE_ANON_KEY.trim()) {
      setStatus('SERVICE INDISPONIBLE', 'invalid', 'La configuration du service de vérification est absente.');
      return;
    }

    try {
      const client = window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY);
      const { data, error } = await client.rpc('verify_receipt', { p_token: token });
      if (error) throw error;
      const result = Array.isArray(data) ? data[0] : data;

      if (!result || result.is_valid !== true) {
        setStatus('REÇU INTROUVABLE', 'invalid', 'Aucun reçu correspondant à ce jeton n’a été retrouvé dans le registre de la Commune de Léona.');
        return;
      }

      const reversed = String(result.payment_status || '').toUpperCase() === 'ANNULE';
      setStatus(
        reversed ? 'REÇU AUTHENTIQUE — PAIEMENT ANNULÉ' : 'REÇU AUTHENTIQUE — PAIEMENT ENREGISTRÉ',
        reversed ? 'reversed' : 'valid',
        reversed
          ? 'Le reçu existe dans le registre, mais le paiement correspondant a été contrepassé. Il ne constitue plus un justificatif de paiement valide.'
          : 'Le reçu correspond à une écriture d’encaissement enregistrée dans le grand livre municipal.'
      );

      const details = $('verification-details');
      details.replaceChildren();
      addDetail(details, 'Numéro du reçu', result.receipt_number);
      addDetail(details, 'Date d’émission', formatDate(result.issued_at));
      addDetail(details, 'Montant', formatAmount(result.amount));
      addDetail(details, 'Mode de paiement', methodLabel(result.payment_method));
      addDetail(details, 'État comptable', reversed ? 'ANNULÉ / CONTREPASSÉ' : 'VALIDE');
      details.classList.remove('hidden');
    } catch (error) {
      console.error('RECEIPT_VERIFICATION_FAILED', error);
      setStatus('VÉRIFICATION IMPOSSIBLE', 'invalid', 'Le service n’a pas pu vérifier ce reçu. Réessayez plus tard ou contactez le receveur municipal.');
    }
  }

  verify();
})();
