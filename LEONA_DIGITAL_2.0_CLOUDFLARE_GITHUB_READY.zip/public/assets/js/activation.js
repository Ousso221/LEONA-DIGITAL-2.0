(() => {
  'use strict';
  const cfg = window.APP_CONFIG || {};
  const form = document.getElementById('activation-form');
  const message = document.getElementById('activation-message');
  const button = document.getElementById('activate-button');
  const say = (text, type='') => { message.textContent=text; message.className=`form-message ${type}`.trim(); };
  if (!window.supabase || !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
    say('Configuration de la plateforme indisponible. Contactez l’administrateur.', 'error');
    button.disabled=true; return;
  }
  const db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  let sessionReady = false;
  db.auth.getSession().then(({data,error}) => {
    if (error || !data?.session) {
      say('Lien d’invitation invalide ou expiré. Demandez à l’administrateur de renvoyer une invitation.', 'error');
      button.disabled=true; return;
    }
    sessionReady=true;
    say(`Invitation reconnue pour ${data.session.user.email || 'votre compte'}. Définissez votre mot de passe.`);
  }).catch(() => { say('Impossible de vérifier le lien. Réessayez ou demandez une nouvelle invitation.', 'error'); button.disabled=true; });
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!sessionReady) return say('Le lien doit être vérifié avant de continuer.', 'error');
    const password=document.getElementById('new-password').value;
    const confirm=document.getElementById('confirm-password').value;
    if (password.length < 12) return say('Utilisez au moins 12 caractères.', 'error');
    if (password !== confirm) return say('Les deux mots de passe ne correspondent pas.', 'error');
    button.disabled=true; say('Enregistrement sécurisé du mot de passe…');
    const {error}=await db.auth.updateUser({password});
    if (error) { button.disabled=false; say('Impossible de définir le mot de passe. Le lien peut avoir expiré ; demandez une nouvelle invitation.', 'error'); return; }
    say('Compte activé. Ouverture de votre espace municipal…', 'success');
    window.location.replace('/espace');
  });
})();
