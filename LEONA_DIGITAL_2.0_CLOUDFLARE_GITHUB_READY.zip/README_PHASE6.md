# Phase 6 — Encaissements et grand livre

Lire `docs/LIVRAISON_6_ENCAISSEMENTS_GRAND_LIVRE.md` avant installation.

Migration à exécuter une seule fois :
`supabase/migrations/0004_phase6_encaissements_grand_livre.sql`

Cette livraison ne nécessite aucune variable Netlify supplémentaire et n'expose aucune clé secrète côté navigateur.


## Phase 6.1 — espace du receveur municipal

La mise à jour `PHASE6_1_RECEVEUR_MUNICIPAL` améliore l'interface financière existante sans réinitialiser la base :

- synthèse des encaissements, contrepassations et net comptable sur les 200 dernières opérations visibles ;
- filtres du grand livre par contribuable/code/reçu, type, état, mode et dates ;
- action de contrepassation affichée uniquement au profil `receveur_municipal` disposant de `payments.reverse` ;
- lien de vérification publique ajouté au reçu imprimable lorsque le jeton est accessible ;
- page publique `/verification-recu` utilisant exclusivement la fonction RPC `verify_receipt(uuid)` ; aucune identité de contribuable n'est exposée sur cette page.

**Base de données :** aucune nouvelle migration SQL n'est requise si la correction Phase 6 exécutée le 25 novembre 2026 est toujours en place et si `public.verify_receipt(uuid)` est disponible. Ne pas réexécuter les migrations historiques.

Les indicateurs de synthèse et les filtres portent sur les 200 opérations les plus récentes retournées par la vue. Ils ne constituent pas encore des états comptables exhaustifs ou des rapports officiels.
