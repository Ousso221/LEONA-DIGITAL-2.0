# LÉONA DIGITAL 2.0 — Projet complet, espace Secrétaire général (Phase 5.1)

Cette archive est un projet complet à déployer, pas un patch isolé.

- Projet exclusivement destiné à la Commune de Léona.
- Conserve les fichiers de base, les fonctions Netlify et les migrations déjà livrées.
- Ajoute l'interface Fiscalité Phase 5 et les améliorations de travail du Secrétaire général Phase 5.1.
- Aucun tarif, catégorie fiscale officielle ou montant fictif n'est préchargé.

Consulter `docs/LIVRAISON_5_1_SECRETAIRE_GENERAL.md` avant le déploiement.

**Important :** ne rejouer aucune migration SQL déjà exécutée. En particulier, ne pas rejouer `0001_initial.sql`, `0002_phase4_agent_management.sql` ou `0003_phase5_fiscalite.sql`.
